import process from 'node:process';globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import { createHead as createHead$1 } from 'unhead/server';
import { isRef, toValue as toValue$1 } from 'vue';
import { DeprecationsPlugin } from 'unhead/legacy';
import { PromisesPlugin, TemplateParamsPlugin, AliasSortingPlugin } from 'unhead/plugins';
import http, { Server as Server$1 } from 'node:http';
import https, { Server } from 'node:https';
import { EventEmitter } from 'node:events';
import { Buffer as Buffer$1 } from 'node:buffer';
import { promises, existsSync } from 'node:fs';
import { resolve as resolve$2, dirname as dirname$1, join } from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { createConsola } from 'consola';
import { collectSitemap } from 'sitemapd/parse';

const suspectProtoRx = /"(?:_|\\u0{2}5[Ff]){2}(?:p|\\u0{2}70)(?:r|\\u0{2}72)(?:o|\\u0{2}6[Ff])(?:t|\\u0{2}74)(?:o|\\u0{2}6[Ff])(?:_|\\u0{2}5[Ff]){2}"\s*:/;
const suspectConstructorRx = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/;
const JsonSigRx = /^\s*["[{]|^\s*-?\d{1,16}(\.\d{1,17})?([Ee][+-]?\d+)?\s*$/;
function jsonParseTransform(key, value) {
  if (key === "__proto__" || key === "constructor" && value && typeof value === "object" && "prototype" in value) {
    warnKeyDropped(key);
    return;
  }
  return value;
}
function warnKeyDropped(key) {
  console.warn(`[destr] Dropping "${key}" key to prevent prototype pollution.`);
}
function destr(value, options = {}) {
  if (typeof value !== "string") {
    return value;
  }
  if (value[0] === '"' && value[value.length - 1] === '"' && value.indexOf("\\") === -1) {
    return value.slice(1, -1);
  }
  const _value = value.trim();
  if (_value.length <= 9) {
    switch (_value.toLowerCase()) {
      case "true": {
        return true;
      }
      case "false": {
        return false;
      }
      case "undefined": {
        return void 0;
      }
      case "null": {
        return null;
      }
      case "nan": {
        return Number.NaN;
      }
      case "infinity": {
        return Number.POSITIVE_INFINITY;
      }
      case "-infinity": {
        return Number.NEGATIVE_INFINITY;
      }
    }
  }
  if (!JsonSigRx.test(value)) {
    if (options.strict) {
      throw new SyntaxError("[destr] Invalid JSON");
    }
    return value;
  }
  try {
    if (suspectProtoRx.test(value) || suspectConstructorRx.test(value)) {
      if (options.strict) {
        throw new Error("[destr] Possible prototype pollution");
      }
      return JSON.parse(value, jsonParseTransform);
    }
    return JSON.parse(value);
  } catch (error) {
    if (options.strict) {
      throw error;
    }
    return value;
  }
}

const HASH_RE$1 = /#/g;
const AMPERSAND_RE = /&/g;
const SLASH_RE = /\//g;
const EQUAL_RE = /=/g;
const IM_RE = /\?/g;
const PLUS_RE = /\+/g;
const ENC_CARET_RE = /%5e/gi;
const ENC_BACKTICK_RE = /%60/gi;
const ENC_PIPE_RE$1 = /%7c/gi;
const ENC_SPACE_RE = /%20/gi;
const ENC_SLASH_RE = /%2f/gi;
const ENC_ENC_SLASH_RE$1 = /%252f/gi;
function encode(text) {
  return encodeURI("" + text).replace(ENC_PIPE_RE$1, "|");
}
function encodeQueryValue(input) {
  return encode(typeof input === "string" ? input : JSON.stringify(input)).replace(PLUS_RE, "%2B").replace(ENC_SPACE_RE, "+").replace(HASH_RE$1, "%23").replace(AMPERSAND_RE, "%26").replace(ENC_BACKTICK_RE, "`").replace(ENC_CARET_RE, "^").replace(SLASH_RE, "%2F");
}
function encodeQueryKey(text) {
  return encodeQueryValue(text).replace(EQUAL_RE, "%3D");
}
function encodePath(text) {
  return encode(text).replace(HASH_RE$1, "%23").replace(IM_RE, "%3F").replace(ENC_ENC_SLASH_RE$1, "%2F").replace(AMPERSAND_RE, "%26").replace(PLUS_RE, "%2B");
}
function decode(text = "") {
  try {
    return decodeURIComponent("" + text);
  } catch {
    return "" + text;
  }
}
function decodePath(text) {
  return decode(text.replace(ENC_SLASH_RE, "%252F"));
}
function decodeQueryKey(text) {
  return decode(text.replace(PLUS_RE, " "));
}
function decodeQueryValue(text) {
  return decode(text.replace(PLUS_RE, " "));
}

function parseQuery(parametersString = "") {
  const object = /* @__PURE__ */ Object.create(null);
  if (parametersString[0] === "?") {
    parametersString = parametersString.slice(1);
  }
  for (const parameter of parametersString.split("&")) {
    const s = parameter.match(/([^=]+)=?(.*)/) || [];
    if (s.length < 2) {
      continue;
    }
    const key = decodeQueryKey(s[1]);
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = decodeQueryValue(s[2] || "");
    if (object[key] === void 0) {
      object[key] = value;
    } else if (Array.isArray(object[key])) {
      object[key].push(value);
    } else {
      object[key] = [object[key], value];
    }
  }
  return object;
}
function encodeQueryItem(key, value) {
  if (typeof value === "number" || typeof value === "boolean") {
    value = String(value);
  }
  if (!value) {
    return encodeQueryKey(key);
  }
  if (Array.isArray(value)) {
    return value.map(
      (_value) => `${encodeQueryKey(key)}=${encodeQueryValue(_value)}`
    ).join("&");
  }
  return `${encodeQueryKey(key)}=${encodeQueryValue(value)}`;
}
function stringifyQuery(query) {
  return Object.keys(query).filter((k) => query[k] !== void 0).map((k) => encodeQueryItem(k, query[k])).filter(Boolean).join("&");
}

const PROTOCOL_STRICT_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{1,2})/;
const PROTOCOL_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{2})?/;
const PROTOCOL_RELATIVE_REGEX = /^([/\\]\s*){2,}[^/\\]/;
const PROTOCOL_SCRIPT_RE = /^[\s\0]*(blob|data|javascript|vbscript):$/i;
const TRAILING_SLASH_RE$1 = /\/$|\/\?|\/#/;
const JOIN_LEADING_SLASH_RE = /^\.?\//;
function hasProtocol(inputString, opts = {}) {
  if (typeof opts === "boolean") {
    opts = { acceptRelative: opts };
  }
  if (opts.strict) {
    return PROTOCOL_STRICT_REGEX.test(inputString);
  }
  return PROTOCOL_REGEX.test(inputString) || (opts.acceptRelative ? PROTOCOL_RELATIVE_REGEX.test(inputString) : false);
}
function isScriptProtocol(protocol) {
  return !!protocol && PROTOCOL_SCRIPT_RE.test(protocol);
}
function hasTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/");
  }
  return TRAILING_SLASH_RE$1.test(input);
}
function withoutTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return (hasTrailingSlash(input) ? input.slice(0, -1) : input) || "/";
  }
  if (!hasTrailingSlash(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex !== -1) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
  }
  const [s0, ...s] = path.split("?");
  const cleanPath = s0.endsWith("/") ? s0.slice(0, -1) : s0;
  return (cleanPath || "/") + (s.length > 0 ? `?${s.join("?")}` : "") + fragment;
}
function withTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/") ? input : input + "/";
  }
  if (hasTrailingSlash(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex !== -1) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
    if (!path) {
      return fragment;
    }
  }
  const [s0, ...s] = path.split("?");
  return s0 + "/" + (s.length > 0 ? `?${s.join("?")}` : "") + fragment;
}
function hasLeadingSlash(input = "") {
  return input.startsWith("/");
}
function withLeadingSlash(input = "") {
  return hasLeadingSlash(input) ? input : "/" + input;
}
function withBase(input, base) {
  if (isEmptyURL(base) || hasProtocol(input)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (input.startsWith(_base)) {
    const nextChar = input[_base.length];
    if (!nextChar || nextChar === "/" || nextChar === "?") {
      return input;
    }
  }
  return joinURL(_base, input);
}
function withoutBase(input, base) {
  if (isEmptyURL(base)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (!input.startsWith(_base)) {
    return input;
  }
  const nextChar = input[_base.length];
  if (nextChar && nextChar !== "/" && nextChar !== "?") {
    return input;
  }
  const trimmed = input.slice(_base.length).replace(/^\/+/, "");
  return "/" + trimmed;
}
function withQuery(input, query) {
  const parsed = parseURL(input);
  const mergedQuery = { ...parseQuery(parsed.search), ...query };
  parsed.search = stringifyQuery(mergedQuery);
  return stringifyParsedURL(parsed);
}
function getQuery$1(input) {
  return parseQuery(parseURL(input).search);
}
function isEmptyURL(url) {
  return !url || url === "/";
}
function isNonEmptyURL(url) {
  return url && url !== "/";
}
function joinURL(base, ...input) {
  let url = base || "";
  for (const segment of input.filter((url2) => isNonEmptyURL(url2))) {
    if (url) {
      const _segment = segment.replace(JOIN_LEADING_SLASH_RE, "");
      url = withTrailingSlash(url) + _segment;
    } else {
      url = segment;
    }
  }
  return url;
}
function joinRelativeURL(..._input) {
  const JOIN_SEGMENT_SPLIT_RE = /\/(?!\/)/;
  const input = _input.filter(Boolean);
  const segments = [];
  let segmentsDepth = 0;
  for (const i of input) {
    if (!i || i === "/") {
      continue;
    }
    for (const [sindex, s] of i.split(JOIN_SEGMENT_SPLIT_RE).entries()) {
      if (!s || s === ".") {
        continue;
      }
      if (s === "..") {
        if (segments.length === 1 && hasProtocol(segments[0])) {
          continue;
        }
        segments.pop();
        segmentsDepth--;
        continue;
      }
      if (sindex === 1 && segments[segments.length - 1]?.endsWith(":/")) {
        segments[segments.length - 1] += "/" + s;
        continue;
      }
      segments.push(s);
      segmentsDepth++;
    }
  }
  let url = segments.join("/");
  if (segmentsDepth >= 0) {
    if (input[0]?.startsWith("/") && !url.startsWith("/")) {
      url = "/" + url;
    } else if (input[0]?.startsWith("./") && !url.startsWith("./")) {
      url = "./" + url;
    }
  } else {
    url = "../".repeat(-1 * segmentsDepth) + url;
  }
  if (input[input.length - 1]?.endsWith("/") && !url.endsWith("/")) {
    url += "/";
  }
  return url;
}
function withHttps(input) {
  return withProtocol(input, "https://");
}
function withProtocol(input, protocol) {
  let match = input.match(PROTOCOL_REGEX);
  if (!match) {
    match = input.match(/^\/{2,}/);
  }
  if (!match) {
    return protocol + input;
  }
  return protocol + input.slice(match[0].length);
}

const protocolRelative = Symbol.for("ufo:protocolRelative");
function parseURL(input = "", defaultProto) {
  const _specialProtoMatch = input.match(
    /^[\s\0]*(blob:|data:|javascript:|vbscript:)(.*)/i
  );
  if (_specialProtoMatch) {
    const [, _proto, _pathname = ""] = _specialProtoMatch;
    return {
      protocol: _proto.toLowerCase(),
      pathname: _pathname,
      href: _proto + _pathname,
      auth: "",
      host: "",
      search: "",
      hash: ""
    };
  }
  if (!hasProtocol(input, { acceptRelative: true })) {
    return defaultProto ? parseURL(defaultProto + input) : parsePath(input);
  }
  const [, protocol = "", auth, hostAndPath = ""] = input.replace(/\\/g, "/").match(/^[\s\0]*([\w+.-]{2,}:)?\/\/([^/@]+@)?(.*)/) || [];
  let [, host = "", path = ""] = hostAndPath.match(/([^#/?]*)(.*)?/) || [];
  if (protocol === "file:") {
    path = path.replace(/\/(?=[A-Za-z]:)/, "");
  }
  const { pathname, search, hash } = parsePath(path);
  return {
    protocol: protocol.toLowerCase(),
    auth: auth ? auth.slice(0, Math.max(0, auth.length - 1)) : "",
    host,
    pathname,
    search,
    hash,
    [protocolRelative]: !protocol
  };
}
function parsePath(input = "") {
  const [pathname = "", search = "", hash = ""] = (input.match(/([^#?]*)(\?[^#]*)?(#.*)?/) || []).splice(1);
  return {
    pathname,
    search,
    hash
  };
}
function stringifyParsedURL(parsed) {
  const pathname = parsed.pathname || "";
  const search = parsed.search ? (parsed.search.startsWith("?") ? "" : "?") + parsed.search : "";
  const hash = parsed.hash || "";
  const auth = parsed.auth ? parsed.auth + "@" : "";
  const host = parsed.host || "";
  const proto = parsed.protocol || parsed[protocolRelative] ? (parsed.protocol || "") + "//" : "";
  return proto + auth + host + pathname + search + hash;
}

const NODE_TYPES = {
  NORMAL: 0,
  WILDCARD: 1,
  PLACEHOLDER: 2
};

function createRouter$1(options = {}) {
  const ctx = {
    options,
    rootNode: createRadixNode(),
    staticRoutesMap: {}
  };
  const normalizeTrailingSlash = (p) => options.strictTrailingSlash ? p : p.replace(/\/$/, "") || "/";
  if (options.routes) {
    for (const path in options.routes) {
      insert(ctx, normalizeTrailingSlash(path), options.routes[path]);
    }
  }
  return {
    ctx,
    lookup: (path) => lookup(ctx, normalizeTrailingSlash(path)),
    insert: (path, data) => insert(ctx, normalizeTrailingSlash(path), data),
    remove: (path) => remove(ctx, normalizeTrailingSlash(path))
  };
}
function lookup(ctx, path) {
  const staticPathNode = ctx.staticRoutesMap[path];
  if (staticPathNode) {
    return staticPathNode.data;
  }
  const sections = path.split("/");
  const params = {};
  let paramsFound = false;
  let wildcardNode = null;
  let node = ctx.rootNode;
  let wildCardParam = null;
  for (let i = 0; i < sections.length; i++) {
    const section = sections[i];
    if (node.wildcardChildNode !== null) {
      wildcardNode = node.wildcardChildNode;
      wildCardParam = sections.slice(i).join("/");
    }
    const nextNode = node.children.get(section);
    if (nextNode === void 0) {
      if (node && node.placeholderChildren.length > 1) {
        const remaining = sections.length - i;
        node = node.placeholderChildren.find((c) => c.maxDepth === remaining) || null;
      } else {
        node = node.placeholderChildren[0] || null;
      }
      if (!node) {
        break;
      }
      if (node.paramName) {
        params[node.paramName] = section;
      }
      paramsFound = true;
    } else {
      node = nextNode;
    }
  }
  if ((node === null || node.data === null) && wildcardNode !== null) {
    node = wildcardNode;
    params[node.paramName || "_"] = wildCardParam;
    paramsFound = true;
  }
  if (!node) {
    return null;
  }
  if (paramsFound) {
    return {
      ...node.data,
      params: paramsFound ? params : void 0
    };
  }
  return node.data;
}
function insert(ctx, path, data) {
  let isStaticRoute = true;
  const sections = path.split("/");
  let node = ctx.rootNode;
  let _unnamedPlaceholderCtr = 0;
  const matchedNodes = [node];
  for (const section of sections) {
    let childNode;
    if (childNode = node.children.get(section)) {
      node = childNode;
    } else {
      const type = getNodeType(section);
      childNode = createRadixNode({ type, parent: node });
      node.children.set(section, childNode);
      if (type === NODE_TYPES.PLACEHOLDER) {
        childNode.paramName = section === "*" ? `_${_unnamedPlaceholderCtr++}` : section.slice(1);
        node.placeholderChildren.push(childNode);
        isStaticRoute = false;
      } else if (type === NODE_TYPES.WILDCARD) {
        node.wildcardChildNode = childNode;
        childNode.paramName = section.slice(
          3
          /* "**:" */
        ) || "_";
        isStaticRoute = false;
      }
      matchedNodes.push(childNode);
      node = childNode;
    }
  }
  for (const [depth, node2] of matchedNodes.entries()) {
    node2.maxDepth = Math.max(matchedNodes.length - depth, node2.maxDepth || 0);
  }
  node.data = data;
  if (isStaticRoute === true) {
    ctx.staticRoutesMap[path] = node;
  }
  return node;
}
function remove(ctx, path) {
  let success = false;
  const sections = path.split("/");
  let node = ctx.rootNode;
  for (const section of sections) {
    node = node.children.get(section);
    if (!node) {
      return success;
    }
  }
  if (node.data) {
    const lastSection = sections.at(-1) || "";
    node.data = null;
    if (Object.keys(node.children).length === 0 && node.parent) {
      node.parent.children.delete(lastSection);
      node.parent.wildcardChildNode = null;
      node.parent.placeholderChildren = [];
    }
    success = true;
  }
  return success;
}
function createRadixNode(options = {}) {
  return {
    type: options.type || NODE_TYPES.NORMAL,
    maxDepth: 0,
    parent: options.parent || null,
    children: /* @__PURE__ */ new Map(),
    data: options.data || null,
    paramName: options.paramName || null,
    wildcardChildNode: null,
    placeholderChildren: []
  };
}
function getNodeType(str) {
  if (str.startsWith("**")) {
    return NODE_TYPES.WILDCARD;
  }
  if (str[0] === ":" || str === "*") {
    return NODE_TYPES.PLACEHOLDER;
  }
  return NODE_TYPES.NORMAL;
}

function toRouteMatcher(router) {
  const table = _routerNodeToTable("", router.ctx.rootNode);
  return _createMatcher(table, router.ctx.options.strictTrailingSlash);
}
function _createMatcher(table, strictTrailingSlash) {
  return {
    ctx: { table },
    matchAll: (path) => _matchRoutes(path, table, strictTrailingSlash)
  };
}
function _createRouteTable() {
  return {
    static: /* @__PURE__ */ new Map(),
    wildcard: /* @__PURE__ */ new Map(),
    dynamic: /* @__PURE__ */ new Map()
  };
}
function _matchRoutes(path, table, strictTrailingSlash) {
  if (strictTrailingSlash !== true && path.endsWith("/")) {
    path = path.slice(0, -1) || "/";
  }
  const matches = [];
  for (const [key, value] of _sortRoutesMap(table.wildcard)) {
    if (path === key || path.startsWith(key + "/")) {
      matches.push(value);
    }
  }
  for (const [key, value] of _sortRoutesMap(table.dynamic)) {
    if (path.startsWith(key + "/")) {
      const subPath = "/" + path.slice(key.length).split("/").splice(2).join("/");
      matches.push(..._matchRoutes(subPath, value));
    }
  }
  const staticMatch = table.static.get(path);
  if (staticMatch) {
    matches.push(staticMatch);
  }
  return matches.filter(Boolean);
}
function _sortRoutesMap(m) {
  return [...m.entries()].sort((a, b) => a[0].length - b[0].length);
}
function _routerNodeToTable(initialPath, initialNode) {
  const table = _createRouteTable();
  function _addNode(path, node) {
    if (path) {
      if (node.type === NODE_TYPES.NORMAL && !(path.includes("*") || path.includes(":"))) {
        if (node.data) {
          table.static.set(path, node.data);
        }
      } else if (node.type === NODE_TYPES.WILDCARD) {
        table.wildcard.set(path.replace("/**", ""), node.data);
      } else if (node.type === NODE_TYPES.PLACEHOLDER) {
        const subTable = _routerNodeToTable("", node);
        if (node.data) {
          subTable.static.set("/", node.data);
        }
        table.dynamic.set(path.replace(/\/\*|\/:\w+/, ""), subTable);
        return;
      }
    }
    for (const [childPath, child] of node.children.entries()) {
      _addNode(`${path}/${childPath}`.replace("//", "/"), child);
    }
  }
  _addNode(initialPath, initialNode);
  return table;
}

function isPlainObject(value) {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== null && prototype !== Object.prototype && Object.getPrototypeOf(prototype) !== null) {
    return false;
  }
  if (Symbol.iterator in value) {
    return false;
  }
  if (Symbol.toStringTag in value) {
    return Object.prototype.toString.call(value) === "[object Module]";
  }
  return true;
}

function _defu(baseObject, defaults, namespace = ".", merger) {
  if (!isPlainObject(defaults)) {
    return _defu(baseObject, {}, namespace, merger);
  }
  const object = { ...defaults };
  for (const key of Object.keys(baseObject)) {
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = baseObject[key];
    if (value === null || value === void 0) {
      continue;
    }
    if (merger && merger(object, key, value, namespace)) {
      continue;
    }
    if (Array.isArray(value) && Array.isArray(object[key])) {
      object[key] = [...value, ...object[key]];
    } else if (isPlainObject(value) && isPlainObject(object[key])) {
      object[key] = _defu(
        value,
        object[key],
        (namespace ? `${namespace}.` : "") + key.toString(),
        merger
      );
    } else {
      object[key] = value;
    }
  }
  return object;
}
function createDefu(merger) {
  return (...arguments_) => (
    // eslint-disable-next-line unicorn/no-array-reduce
    arguments_.reduce((p, c) => _defu(p, c, "", merger), {})
  );
}
const defu = createDefu();
const defuFn = createDefu((object, key, currentValue) => {
  if (object[key] !== void 0 && typeof currentValue === "function") {
    object[key] = currentValue(object[key]);
    return true;
  }
});

function o(n){throw new Error(`${n} is not implemented yet!`)}let i$1 = class i extends EventEmitter{__unenv__={};readableEncoding=null;readableEnded=true;readableFlowing=false;readableHighWaterMark=0;readableLength=0;readableObjectMode=false;readableAborted=false;readableDidRead=false;closed=false;errored=null;readable=false;destroyed=false;static from(e,t){return new i(t)}constructor(e){super();}_read(e){}read(e){}setEncoding(e){return this}pause(){return this}resume(){return this}isPaused(){return  true}unpipe(e){return this}unshift(e,t){}wrap(e){return this}push(e,t){return  false}_destroy(e,t){this.removeAllListeners();}destroy(e){return this.destroyed=true,this._destroy(e),this}pipe(e,t){return {}}compose(e,t){throw new Error("Method not implemented.")}[Symbol.asyncDispose](){return this.destroy(),Promise.resolve()}async*[Symbol.asyncIterator](){throw o("Readable.asyncIterator")}iterator(e){throw o("Readable.iterator")}map(e,t){throw o("Readable.map")}filter(e,t){throw o("Readable.filter")}forEach(e,t){throw o("Readable.forEach")}reduce(e,t,r){throw o("Readable.reduce")}find(e,t){throw o("Readable.find")}findIndex(e,t){throw o("Readable.findIndex")}some(e,t){throw o("Readable.some")}toArray(e){throw o("Readable.toArray")}every(e,t){throw o("Readable.every")}flatMap(e,t){throw o("Readable.flatMap")}drop(e,t){throw o("Readable.drop")}take(e,t){throw o("Readable.take")}asIndexedPairs(e){throw o("Readable.asIndexedPairs")}};let l$1 = class l extends EventEmitter{__unenv__={};writable=true;writableEnded=false;writableFinished=false;writableHighWaterMark=0;writableLength=0;writableObjectMode=false;writableCorked=0;closed=false;errored=null;writableNeedDrain=false;writableAborted=false;destroyed=false;_data;_encoding="utf8";constructor(e){super();}pipe(e,t){return {}}_write(e,t,r){if(this.writableEnded){r&&r();return}if(this._data===void 0)this._data=e;else {const s=typeof this._data=="string"?Buffer$1.from(this._data,this._encoding||t||"utf8"):this._data,a=typeof e=="string"?Buffer$1.from(e,t||this._encoding||"utf8"):e;this._data=Buffer$1.concat([s,a]);}this._encoding=t,r&&r();}_writev(e,t){}_destroy(e,t){}_final(e){}write(e,t,r){const s=typeof t=="string"?this._encoding:"utf8",a=typeof t=="function"?t:typeof r=="function"?r:void 0;return this._write(e,s,a),true}setDefaultEncoding(e){return this}end(e,t,r){const s=typeof e=="function"?e:typeof t=="function"?t:typeof r=="function"?r:void 0;if(this.writableEnded)return s&&s(),this;const a=e===s?void 0:e;if(a){const u=t===s?void 0:t;this.write(a,u);}return this.writableEnded=true,this.writableFinished=true,this.emit("close"),this.emit("finish"),s&&s(),this}cork(){}uncork(){}destroy(e){return this.destroyed=true,delete this._data,this.removeAllListeners(),this}compose(e,t){throw new Error("Method not implemented.")}[Symbol.asyncDispose](){return Promise.resolve()}};const c$1=class c{allowHalfOpen=true;_destroy;constructor(e=new i$1,t=new l$1){Object.assign(this,e),Object.assign(this,t),this._destroy=m$1(e._destroy,t._destroy);}};function _(){return Object.assign(c$1.prototype,i$1.prototype),Object.assign(c$1.prototype,l$1.prototype),c$1}function m$1(...n){return function(...e){for(const t of n)t(...e);}}const g$1=_();class A extends g$1{__unenv__={};bufferSize=0;bytesRead=0;bytesWritten=0;connecting=false;destroyed=false;pending=false;localAddress="";localPort=0;remoteAddress="";remoteFamily="";remotePort=0;autoSelectFamilyAttemptedAddresses=[];readyState="readOnly";constructor(e){super();}write(e,t,r){return  false}connect(e,t,r){return this}end(e,t,r){return this}setEncoding(e){return this}pause(){return this}resume(){return this}setTimeout(e,t){return this}setNoDelay(e){return this}setKeepAlive(e,t){return this}address(){return {}}unref(){return this}ref(){return this}destroySoon(){this.destroy();}resetAndDestroy(){const e=new Error("ERR_SOCKET_CLOSED");return e.code="ERR_SOCKET_CLOSED",this.destroy(e),this}}class y extends i$1{aborted=false;httpVersion="1.1";httpVersionMajor=1;httpVersionMinor=1;complete=true;connection;socket;headers={};trailers={};method="GET";url="/";statusCode=200;statusMessage="";closed=false;errored=null;readable=false;constructor(e){super(),this.socket=this.connection=e||new A;}get rawHeaders(){const e=this.headers,t=[];for(const r in e)if(Array.isArray(e[r]))for(const s of e[r])t.push(r,s);else t.push(r,e[r]);return t}get rawTrailers(){return []}setTimeout(e,t){return this}get headersDistinct(){return p$1(this.headers)}get trailersDistinct(){return p$1(this.trailers)}}function p$1(n){const e={};for(const[t,r]of Object.entries(n))t&&(e[t]=(Array.isArray(r)?r:[r]).filter(Boolean));return e}class w extends l$1{statusCode=200;statusMessage="";upgrading=false;chunkedEncoding=false;shouldKeepAlive=false;useChunkedEncodingByDefault=false;sendDate=false;finished=false;headersSent=false;strictContentLength=false;connection=null;socket=null;req;_headers={};constructor(e){super(),this.req=e;}assignSocket(e){e._httpMessage=this,this.socket=e,this.connection=e,this.emit("socket",e),this._flush();}_flush(){this.flushHeaders();}detachSocket(e){}writeContinue(e){}writeHead(e,t,r){e&&(this.statusCode=e),typeof t=="string"&&(this.statusMessage=t,t=void 0);const s=r||t;if(s&&!Array.isArray(s))for(const a in s)this.setHeader(a,s[a]);return this.headersSent=true,this}writeProcessing(){}setTimeout(e,t){return this}appendHeader(e,t){e=e.toLowerCase();const r=this._headers[e],s=[...Array.isArray(r)?r:[r],...Array.isArray(t)?t:[t]].filter(Boolean);return this._headers[e]=s.length>1?s:s[0],this}setHeader(e,t){return this._headers[e.toLowerCase()]=t,this}setHeaders(e){for(const[t,r]of Object.entries(e))this.setHeader(t,r);return this}getHeader(e){return this._headers[e.toLowerCase()]}getHeaders(){return this._headers}getHeaderNames(){return Object.keys(this._headers)}hasHeader(e){return e.toLowerCase()in this._headers}removeHeader(e){delete this._headers[e.toLowerCase()];}addTrailers(e){}flushHeaders(){}writeEarlyHints(e,t){typeof t=="function"&&t();}}const E$1=(()=>{const n=function(){};return n.prototype=Object.create(null),n})();function R(n={}){const e=new E$1,t=Array.isArray(n)||H$1(n)?n:Object.entries(n);for(const[r,s]of t)if(s){if(e[r]===void 0){e[r]=s;continue}e[r]=[...Array.isArray(e[r])?e[r]:[e[r]],...Array.isArray(s)?s:[s]];}return e}function H$1(n){return typeof n?.entries=="function"}function v$1(n={}){if(n instanceof Headers)return n;const e=new Headers;for(const[t,r]of Object.entries(n))if(r!==void 0){if(Array.isArray(r)){for(const s of r)e.append(t,String(s));continue}e.set(t,String(r));}return e}const S=new Set([101,204,205,304]);async function b$1(n,e){const t=new y,r=new w(t);t.url=e.url?.toString()||"/";let s;if(!t.url.startsWith("/")){const d=new URL(t.url);s=d.host,t.url=d.pathname+d.search+d.hash;}t.method=e.method||"GET",t.headers=R(e.headers||{}),t.headers.host||(t.headers.host=e.host||s||"localhost"),t.connection.encrypted=t.connection.encrypted||e.protocol==="https",t.body=e.body||null,t.__unenv__=e.context,await n(t,r);let a=r._data;(S.has(r.statusCode)||t.method.toUpperCase()==="HEAD")&&(a=null,delete r._headers["content-length"]);const u={status:r.statusCode,statusText:r.statusMessage,headers:r._headers,body:a};return t.destroy(),r.destroy(),u}async function C(n,e,t={}){try{const r=await b$1(n,{url:e,...t});return new Response(r.body,{status:r.status,statusText:r.statusText,headers:v$1(r.headers)})}catch(r){return new Response(r.toString(),{status:Number.parseInt(r.statusCode||r.code)||500,statusText:r.statusText})}}

function hasProp(obj, prop) {
  try {
    return prop in obj;
  } catch {
    return false;
  }
}

class H3Error extends Error {
  static __h3_error__ = true;
  statusCode = 500;
  fatal = false;
  unhandled = false;
  statusMessage;
  data;
  cause;
  constructor(message, opts = {}) {
    super(message, opts);
    if (opts.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
  toJSON() {
    const obj = {
      message: this.message,
      statusCode: sanitizeStatusCode(this.statusCode, 500)
    };
    if (this.statusMessage) {
      obj.statusMessage = sanitizeStatusMessage(this.statusMessage);
    }
    if (this.data !== void 0) {
      obj.data = this.data;
    }
    return obj;
  }
}
function createError$1(input) {
  if (typeof input === "string") {
    return new H3Error(input);
  }
  if (isError(input)) {
    return input;
  }
  const err = new H3Error(input.message ?? input.statusMessage ?? "", {
    cause: input.cause || input
  });
  if (hasProp(input, "stack")) {
    try {
      Object.defineProperty(err, "stack", {
        get() {
          return input.stack;
        }
      });
    } catch {
      try {
        err.stack = input.stack;
      } catch {
      }
    }
  }
  if (input.data) {
    err.data = input.data;
  }
  if (input.statusCode) {
    err.statusCode = sanitizeStatusCode(input.statusCode, err.statusCode);
  } else if (input.status) {
    err.statusCode = sanitizeStatusCode(input.status, err.statusCode);
  }
  if (input.statusMessage) {
    err.statusMessage = input.statusMessage;
  } else if (input.statusText) {
    err.statusMessage = input.statusText;
  }
  if (err.statusMessage) {
    const originalMessage = err.statusMessage;
    const sanitizedMessage = sanitizeStatusMessage(err.statusMessage);
    if (sanitizedMessage !== originalMessage) {
      console.warn(
        "[h3] Please prefer using `message` for longer error messages instead of `statusMessage`. In the future, `statusMessage` will be sanitized by default."
      );
    }
  }
  if (input.fatal !== void 0) {
    err.fatal = input.fatal;
  }
  if (input.unhandled !== void 0) {
    err.unhandled = input.unhandled;
  }
  return err;
}
function sendError(event, error, debug) {
  if (event.handled) {
    return;
  }
  const h3Error = isError(error) ? error : createError$1(error);
  const responseBody = {
    statusCode: h3Error.statusCode,
    statusMessage: h3Error.statusMessage,
    stack: [],
    data: h3Error.data
  };
  if (debug) {
    responseBody.stack = (h3Error.stack || "").split("\n").map((l) => l.trim());
  }
  if (event.handled) {
    return;
  }
  const _code = Number.parseInt(h3Error.statusCode);
  setResponseStatus(event, _code, h3Error.statusMessage);
  event.node.res.setHeader("content-type", MIMES.json);
  event.node.res.end(JSON.stringify(responseBody, void 0, 2));
}
function isError(input) {
  return input?.constructor?.__h3_error__ === true;
}

function getQuery(event) {
  return getQuery$1(event.path || "");
}
function getRouterParams(event, opts = {}) {
  let params = event.context.params || {};
  if (opts.decode) {
    params = { ...params };
    for (const key in params) {
      params[key] = decode(params[key]);
    }
  }
  return params;
}
function getRouterParam(event, name, opts = {}) {
  const params = getRouterParams(event, opts);
  return params[name];
}
function isMethod(event, expected, allowHead) {
  if (typeof expected === "string") {
    if (event.method === expected) {
      return true;
    }
  } else if (expected.includes(event.method)) {
    return true;
  }
  return false;
}
function assertMethod(event, expected, allowHead) {
  if (!isMethod(event, expected)) {
    throw createError$1({
      statusCode: 405,
      statusMessage: "HTTP method is not allowed."
    });
  }
}
function getRequestHeaders(event) {
  const _headers = {};
  for (const key in event.node.req.headers) {
    const val = event.node.req.headers[key];
    _headers[key] = Array.isArray(val) ? val.filter(Boolean).join(", ") : val;
  }
  return _headers;
}
function getRequestHeader(event, name) {
  const headers = getRequestHeaders(event);
  const value = headers[name.toLowerCase()];
  return value;
}
const getHeader = getRequestHeader;
function getRequestHost(event, opts = {}) {
  if (opts.xForwardedHost) {
    const _header = event.node.req.headers["x-forwarded-host"];
    const xForwardedHost = (_header || "").split(",").shift()?.trim();
    if (xForwardedHost) {
      return xForwardedHost;
    }
  }
  return event.node.req.headers.host || "localhost";
}
function getRequestProtocol(event, opts = {}) {
  if (opts.xForwardedProto !== false && event.node.req.headers["x-forwarded-proto"] === "https") {
    return "https";
  }
  return event.node.req.connection?.encrypted ? "https" : "http";
}
function getRequestURL(event, opts = {}) {
  const host = getRequestHost(event, opts);
  const protocol = getRequestProtocol(event, opts);
  const path = (event.node.req.originalUrl || event.path).replace(
    /^[/\\]+/g,
    "/"
  );
  return new URL(path, `${protocol}://${host}`);
}

const RawBodySymbol = Symbol.for("h3RawBody");
const PayloadMethods$1 = ["PATCH", "POST", "PUT", "DELETE"];
function readRawBody(event, encoding = "utf8") {
  assertMethod(event, PayloadMethods$1);
  const _rawBody = event._requestBody || event.web?.request?.body || event.node.req[RawBodySymbol] || event.node.req.rawBody || event.node.req.body;
  if (_rawBody) {
    const promise2 = Promise.resolve(_rawBody).then((_resolved) => {
      if (Buffer.isBuffer(_resolved)) {
        return _resolved;
      }
      if (typeof _resolved.pipeTo === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.pipeTo(
            new WritableStream({
              write(chunk) {
                chunks.push(chunk);
              },
              close() {
                resolve(Buffer.concat(chunks));
              },
              abort(reason) {
                reject(reason);
              }
            })
          ).catch(reject);
        });
      } else if (typeof _resolved.pipe === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.on("data", (chunk) => {
            chunks.push(chunk);
          }).on("end", () => {
            resolve(Buffer.concat(chunks));
          }).on("error", reject);
        });
      }
      if (_resolved.constructor === Object) {
        return Buffer.from(JSON.stringify(_resolved));
      }
      if (_resolved instanceof URLSearchParams) {
        return Buffer.from(_resolved.toString());
      }
      if (_resolved instanceof FormData) {
        return new Response(_resolved).bytes().then((uint8arr) => Buffer.from(uint8arr));
      }
      return Buffer.from(_resolved);
    });
    return encoding ? promise2.then((buff) => buff.toString(encoding)) : promise2;
  }
  if (!Number.parseInt(event.node.req.headers["content-length"] || "") && !/\bchunked\b/i.test(
    String(event.node.req.headers["transfer-encoding"] ?? "")
  )) {
    return Promise.resolve(void 0);
  }
  const promise = event.node.req[RawBodySymbol] = new Promise(
    (resolve, reject) => {
      const bodyData = [];
      event.node.req.on("error", (err) => {
        reject(err);
      }).on("data", (chunk) => {
        bodyData.push(chunk);
      }).on("end", () => {
        resolve(Buffer.concat(bodyData));
      });
    }
  );
  const result = encoding ? promise.then((buff) => buff.toString(encoding)) : promise;
  return result;
}
function getRequestWebStream(event) {
  if (!PayloadMethods$1.includes(event.method)) {
    return;
  }
  const bodyStream = event.web?.request?.body || event._requestBody;
  if (bodyStream) {
    return bodyStream;
  }
  const _hasRawBody = RawBodySymbol in event.node.req || "rawBody" in event.node.req || "body" in event.node.req || "__unenv__" in event.node.req;
  if (_hasRawBody) {
    return new ReadableStream({
      async start(controller) {
        const _rawBody = await readRawBody(event, false);
        if (_rawBody) {
          controller.enqueue(_rawBody);
        }
        controller.close();
      }
    });
  }
  return new ReadableStream({
    start: (controller) => {
      event.node.req.on("data", (chunk) => {
        controller.enqueue(chunk);
      });
      event.node.req.on("end", () => {
        controller.close();
      });
      event.node.req.on("error", (err) => {
        controller.error(err);
      });
    }
  });
}

function handleCacheHeaders(event, opts) {
  const cacheControls = ["public", ...opts.cacheControls || []];
  let cacheMatched = false;
  if (opts.maxAge !== void 0) {
    cacheControls.push(`max-age=${+opts.maxAge}`, `s-maxage=${+opts.maxAge}`);
  }
  if (opts.modifiedTime) {
    const modifiedTime = new Date(opts.modifiedTime);
    const ifModifiedSince = event.node.req.headers["if-modified-since"];
    event.node.res.setHeader("last-modified", modifiedTime.toUTCString());
    if (ifModifiedSince && new Date(ifModifiedSince) >= modifiedTime) {
      cacheMatched = true;
    }
  }
  if (opts.etag) {
    event.node.res.setHeader("etag", opts.etag);
    const ifNonMatch = event.node.req.headers["if-none-match"];
    if (ifNonMatch === opts.etag) {
      cacheMatched = true;
    }
  }
  event.node.res.setHeader("cache-control", cacheControls.join(", "));
  if (cacheMatched) {
    event.node.res.statusCode = 304;
    if (!event.handled) {
      event.node.res.end();
    }
    return true;
  }
  return false;
}

const MIMES = {
  html: "text/html",
  json: "application/json"
};

const DISALLOWED_STATUS_CHARS = /[^\u0009\u0020-\u007E]/g;
function sanitizeStatusMessage(statusMessage = "") {
  return statusMessage.replace(DISALLOWED_STATUS_CHARS, "");
}
function sanitizeStatusCode(statusCode, defaultStatusCode = 200) {
  if (!statusCode) {
    return defaultStatusCode;
  }
  if (typeof statusCode === "string") {
    statusCode = Number.parseInt(statusCode, 10);
  }
  if (statusCode < 100 || statusCode > 999) {
    return defaultStatusCode;
  }
  return statusCode;
}
function splitCookiesString(cookiesString) {
  if (Array.isArray(cookiesString)) {
    return cookiesString.flatMap((c) => splitCookiesString(c));
  }
  if (typeof cookiesString !== "string") {
    return [];
  }
  const cookiesStrings = [];
  let pos = 0;
  let start;
  let ch;
  let lastComma;
  let nextStart;
  let cookiesSeparatorFound;
  const skipWhitespace = () => {
    while (pos < cookiesString.length && /\s/.test(cookiesString.charAt(pos))) {
      pos += 1;
    }
    return pos < cookiesString.length;
  };
  const notSpecialChar = () => {
    ch = cookiesString.charAt(pos);
    return ch !== "=" && ch !== ";" && ch !== ",";
  };
  while (pos < cookiesString.length) {
    start = pos;
    cookiesSeparatorFound = false;
    while (skipWhitespace()) {
      ch = cookiesString.charAt(pos);
      if (ch === ",") {
        lastComma = pos;
        pos += 1;
        skipWhitespace();
        nextStart = pos;
        while (pos < cookiesString.length && notSpecialChar()) {
          pos += 1;
        }
        if (pos < cookiesString.length && cookiesString.charAt(pos) === "=") {
          cookiesSeparatorFound = true;
          pos = nextStart;
          cookiesStrings.push(cookiesString.slice(start, lastComma));
          start = pos;
        } else {
          pos = lastComma + 1;
        }
      } else {
        pos += 1;
      }
    }
    if (!cookiesSeparatorFound || pos >= cookiesString.length) {
      cookiesStrings.push(cookiesString.slice(start));
    }
  }
  return cookiesStrings;
}

const defer = typeof setImmediate === "undefined" ? (fn) => fn() : setImmediate;
function send(event, data, type) {
  if (type) {
    defaultContentType(event, type);
  }
  return new Promise((resolve) => {
    defer(() => {
      if (!event.handled) {
        event.node.res.end(data);
      }
      resolve();
    });
  });
}
function sendNoContent(event, code) {
  if (event.handled) {
    return;
  }
  if (!code && event.node.res.statusCode !== 200) {
    code = event.node.res.statusCode;
  }
  const _code = sanitizeStatusCode(code, 204);
  if (_code === 204) {
    event.node.res.removeHeader("content-length");
  }
  event.node.res.writeHead(_code);
  event.node.res.end();
}
function setResponseStatus(event, code, text) {
  if (code) {
    event.node.res.statusCode = sanitizeStatusCode(
      code,
      event.node.res.statusCode
    );
  }
  if (text) {
    event.node.res.statusMessage = sanitizeStatusMessage(text);
  }
}
function getResponseStatus(event) {
  return event.node.res.statusCode;
}
function defaultContentType(event, type) {
  if (type && event.node.res.statusCode !== 304 && !event.node.res.getHeader("content-type")) {
    event.node.res.setHeader("content-type", type);
  }
}
function sendRedirect(event, location, code = 302) {
  event.node.res.statusCode = sanitizeStatusCode(
    code,
    event.node.res.statusCode
  );
  event.node.res.setHeader("location", location);
  const encodedLoc = location.replace(/"/g, "%22");
  const html = `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0; url=${encodedLoc}"></head></html>`;
  return send(event, html, MIMES.html);
}
function getResponseHeader(event, name) {
  return event.node.res.getHeader(name);
}
function setResponseHeaders(event, headers) {
  for (const [name, value] of Object.entries(headers)) {
    event.node.res.setHeader(
      name,
      value
    );
  }
}
const setHeaders = setResponseHeaders;
function setResponseHeader(event, name, value) {
  event.node.res.setHeader(name, value);
}
const setHeader = setResponseHeader;
function appendResponseHeader(event, name, value) {
  let current = event.node.res.getHeader(name);
  if (!current) {
    event.node.res.setHeader(name, value);
    return;
  }
  if (!Array.isArray(current)) {
    current = [current.toString()];
  }
  event.node.res.setHeader(name, [...current, value]);
}
function removeResponseHeader(event, name) {
  return event.node.res.removeHeader(name);
}
function isStream(data) {
  if (!data || typeof data !== "object") {
    return false;
  }
  if (typeof data.pipe === "function") {
    if (typeof data._read === "function") {
      return true;
    }
    if (typeof data.abort === "function") {
      return true;
    }
  }
  if (typeof data.pipeTo === "function") {
    return true;
  }
  return false;
}
function isWebResponse(data) {
  return typeof Response !== "undefined" && data instanceof Response;
}
function sendStream(event, stream) {
  if (!stream || typeof stream !== "object") {
    throw new Error("[h3] Invalid stream provided.");
  }
  event.node.res._data = stream;
  if (!event.node.res.socket) {
    event._handled = true;
    return Promise.resolve();
  }
  if (hasProp(stream, "pipeTo") && typeof stream.pipeTo === "function") {
    return stream.pipeTo(
      new WritableStream({
        write(chunk) {
          event.node.res.write(chunk);
        }
      })
    ).then(() => {
      event.node.res.end();
    });
  }
  if (hasProp(stream, "pipe") && typeof stream.pipe === "function") {
    return new Promise((resolve, reject) => {
      stream.pipe(event.node.res);
      if (stream.on) {
        stream.on("end", () => {
          event.node.res.end();
          resolve();
        });
        stream.on("error", (error) => {
          reject(error);
        });
      }
      event.node.res.on("close", () => {
        if (stream.abort) {
          stream.abort();
        }
      });
    });
  }
  throw new Error("[h3] Invalid or incompatible stream provided.");
}
const noop = () => {
};
function writeEarlyHints(event, hints, cb = noop) {
  if (!event.node.res.socket) {
    cb();
    return;
  }
  if (typeof hints === "string" || Array.isArray(hints)) {
    hints = { link: hints };
  }
  if (hints.link) {
    hints.link = Array.isArray(hints.link) ? hints.link : hints.link.split(",");
  }
  const headers = Object.entries(hints).map(
    (e) => [e[0].toLowerCase(), e[1]]
  );
  if (headers.length === 0) {
    cb();
    return;
  }
  let hint = "HTTP/1.1 103 Early Hints";
  if (hints.link) {
    hint += `\r
Link: ${hints.link.join(", ")}`;
  }
  for (const [header, value] of headers) {
    if (header === "link") {
      continue;
    }
    hint += `\r
${header}: ${value}`;
  }
  if (event.node.res.socket) {
    event.node.res.socket.write(
      `${hint}\r
\r
`,
      "utf8",
      cb
    );
  } else {
    cb();
  }
}
function sendWebResponse(event, response) {
  for (const [key, value] of response.headers) {
    if (key === "set-cookie") {
      event.node.res.appendHeader(key, splitCookiesString(value));
    } else {
      event.node.res.setHeader(key, value);
    }
  }
  if (response.status) {
    event.node.res.statusCode = sanitizeStatusCode(
      response.status,
      event.node.res.statusCode
    );
  }
  if (response.statusText) {
    event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  }
  if (response.redirected) {
    event.node.res.setHeader("location", response.url);
  }
  if (!response.body) {
    event.node.res.end();
    return;
  }
  return sendStream(event, response.body);
}

const PayloadMethods = /* @__PURE__ */ new Set(["PATCH", "POST", "PUT", "DELETE"]);
const ignoredHeaders = /* @__PURE__ */ new Set([
  "transfer-encoding",
  "accept-encoding",
  "connection",
  "keep-alive",
  "upgrade",
  "expect",
  "host",
  "accept"
]);
async function proxyRequest(event, target, opts = {}) {
  let body;
  let duplex;
  if (PayloadMethods.has(event.method)) {
    if (opts.streamRequest) {
      body = getRequestWebStream(event);
      duplex = "half";
    } else {
      body = await readRawBody(event, false).catch(() => void 0);
    }
  }
  const method = opts.fetchOptions?.method || event.method;
  const fetchHeaders = mergeHeaders$1(
    getProxyRequestHeaders(event, { host: target.startsWith("/") }),
    opts.fetchOptions?.headers,
    opts.headers
  );
  return sendProxy(event, target, {
    ...opts,
    fetchOptions: {
      method,
      body,
      duplex,
      ...opts.fetchOptions,
      headers: fetchHeaders
    }
  });
}
async function sendProxy(event, target, opts = {}) {
  let response;
  try {
    response = await _getFetch(opts.fetch)(target, {
      headers: opts.headers,
      ignoreResponseError: true,
      // make $ofetch.raw transparent
      ...opts.fetchOptions
    });
  } catch (error) {
    throw createError$1({
      status: 502,
      statusMessage: "Bad Gateway",
      cause: error
    });
  }
  event.node.res.statusCode = sanitizeStatusCode(
    response.status,
    event.node.res.statusCode
  );
  event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  const cookies = [];
  for (const [key, value] of response.headers.entries()) {
    if (key === "content-encoding") {
      continue;
    }
    if (key === "content-length") {
      continue;
    }
    if (key === "set-cookie") {
      cookies.push(...splitCookiesString(value));
      continue;
    }
    event.node.res.setHeader(key, value);
  }
  if (cookies.length > 0) {
    event.node.res.setHeader(
      "set-cookie",
      cookies.map((cookie) => {
        if (opts.cookieDomainRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookieDomainRewrite,
            "domain"
          );
        }
        if (opts.cookiePathRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookiePathRewrite,
            "path"
          );
        }
        return cookie;
      })
    );
  }
  if (opts.onResponse) {
    await opts.onResponse(event, response);
  }
  if (response._data !== void 0) {
    return response._data;
  }
  if (event.handled) {
    return;
  }
  if (opts.sendStream === false) {
    const data = new Uint8Array(await response.arrayBuffer());
    return event.node.res.end(data);
  }
  if (response.body) {
    for await (const chunk of response.body) {
      event.node.res.write(chunk);
    }
  }
  return event.node.res.end();
}
function getProxyRequestHeaders(event, opts) {
  const headers = /* @__PURE__ */ Object.create(null);
  const reqHeaders = getRequestHeaders(event);
  for (const name in reqHeaders) {
    if (!ignoredHeaders.has(name) || name === "host" && opts?.host) {
      headers[name] = reqHeaders[name];
    }
  }
  return headers;
}
function fetchWithEvent$1(event, req, init, options) {
  return _getFetch(options?.fetch)(req, {
    ...init,
    context: init?.context || event.context,
    headers: {
      ...getProxyRequestHeaders(event, {
        host: typeof req === "string" && req.startsWith("/")
      }),
      ...init?.headers
    }
  });
}
function _getFetch(_fetch) {
  if (_fetch) {
    return _fetch;
  }
  if (globalThis.fetch) {
    return globalThis.fetch;
  }
  throw new Error(
    "fetch is not available. Try importing `node-fetch-native/polyfill` for Node.js."
  );
}
function rewriteCookieProperty(header, map, property) {
  const _map = typeof map === "string" ? { "*": map } : map;
  return header.replace(
    new RegExp(`(;\\s*${property}=)([^;]+)`, "gi"),
    (match, prefix, previousValue) => {
      let newValue;
      if (previousValue in _map) {
        newValue = _map[previousValue];
      } else if ("*" in _map) {
        newValue = _map["*"];
      } else {
        return match;
      }
      return newValue ? prefix + newValue : "";
    }
  );
}
function mergeHeaders$1(defaults, ...inputs) {
  const _inputs = inputs.filter(Boolean);
  if (_inputs.length === 0) {
    return defaults;
  }
  const merged = new Headers(defaults);
  for (const input of _inputs) {
    const entries = Array.isArray(input) ? input : typeof input.entries === "function" ? input.entries() : Object.entries(input);
    for (const [key, value] of entries) {
      if (value !== void 0) {
        merged.set(key, value);
      }
    }
  }
  return merged;
}

class H3Event {
  "__is_event__" = true;
  // Context
  node;
  // Node
  web;
  // Web
  context = {};
  // Shared
  // Request
  _method;
  _path;
  _headers;
  _requestBody;
  // Response
  _handled = false;
  // Hooks
  _onBeforeResponseCalled;
  _onAfterResponseCalled;
  constructor(req, res) {
    this.node = { req, res };
  }
  // --- Request ---
  get method() {
    if (!this._method) {
      this._method = (this.node.req.method || "GET").toUpperCase();
    }
    return this._method;
  }
  get path() {
    return this._path || this.node.req.url || "/";
  }
  get headers() {
    if (!this._headers) {
      this._headers = _normalizeNodeHeaders(this.node.req.headers);
    }
    return this._headers;
  }
  // --- Respoonse ---
  get handled() {
    return this._handled || this.node.res.writableEnded || this.node.res.headersSent;
  }
  respondWith(response) {
    return Promise.resolve(response).then(
      (_response) => sendWebResponse(this, _response)
    );
  }
  // --- Utils ---
  toString() {
    return `[${this.method}] ${this.path}`;
  }
  toJSON() {
    return this.toString();
  }
  // --- Deprecated ---
  /** @deprecated Please use `event.node.req` instead. */
  get req() {
    return this.node.req;
  }
  /** @deprecated Please use `event.node.res` instead. */
  get res() {
    return this.node.res;
  }
}
function isEvent(input) {
  return hasProp(input, "__is_event__");
}
function createEvent(req, res) {
  return new H3Event(req, res);
}
function _normalizeNodeHeaders(nodeHeaders) {
  const headers = new Headers();
  for (const [name, value] of Object.entries(nodeHeaders)) {
    if (Array.isArray(value)) {
      for (const item of value) {
        headers.append(name, item);
      }
    } else if (value) {
      headers.set(name, value);
    }
  }
  return headers;
}

function defineEventHandler(handler) {
  if (typeof handler === "function") {
    handler.__is_handler__ = true;
    return handler;
  }
  const _hooks = {
    onRequest: _normalizeArray(handler.onRequest),
    onBeforeResponse: _normalizeArray(handler.onBeforeResponse)
  };
  const _handler = (event) => {
    return _callHandler(event, handler.handler, _hooks);
  };
  _handler.__is_handler__ = true;
  _handler.__resolve__ = handler.handler.__resolve__;
  _handler.__websocket__ = handler.websocket;
  return _handler;
}
function _normalizeArray(input) {
  return input ? Array.isArray(input) ? input : [input] : void 0;
}
async function _callHandler(event, handler, hooks) {
  if (hooks.onRequest) {
    for (const hook of hooks.onRequest) {
      await hook(event);
      if (event.handled) {
        return;
      }
    }
  }
  const body = await handler(event);
  const response = { body };
  if (hooks.onBeforeResponse) {
    for (const hook of hooks.onBeforeResponse) {
      await hook(event, response);
    }
  }
  return response.body;
}
const eventHandler = defineEventHandler;
function isEventHandler(input) {
  return hasProp(input, "__is_handler__");
}
function toEventHandler(input, _, _route) {
  return input;
}
function defineLazyEventHandler(factory) {
  let _promise;
  let _resolved;
  const resolveHandler = () => {
    if (_resolved) {
      return Promise.resolve(_resolved);
    }
    if (!_promise) {
      _promise = Promise.resolve(factory()).then((r) => {
        const handler2 = r.default || r;
        if (typeof handler2 !== "function") {
          throw new TypeError(
            "Invalid lazy handler result. It should be a function:",
            handler2
          );
        }
        _resolved = { handler: toEventHandler(r.default || r) };
        return _resolved;
      });
    }
    return _promise;
  };
  const handler = eventHandler((event) => {
    if (_resolved) {
      return _resolved.handler(event);
    }
    return resolveHandler().then((r) => r.handler(event));
  });
  handler.__resolve__ = resolveHandler;
  return handler;
}
const lazyEventHandler = defineLazyEventHandler;

function createApp(options = {}) {
  const stack = [];
  const handler = createAppEventHandler(stack, options);
  const resolve = createResolver(stack);
  handler.__resolve__ = resolve;
  const getWebsocket = cachedFn(() => websocketOptions(resolve, options));
  const app = {
    // @ts-expect-error
    use: (arg1, arg2, arg3) => use(app, arg1, arg2, arg3),
    resolve,
    handler,
    stack,
    options,
    get websocket() {
      return getWebsocket();
    }
  };
  return app;
}
function use(app, arg1, arg2, arg3) {
  if (Array.isArray(arg1)) {
    for (const i of arg1) {
      use(app, i, arg2, arg3);
    }
  } else if (Array.isArray(arg2)) {
    for (const i of arg2) {
      use(app, arg1, i, arg3);
    }
  } else if (typeof arg1 === "string") {
    app.stack.push(
      normalizeLayer({ ...arg3, route: arg1, handler: arg2 })
    );
  } else if (typeof arg1 === "function") {
    app.stack.push(normalizeLayer({ ...arg2, handler: arg1 }));
  } else {
    app.stack.push(normalizeLayer({ ...arg1 }));
  }
  return app;
}
function createAppEventHandler(stack, options) {
  const spacing = options.debug ? 2 : void 0;
  return eventHandler(async (event) => {
    event.node.req.originalUrl = event.node.req.originalUrl || event.node.req.url || "/";
    const _rawReqUrl = event.node.req.url || "/";
    const _reqPath = _decodePath(event._path || _rawReqUrl);
    event._path = _reqPath;
    const _needsRawUrl = _reqPath !== _rawReqUrl;
    let _layerPath;
    if (options.onRequest) {
      await options.onRequest(event);
    }
    for (const layer of stack) {
      if (layer.route.length > 1) {
        if (!_reqPath.startsWith(layer.route)) {
          continue;
        }
        _layerPath = _reqPath.slice(layer.route.length) || "/";
      } else {
        _layerPath = _reqPath;
      }
      if (layer.match && !layer.match(_layerPath, event)) {
        continue;
      }
      event._path = _layerPath;
      event.node.req.url = _needsRawUrl ? layer.route.length > 1 ? _rawReqUrl.slice(layer.route.length) || "/" : _rawReqUrl : _layerPath;
      const val = await layer.handler(event);
      const _body = val === void 0 ? void 0 : await val;
      if (_body !== void 0) {
        const _response = { body: _body };
        if (options.onBeforeResponse) {
          event._onBeforeResponseCalled = true;
          await options.onBeforeResponse(event, _response);
        }
        await handleHandlerResponse(event, _response.body, spacing);
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, _response);
        }
        return;
      }
      if (event.handled) {
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, void 0);
        }
        return;
      }
    }
    if (!event.handled) {
      throw createError$1({
        statusCode: 404,
        statusMessage: `Cannot find any path matching ${event.path || "/"}.`
      });
    }
    if (options.onAfterResponse) {
      event._onAfterResponseCalled = true;
      await options.onAfterResponse(event, void 0);
    }
  });
}
function createResolver(stack) {
  return async (path) => {
    let _layerPath;
    for (const layer of stack) {
      if (layer.route === "/" && !layer.handler.__resolve__) {
        continue;
      }
      if (!path.startsWith(layer.route)) {
        continue;
      }
      _layerPath = path.slice(layer.route.length) || "/";
      if (layer.match && !layer.match(_layerPath, void 0)) {
        continue;
      }
      let res = { route: layer.route, handler: layer.handler };
      if (res.handler.__resolve__) {
        const _res = await res.handler.__resolve__(_layerPath);
        if (!_res) {
          continue;
        }
        res = {
          ...res,
          ..._res,
          route: joinURL(res.route || "/", _res.route || "/")
        };
      }
      return res;
    }
  };
}
function normalizeLayer(input) {
  let handler = input.handler;
  if (handler.handler) {
    handler = handler.handler;
  }
  if (input.lazy) {
    handler = lazyEventHandler(handler);
  } else if (!isEventHandler(handler)) {
    handler = toEventHandler(handler, void 0, input.route);
  }
  return {
    route: withoutTrailingSlash(input.route),
    match: input.match,
    handler
  };
}
function handleHandlerResponse(event, val, jsonSpace) {
  if (val === null) {
    return sendNoContent(event);
  }
  if (val) {
    if (isWebResponse(val)) {
      return sendWebResponse(event, val);
    }
    if (isStream(val)) {
      return sendStream(event, val);
    }
    if (val.buffer) {
      return send(event, val);
    }
    if (val.arrayBuffer && typeof val.arrayBuffer === "function") {
      return val.arrayBuffer().then((arrayBuffer) => {
        return send(event, Buffer.from(arrayBuffer), val.type);
      });
    }
    if (val instanceof Error) {
      throw createError$1(val);
    }
    if (typeof val.end === "function") {
      return true;
    }
  }
  const valType = typeof val;
  if (valType === "string") {
    return send(event, val, MIMES.html);
  }
  if (valType === "object" || valType === "boolean" || valType === "number") {
    return send(event, JSON.stringify(val, void 0, jsonSpace), MIMES.json);
  }
  if (valType === "bigint") {
    return send(event, val.toString(), MIMES.json);
  }
  throw createError$1({
    statusCode: 500,
    statusMessage: `[h3] Cannot send ${valType} as response.`
  });
}
function cachedFn(fn) {
  let cache;
  return () => {
    if (!cache) {
      cache = fn();
    }
    return cache;
  };
}
function _decodePath(url) {
  const qIndex = url.indexOf("?");
  const path = qIndex === -1 ? url : url.slice(0, qIndex);
  const query = qIndex === -1 ? "" : url.slice(qIndex);
  const decodedPath = path.includes("%25") ? decodePath(path.replace(/%25/g, "%2525")) : decodePath(path);
  return decodedPath + query;
}
function websocketOptions(evResolver, appOptions) {
  return {
    ...appOptions.websocket,
    async resolve(info) {
      const url = info.request?.url || info.url || "/";
      const { pathname } = typeof url === "string" ? parseURL(url) : url;
      const resolved = await evResolver(pathname);
      return resolved?.handler?.__websocket__ || {};
    }
  };
}

const RouterMethods = [
  "connect",
  "delete",
  "get",
  "head",
  "options",
  "post",
  "put",
  "trace",
  "patch"
];
function createRouter(opts = {}) {
  const _router = createRouter$1({});
  const routes = {};
  let _matcher;
  const router = {};
  const addRoute = (path, handler, method) => {
    let route = routes[path];
    if (!route) {
      routes[path] = route = { path, handlers: {} };
      _router.insert(path, route);
    }
    if (Array.isArray(method)) {
      for (const m of method) {
        addRoute(path, handler, m);
      }
    } else {
      route.handlers[method] = toEventHandler(handler);
    }
    return router;
  };
  router.use = router.add = (path, handler, method) => addRoute(path, handler, method || "all");
  for (const method of RouterMethods) {
    router[method] = (path, handle) => router.add(path, handle, method);
  }
  const matchHandler = (path = "/", method = "get") => {
    const qIndex = path.indexOf("?");
    if (qIndex !== -1) {
      path = path.slice(0, Math.max(0, qIndex));
    }
    const matched = _router.lookup(path);
    if (!matched || !matched.handlers) {
      return {
        error: createError$1({
          statusCode: 404,
          name: "Not Found",
          statusMessage: `Cannot find any route matching ${path || "/"}.`
        })
      };
    }
    let handler = matched.handlers[method] || matched.handlers.all;
    if (!handler) {
      if (!_matcher) {
        _matcher = toRouteMatcher(_router);
      }
      const _matches = _matcher.matchAll(path).reverse();
      for (const _match of _matches) {
        if (_match.handlers[method]) {
          handler = _match.handlers[method];
          matched.handlers[method] = matched.handlers[method] || handler;
          break;
        }
        if (_match.handlers.all) {
          handler = _match.handlers.all;
          matched.handlers.all = matched.handlers.all || handler;
          break;
        }
      }
    }
    if (!handler) {
      return {
        error: createError$1({
          statusCode: 405,
          name: "Method Not Allowed",
          statusMessage: `Method ${method} is not allowed on this route.`
        })
      };
    }
    return { matched, handler };
  };
  const isPreemptive = opts.preemptive || opts.preemtive;
  router.handler = eventHandler((event) => {
    const match = matchHandler(
      event.path,
      event.method.toLowerCase()
    );
    if ("error" in match) {
      if (isPreemptive) {
        throw match.error;
      } else {
        return;
      }
    }
    event.context.matchedRoute = match.matched;
    const params = match.matched.params || {};
    event.context.params = params;
    return Promise.resolve(match.handler(event)).then((res) => {
      if (res === void 0 && isPreemptive) {
        return null;
      }
      return res;
    });
  });
  router.handler.__resolve__ = async (path) => {
    path = withLeadingSlash(path);
    const match = matchHandler(path);
    if ("error" in match) {
      return;
    }
    let res = {
      route: match.matched.path,
      handler: match.handler
    };
    if (match.handler.__resolve__) {
      const _res = await match.handler.__resolve__(path);
      if (!_res) {
        return;
      }
      res = { ...res, ..._res };
    }
    return res;
  };
  return router;
}
function toNodeListener(app) {
  const toNodeHandle = async function(req, res) {
    const event = createEvent(req, res);
    try {
      await app.handler(event);
    } catch (_error) {
      const error = createError$1(_error);
      if (!isError(_error)) {
        error.unhandled = true;
      }
      setResponseStatus(event, error.statusCode, error.statusMessage);
      if (app.options.onError) {
        await app.options.onError(error, event);
      }
      if (event.handled) {
        return;
      }
      if (error.unhandled || error.fatal) {
        console.error("[h3]", error.fatal ? "[fatal]" : "[unhandled]", error);
      }
      if (app.options.onBeforeResponse && !event._onBeforeResponseCalled) {
        await app.options.onBeforeResponse(event, { body: error });
      }
      await sendError(event, error, !!app.options.debug);
      if (app.options.onAfterResponse && !event._onAfterResponseCalled) {
        await app.options.onAfterResponse(event, { body: error });
      }
    }
  };
  return toNodeHandle;
}

function flatHooks(configHooks, hooks = {}, parentName) {
  for (const key in configHooks) {
    const subHook = configHooks[key];
    const name = parentName ? `${parentName}:${key}` : key;
    if (typeof subHook === "object" && subHook !== null) {
      flatHooks(subHook, hooks, name);
    } else if (typeof subHook === "function") {
      hooks[name] = subHook;
    }
  }
  return hooks;
}
const defaultTask = { run: (function_) => function_() };
const _createTask = () => defaultTask;
const createTask = typeof console.createTask !== "undefined" ? console.createTask : _createTask;
function serialTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return hooks.reduce(
    (promise, hookFunction) => promise.then(() => task.run(() => hookFunction(...args))),
    Promise.resolve()
  );
}
function parallelTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return Promise.all(hooks.map((hook) => task.run(() => hook(...args))));
}
function callEachWith(callbacks, arg0) {
  for (const callback of [...callbacks]) {
    callback(arg0);
  }
}

class Hookable {
  constructor() {
    this._hooks = {};
    this._before = void 0;
    this._after = void 0;
    this._deprecatedMessages = void 0;
    this._deprecatedHooks = {};
    this.hook = this.hook.bind(this);
    this.callHook = this.callHook.bind(this);
    this.callHookWith = this.callHookWith.bind(this);
  }
  hook(name, function_, options = {}) {
    if (!name || typeof function_ !== "function") {
      return () => {
      };
    }
    const originalName = name;
    let dep;
    while (this._deprecatedHooks[name]) {
      dep = this._deprecatedHooks[name];
      name = dep.to;
    }
    if (dep && !options.allowDeprecated) {
      let message = dep.message;
      if (!message) {
        message = `${originalName} hook has been deprecated` + (dep.to ? `, please use ${dep.to}` : "");
      }
      if (!this._deprecatedMessages) {
        this._deprecatedMessages = /* @__PURE__ */ new Set();
      }
      if (!this._deprecatedMessages.has(message)) {
        console.warn(message);
        this._deprecatedMessages.add(message);
      }
    }
    if (!function_.name) {
      try {
        Object.defineProperty(function_, "name", {
          get: () => "_" + name.replace(/\W+/g, "_") + "_hook_cb",
          configurable: true
        });
      } catch {
      }
    }
    this._hooks[name] = this._hooks[name] || [];
    this._hooks[name].push(function_);
    return () => {
      if (function_) {
        this.removeHook(name, function_);
        function_ = void 0;
      }
    };
  }
  hookOnce(name, function_) {
    let _unreg;
    let _function = (...arguments_) => {
      if (typeof _unreg === "function") {
        _unreg();
      }
      _unreg = void 0;
      _function = void 0;
      return function_(...arguments_);
    };
    _unreg = this.hook(name, _function);
    return _unreg;
  }
  removeHook(name, function_) {
    if (this._hooks[name]) {
      const index = this._hooks[name].indexOf(function_);
      if (index !== -1) {
        this._hooks[name].splice(index, 1);
      }
      if (this._hooks[name].length === 0) {
        delete this._hooks[name];
      }
    }
  }
  deprecateHook(name, deprecated) {
    this._deprecatedHooks[name] = typeof deprecated === "string" ? { to: deprecated } : deprecated;
    const _hooks = this._hooks[name] || [];
    delete this._hooks[name];
    for (const hook of _hooks) {
      this.hook(name, hook);
    }
  }
  deprecateHooks(deprecatedHooks) {
    Object.assign(this._deprecatedHooks, deprecatedHooks);
    for (const name in deprecatedHooks) {
      this.deprecateHook(name, deprecatedHooks[name]);
    }
  }
  addHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    const removeFns = Object.keys(hooks).map(
      (key) => this.hook(key, hooks[key])
    );
    return () => {
      for (const unreg of removeFns.splice(0, removeFns.length)) {
        unreg();
      }
    };
  }
  removeHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    for (const key in hooks) {
      this.removeHook(key, hooks[key]);
    }
  }
  removeAllHooks() {
    for (const key in this._hooks) {
      delete this._hooks[key];
    }
  }
  callHook(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(serialTaskCaller, name, ...arguments_);
  }
  callHookParallel(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(parallelTaskCaller, name, ...arguments_);
  }
  callHookWith(caller, name, ...arguments_) {
    const event = this._before || this._after ? { name, args: arguments_, context: {} } : void 0;
    if (this._before) {
      callEachWith(this._before, event);
    }
    const result = caller(
      name in this._hooks ? [...this._hooks[name]] : [],
      arguments_
    );
    if (result instanceof Promise) {
      return result.finally(() => {
        if (this._after && event) {
          callEachWith(this._after, event);
        }
      });
    }
    if (this._after && event) {
      callEachWith(this._after, event);
    }
    return result;
  }
  beforeEach(function_) {
    this._before = this._before || [];
    this._before.push(function_);
    return () => {
      if (this._before !== void 0) {
        const index = this._before.indexOf(function_);
        if (index !== -1) {
          this._before.splice(index, 1);
        }
      }
    };
  }
  afterEach(function_) {
    this._after = this._after || [];
    this._after.push(function_);
    return () => {
      if (this._after !== void 0) {
        const index = this._after.indexOf(function_);
        if (index !== -1) {
          this._after.splice(index, 1);
        }
      }
    };
  }
}
function createHooks() {
  return new Hookable();
}

const s=globalThis.Headers,i=globalThis.AbortController,l=globalThis.fetch||(()=>{throw new Error("[node-fetch-native] Failed to fetch: `globalThis.fetch` is not available!")});

class FetchError extends Error {
  constructor(message, opts) {
    super(message, opts);
    this.name = "FetchError";
    if (opts?.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
}
function createFetchError(ctx) {
  const errorMessage = ctx.error?.message || ctx.error?.toString() || "";
  const method = ctx.request?.method || ctx.options?.method || "GET";
  const url = ctx.request?.url || String(ctx.request) || "/";
  const requestStr = `[${method}] ${JSON.stringify(url)}`;
  const statusStr = ctx.response ? `${ctx.response.status} ${ctx.response.statusText}` : "<no response>";
  const message = `${requestStr}: ${statusStr}${errorMessage ? ` ${errorMessage}` : ""}`;
  const fetchError = new FetchError(
    message,
    ctx.error ? { cause: ctx.error } : void 0
  );
  for (const key of ["request", "options", "response"]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx[key];
      }
    });
  }
  for (const [key, refKey] of [
    ["data", "_data"],
    ["status", "status"],
    ["statusCode", "status"],
    ["statusText", "statusText"],
    ["statusMessage", "statusText"]
  ]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx.response && ctx.response[refKey];
      }
    });
  }
  return fetchError;
}

const payloadMethods = new Set(
  Object.freeze(["PATCH", "POST", "PUT", "DELETE"])
);
function isPayloadMethod(method = "GET") {
  return payloadMethods.has(method.toUpperCase());
}
function isJSONSerializable(value) {
  if (value === void 0) {
    return false;
  }
  const t = typeof value;
  if (t === "string" || t === "number" || t === "boolean" || t === null) {
    return true;
  }
  if (t !== "object") {
    return false;
  }
  if (Array.isArray(value)) {
    return true;
  }
  if (value.buffer) {
    return false;
  }
  if (value instanceof FormData || value instanceof URLSearchParams) {
    return false;
  }
  return value.constructor && value.constructor.name === "Object" || typeof value.toJSON === "function";
}
const textTypes = /* @__PURE__ */ new Set([
  "image/svg",
  "application/xml",
  "application/xhtml",
  "application/html"
]);
const JSON_RE = /^application\/(?:[\w!#$%&*.^`~-]*\+)?json(;.+)?$/i;
function detectResponseType(_contentType = "") {
  if (!_contentType) {
    return "json";
  }
  const contentType = _contentType.split(";").shift() || "";
  if (JSON_RE.test(contentType)) {
    return "json";
  }
  if (contentType === "text/event-stream") {
    return "stream";
  }
  if (textTypes.has(contentType) || contentType.startsWith("text/")) {
    return "text";
  }
  return "blob";
}
function resolveFetchOptions(request, input, defaults, Headers) {
  const headers = mergeHeaders(
    input?.headers ?? request?.headers,
    defaults?.headers,
    Headers
  );
  let query;
  if (defaults?.query || defaults?.params || input?.params || input?.query) {
    query = {
      ...defaults?.params,
      ...defaults?.query,
      ...input?.params,
      ...input?.query
    };
  }
  return {
    ...defaults,
    ...input,
    query,
    params: query,
    headers
  };
}
function mergeHeaders(input, defaults, Headers) {
  if (!defaults) {
    return new Headers(input);
  }
  const headers = new Headers(defaults);
  if (input) {
    for (const [key, value] of Symbol.iterator in input || Array.isArray(input) ? input : new Headers(input)) {
      headers.set(key, value);
    }
  }
  return headers;
}
async function callHooks(context, hooks) {
  if (hooks) {
    if (Array.isArray(hooks)) {
      for (const hook of hooks) {
        await hook(context);
      }
    } else {
      await hooks(context);
    }
  }
}

const retryStatusCodes = /* @__PURE__ */ new Set([
  408,
  // Request Timeout
  409,
  // Conflict
  425,
  // Too Early (Experimental)
  429,
  // Too Many Requests
  500,
  // Internal Server Error
  502,
  // Bad Gateway
  503,
  // Service Unavailable
  504
  // Gateway Timeout
]);
const nullBodyResponses = /* @__PURE__ */ new Set([101, 204, 205, 304]);
function createFetch(globalOptions = {}) {
  const {
    fetch = globalThis.fetch,
    Headers = globalThis.Headers,
    AbortController = globalThis.AbortController
  } = globalOptions;
  async function onError(context) {
    const isAbort = context.error && context.error.name === "AbortError" && !context.options.timeout || false;
    if (context.options.retry !== false && !isAbort) {
      let retries;
      if (typeof context.options.retry === "number") {
        retries = context.options.retry;
      } else {
        retries = isPayloadMethod(context.options.method) ? 0 : 1;
      }
      const responseCode = context.response && context.response.status || 500;
      if (retries > 0 && (Array.isArray(context.options.retryStatusCodes) ? context.options.retryStatusCodes.includes(responseCode) : retryStatusCodes.has(responseCode))) {
        const retryDelay = typeof context.options.retryDelay === "function" ? context.options.retryDelay(context) : context.options.retryDelay || 0;
        if (retryDelay > 0) {
          await new Promise((resolve) => setTimeout(resolve, retryDelay));
        }
        return $fetchRaw(context.request, {
          ...context.options,
          retry: retries - 1
        });
      }
    }
    const error = createFetchError(context);
    if (Error.captureStackTrace) {
      Error.captureStackTrace(error, $fetchRaw);
    }
    throw error;
  }
  const $fetchRaw = async function $fetchRaw2(_request, _options = {}) {
    const context = {
      request: _request,
      options: resolveFetchOptions(
        _request,
        _options,
        globalOptions.defaults,
        Headers
      ),
      response: void 0,
      error: void 0
    };
    if (context.options.method) {
      context.options.method = context.options.method.toUpperCase();
    }
    if (context.options.onRequest) {
      await callHooks(context, context.options.onRequest);
      if (!(context.options.headers instanceof Headers)) {
        context.options.headers = new Headers(
          context.options.headers || {}
          /* compat */
        );
      }
    }
    if (typeof context.request === "string") {
      if (context.options.baseURL) {
        context.request = withBase(context.request, context.options.baseURL);
      }
      if (context.options.query) {
        context.request = withQuery(context.request, context.options.query);
        delete context.options.query;
      }
      if ("query" in context.options) {
        delete context.options.query;
      }
      if ("params" in context.options) {
        delete context.options.params;
      }
    }
    if (context.options.body && isPayloadMethod(context.options.method)) {
      if (isJSONSerializable(context.options.body)) {
        const contentType = context.options.headers.get("content-type");
        if (typeof context.options.body !== "string") {
          context.options.body = contentType === "application/x-www-form-urlencoded" ? new URLSearchParams(
            context.options.body
          ).toString() : JSON.stringify(context.options.body);
        }
        if (!contentType) {
          context.options.headers.set("content-type", "application/json");
        }
        if (!context.options.headers.has("accept")) {
          context.options.headers.set("accept", "application/json");
        }
      } else if (
        // ReadableStream Body
        "pipeTo" in context.options.body && typeof context.options.body.pipeTo === "function" || // Node.js Stream Body
        typeof context.options.body.pipe === "function"
      ) {
        if (!("duplex" in context.options)) {
          context.options.duplex = "half";
        }
      }
    }
    let abortTimeout;
    if (!context.options.signal && context.options.timeout) {
      const controller = new AbortController();
      abortTimeout = setTimeout(() => {
        const error = new Error(
          "[TimeoutError]: The operation was aborted due to timeout"
        );
        error.name = "TimeoutError";
        error.code = 23;
        controller.abort(error);
      }, context.options.timeout);
      context.options.signal = controller.signal;
    }
    try {
      context.response = await fetch(
        context.request,
        context.options
      );
    } catch (error) {
      context.error = error;
      if (context.options.onRequestError) {
        await callHooks(
          context,
          context.options.onRequestError
        );
      }
      return await onError(context);
    } finally {
      if (abortTimeout) {
        clearTimeout(abortTimeout);
      }
    }
    const hasBody = (context.response.body || // https://github.com/unjs/ofetch/issues/324
    // https://github.com/unjs/ofetch/issues/294
    // https://github.com/JakeChampion/fetch/issues/1454
    context.response._bodyInit) && !nullBodyResponses.has(context.response.status) && context.options.method !== "HEAD";
    if (hasBody) {
      const responseType = (context.options.parseResponse ? "json" : context.options.responseType) || detectResponseType(context.response.headers.get("content-type") || "");
      switch (responseType) {
        case "json": {
          const data = await context.response.text();
          const parseFunction = context.options.parseResponse || destr;
          context.response._data = parseFunction(data);
          break;
        }
        case "stream": {
          context.response._data = context.response.body || context.response._bodyInit;
          break;
        }
        default: {
          context.response._data = await context.response[responseType]();
        }
      }
    }
    if (context.options.onResponse) {
      await callHooks(
        context,
        context.options.onResponse
      );
    }
    if (!context.options.ignoreResponseError && context.response.status >= 400 && context.response.status < 600) {
      if (context.options.onResponseError) {
        await callHooks(
          context,
          context.options.onResponseError
        );
      }
      return await onError(context);
    }
    return context.response;
  };
  const $fetch = async function $fetch2(request, options) {
    const r = await $fetchRaw(request, options);
    return r._data;
  };
  $fetch.raw = $fetchRaw;
  $fetch.native = (...args) => fetch(...args);
  $fetch.create = (defaultOptions = {}, customGlobalOptions = {}) => createFetch({
    ...globalOptions,
    ...customGlobalOptions,
    defaults: {
      ...globalOptions.defaults,
      ...customGlobalOptions.defaults,
      ...defaultOptions
    }
  });
  return $fetch;
}

function createNodeFetch() {
  const useKeepAlive = JSON.parse(process.env.FETCH_KEEP_ALIVE || "false");
  if (!useKeepAlive) {
    return l;
  }
  const agentOptions = { keepAlive: true };
  const httpAgent = new http.Agent(agentOptions);
  const httpsAgent = new https.Agent(agentOptions);
  const nodeFetchOptions = {
    agent(parsedURL) {
      return parsedURL.protocol === "http:" ? httpAgent : httpsAgent;
    }
  };
  return function nodeFetchWithKeepAlive(input, init) {
    return l(input, { ...nodeFetchOptions, ...init });
  };
}
const fetch = globalThis.fetch ? (...args) => globalThis.fetch(...args) : createNodeFetch();
const Headers$1 = globalThis.Headers || s;
const AbortController$1 = globalThis.AbortController || i;
const ofetch = createFetch({ fetch, Headers: Headers$1, AbortController: AbortController$1 });
const $fetch = ofetch;

function wrapToPromise(value) {
  if (!value || typeof value.then !== "function") {
    return Promise.resolve(value);
  }
  return value;
}
function asyncCall(function_, ...arguments_) {
  try {
    return wrapToPromise(function_(...arguments_));
  } catch (error) {
    return Promise.reject(error);
  }
}
function isPrimitive$1(value) {
  const type = typeof value;
  return value === null || type !== "object" && type !== "function";
}
function isPureObject(value) {
  const proto = Object.getPrototypeOf(value);
  return !proto || proto.isPrototypeOf(Object);
}
function stringify(value) {
  if (isPrimitive$1(value)) {
    return String(value);
  }
  if (isPureObject(value) || Array.isArray(value)) {
    return JSON.stringify(value);
  }
  if (typeof value.toJSON === "function") {
    return stringify(value.toJSON());
  }
  throw new Error("[unstorage] Cannot stringify value!");
}
const BASE64_PREFIX = "base64:";
function serializeRaw(value) {
  if (typeof value === "string") {
    return value;
  }
  return BASE64_PREFIX + base64Encode(value);
}
function deserializeRaw(value) {
  if (typeof value !== "string") {
    return value;
  }
  if (!value.startsWith(BASE64_PREFIX)) {
    return value;
  }
  return base64Decode(value.slice(BASE64_PREFIX.length));
}
function base64Decode(input) {
  if (globalThis.Buffer) {
    return Buffer.from(input, "base64");
  }
  return Uint8Array.from(
    globalThis.atob(input),
    (c) => c.codePointAt(0)
  );
}
function base64Encode(input) {
  if (globalThis.Buffer) {
    return Buffer.from(input).toString("base64");
  }
  return globalThis.btoa(String.fromCodePoint(...input));
}

const storageKeyProperties = [
  "has",
  "hasItem",
  "get",
  "getItem",
  "getItemRaw",
  "set",
  "setItem",
  "setItemRaw",
  "del",
  "remove",
  "removeItem",
  "getMeta",
  "setMeta",
  "removeMeta",
  "getKeys",
  "clear",
  "mount",
  "unmount"
];
function prefixStorage(storage, base) {
  base = normalizeBaseKey(base);
  if (!base) {
    return storage;
  }
  const nsStorage = { ...storage };
  for (const property of storageKeyProperties) {
    nsStorage[property] = (key = "", ...args) => (
      // @ts-ignore
      storage[property](base + key, ...args)
    );
  }
  nsStorage.getKeys = (key = "", ...arguments_) => storage.getKeys(base + key, ...arguments_).then((keys) => keys.map((key2) => key2.slice(base.length)));
  nsStorage.keys = nsStorage.getKeys;
  nsStorage.getItems = async (items, commonOptions) => {
    const prefixedItems = items.map(
      (item) => typeof item === "string" ? base + item : { ...item, key: base + item.key }
    );
    const results = await storage.getItems(prefixedItems, commonOptions);
    return results.map((entry) => ({
      key: entry.key.slice(base.length),
      value: entry.value
    }));
  };
  nsStorage.setItems = async (items, commonOptions) => {
    const prefixedItems = items.map((item) => ({
      key: base + item.key,
      value: item.value,
      options: item.options
    }));
    return storage.setItems(prefixedItems, commonOptions);
  };
  return nsStorage;
}
function normalizeKey$1(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
}
function joinKeys(...keys) {
  return normalizeKey$1(keys.join(":"));
}
function normalizeBaseKey(base) {
  base = normalizeKey$1(base);
  return base ? base + ":" : "";
}
function filterKeyByDepth(key, depth) {
  if (depth === void 0) {
    return true;
  }
  let substrCount = 0;
  let index = key.indexOf(":");
  while (index > -1) {
    substrCount++;
    index = key.indexOf(":", index + 1);
  }
  return substrCount <= depth;
}
function filterKeyByBase(key, base) {
  if (base) {
    return key.startsWith(base) && key[key.length - 1] !== "$";
  }
  return key[key.length - 1] !== "$";
}

function defineDriver$1(factory) {
  return factory;
}

const DRIVER_NAME$1 = "memory";
const memory = defineDriver$1(() => {
  const data = /* @__PURE__ */ new Map();
  return {
    name: DRIVER_NAME$1,
    getInstance: () => data,
    hasItem(key) {
      return data.has(key);
    },
    getItem(key) {
      return data.get(key) ?? null;
    },
    getItemRaw(key) {
      return data.get(key) ?? null;
    },
    setItem(key, value) {
      data.set(key, value);
    },
    setItemRaw(key, value) {
      data.set(key, value);
    },
    removeItem(key) {
      data.delete(key);
    },
    getKeys() {
      return [...data.keys()];
    },
    clear() {
      data.clear();
    },
    dispose() {
      data.clear();
    }
  };
});

function createStorage(options = {}) {
  const context = {
    mounts: { "": options.driver || memory() },
    mountpoints: [""],
    watching: false,
    watchListeners: [],
    unwatch: {}
  };
  const getMount = (key) => {
    for (const base of context.mountpoints) {
      if (key.startsWith(base)) {
        return {
          base,
          relativeKey: key.slice(base.length),
          driver: context.mounts[base]
        };
      }
    }
    return {
      base: "",
      relativeKey: key,
      driver: context.mounts[""]
    };
  };
  const getMounts = (base, includeParent) => {
    return context.mountpoints.filter(
      (mountpoint) => mountpoint.startsWith(base) || includeParent && base.startsWith(mountpoint)
    ).map((mountpoint) => ({
      relativeBase: base.length > mountpoint.length ? base.slice(mountpoint.length) : void 0,
      mountpoint,
      driver: context.mounts[mountpoint]
    }));
  };
  const onChange = (event, key) => {
    if (!context.watching) {
      return;
    }
    key = normalizeKey$1(key);
    for (const listener of context.watchListeners) {
      listener(event, key);
    }
  };
  const startWatch = async () => {
    if (context.watching) {
      return;
    }
    context.watching = true;
    for (const mountpoint in context.mounts) {
      context.unwatch[mountpoint] = await watch(
        context.mounts[mountpoint],
        onChange,
        mountpoint
      );
    }
  };
  const stopWatch = async () => {
    if (!context.watching) {
      return;
    }
    for (const mountpoint in context.unwatch) {
      await context.unwatch[mountpoint]();
    }
    context.unwatch = {};
    context.watching = false;
  };
  const runBatch = (items, commonOptions, cb) => {
    const batches = /* @__PURE__ */ new Map();
    const getBatch = (mount) => {
      let batch = batches.get(mount.base);
      if (!batch) {
        batch = {
          driver: mount.driver,
          base: mount.base,
          items: []
        };
        batches.set(mount.base, batch);
      }
      return batch;
    };
    for (const item of items) {
      const isStringItem = typeof item === "string";
      const key = normalizeKey$1(isStringItem ? item : item.key);
      const value = isStringItem ? void 0 : item.value;
      const options2 = isStringItem || !item.options ? commonOptions : { ...commonOptions, ...item.options };
      const mount = getMount(key);
      getBatch(mount).items.push({
        key,
        value,
        relativeKey: mount.relativeKey,
        options: options2
      });
    }
    return Promise.all([...batches.values()].map((batch) => cb(batch))).then(
      (r) => r.flat()
    );
  };
  const storage = {
    // Item
    hasItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.hasItem, relativeKey, opts);
    },
    getItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => destr(value)
      );
    },
    getItems(items, commonOptions = {}) {
      return runBatch(items, commonOptions, (batch) => {
        if (batch.driver.getItems) {
          return asyncCall(
            batch.driver.getItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              options: item.options
            })),
            commonOptions
          ).then(
            (r) => r.map((item) => ({
              key: joinKeys(batch.base, item.key),
              value: destr(item.value)
            }))
          );
        }
        return Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.getItem,
              item.relativeKey,
              item.options
            ).then((value) => ({
              key: item.key,
              value: destr(value)
            }));
          })
        );
      });
    },
    getItemRaw(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.getItemRaw) {
        return asyncCall(driver.getItemRaw, relativeKey, opts);
      }
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => deserializeRaw(value)
      );
    },
    async setItem(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.setItem) {
        return;
      }
      await asyncCall(driver.setItem, relativeKey, stringify(value), opts);
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async setItems(items, commonOptions) {
      await runBatch(items, commonOptions, async (batch) => {
        if (batch.driver.setItems) {
          return asyncCall(
            batch.driver.setItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              value: stringify(item.value),
              options: item.options
            })),
            commonOptions
          );
        }
        if (!batch.driver.setItem) {
          return;
        }
        await Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.setItem,
              item.relativeKey,
              stringify(item.value),
              item.options
            );
          })
        );
      });
    },
    async setItemRaw(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key, opts);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.setItemRaw) {
        await asyncCall(driver.setItemRaw, relativeKey, value, opts);
      } else if (driver.setItem) {
        await asyncCall(driver.setItem, relativeKey, serializeRaw(value), opts);
      } else {
        return;
      }
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async removeItem(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { removeMeta: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.removeItem) {
        return;
      }
      await asyncCall(driver.removeItem, relativeKey, opts);
      if (opts.removeMeta || opts.removeMata) {
        await asyncCall(driver.removeItem, relativeKey + "$", opts);
      }
      if (!driver.watch) {
        onChange("remove", key);
      }
    },
    // Meta
    async getMeta(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { nativeOnly: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      const meta = /* @__PURE__ */ Object.create(null);
      if (driver.getMeta) {
        Object.assign(meta, await asyncCall(driver.getMeta, relativeKey, opts));
      }
      if (!opts.nativeOnly) {
        const value = await asyncCall(
          driver.getItem,
          relativeKey + "$",
          opts
        ).then((value_) => destr(value_));
        if (value && typeof value === "object") {
          if (typeof value.atime === "string") {
            value.atime = new Date(value.atime);
          }
          if (typeof value.mtime === "string") {
            value.mtime = new Date(value.mtime);
          }
          Object.assign(meta, value);
        }
      }
      return meta;
    },
    setMeta(key, value, opts = {}) {
      return this.setItem(key + "$", value, opts);
    },
    removeMeta(key, opts = {}) {
      return this.removeItem(key + "$", opts);
    },
    // Keys
    async getKeys(base, opts = {}) {
      base = normalizeBaseKey(base);
      const mounts = getMounts(base, true);
      let maskedMounts = [];
      const allKeys = [];
      let allMountsSupportMaxDepth = true;
      for (const mount of mounts) {
        if (!mount.driver.flags?.maxDepth) {
          allMountsSupportMaxDepth = false;
        }
        const rawKeys = await asyncCall(
          mount.driver.getKeys,
          mount.relativeBase,
          opts
        );
        for (const key of rawKeys) {
          const fullKey = mount.mountpoint + normalizeKey$1(key);
          if (!maskedMounts.some((p) => fullKey.startsWith(p))) {
            allKeys.push(fullKey);
          }
        }
        maskedMounts = [
          mount.mountpoint,
          ...maskedMounts.filter((p) => !p.startsWith(mount.mountpoint))
        ];
      }
      const shouldFilterByDepth = opts.maxDepth !== void 0 && !allMountsSupportMaxDepth;
      return allKeys.filter(
        (key) => (!shouldFilterByDepth || filterKeyByDepth(key, opts.maxDepth)) && filterKeyByBase(key, base)
      );
    },
    // Utils
    async clear(base, opts = {}) {
      base = normalizeBaseKey(base);
      await Promise.all(
        getMounts(base, false).map(async (m) => {
          if (m.driver.clear) {
            return asyncCall(m.driver.clear, m.relativeBase, opts);
          }
          if (m.driver.removeItem) {
            const keys = await m.driver.getKeys(m.relativeBase || "", opts);
            return Promise.all(
              keys.map((key) => m.driver.removeItem(key, opts))
            );
          }
        })
      );
    },
    async dispose() {
      await Promise.all(
        Object.values(context.mounts).map((driver) => dispose(driver))
      );
    },
    async watch(callback) {
      await startWatch();
      context.watchListeners.push(callback);
      return async () => {
        context.watchListeners = context.watchListeners.filter(
          (listener) => listener !== callback
        );
        if (context.watchListeners.length === 0) {
          await stopWatch();
        }
      };
    },
    async unwatch() {
      context.watchListeners = [];
      await stopWatch();
    },
    // Mount
    mount(base, driver) {
      base = normalizeBaseKey(base);
      if (base && context.mounts[base]) {
        throw new Error(`already mounted at ${base}`);
      }
      if (base) {
        context.mountpoints.push(base);
        context.mountpoints.sort((a, b) => b.length - a.length);
      }
      context.mounts[base] = driver;
      if (context.watching) {
        Promise.resolve(watch(driver, onChange, base)).then((unwatcher) => {
          context.unwatch[base] = unwatcher;
        }).catch(console.error);
      }
      return storage;
    },
    async unmount(base, _dispose = true) {
      base = normalizeBaseKey(base);
      if (!base || !context.mounts[base]) {
        return;
      }
      if (context.watching && base in context.unwatch) {
        context.unwatch[base]?.();
        delete context.unwatch[base];
      }
      if (_dispose) {
        await dispose(context.mounts[base]);
      }
      context.mountpoints = context.mountpoints.filter((key) => key !== base);
      delete context.mounts[base];
    },
    getMount(key = "") {
      key = normalizeKey$1(key) + ":";
      const m = getMount(key);
      return {
        driver: m.driver,
        base: m.base
      };
    },
    getMounts(base = "", opts = {}) {
      base = normalizeKey$1(base);
      const mounts = getMounts(base, opts.parents);
      return mounts.map((m) => ({
        driver: m.driver,
        base: m.mountpoint
      }));
    },
    // Aliases
    keys: (base, opts = {}) => storage.getKeys(base, opts),
    get: (key, opts = {}) => storage.getItem(key, opts),
    set: (key, value, opts = {}) => storage.setItem(key, value, opts),
    has: (key, opts = {}) => storage.hasItem(key, opts),
    del: (key, opts = {}) => storage.removeItem(key, opts),
    remove: (key, opts = {}) => storage.removeItem(key, opts)
  };
  return storage;
}
function watch(driver, onChange, base) {
  return driver.watch ? driver.watch((event, key) => onChange(event, base + key)) : () => {
  };
}
async function dispose(driver) {
  if (typeof driver.dispose === "function") {
    await asyncCall(driver.dispose);
  }
}

const _assets = {

};

const normalizeKey = function normalizeKey(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
};

const assets$1 = {
  getKeys() {
    return Promise.resolve(Object.keys(_assets))
  },
  hasItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(id in _assets)
  },
  getItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].import() : null)
  },
  getMeta (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].meta : {})
  }
};

function defineDriver(factory) {
  return factory;
}
function createError(driver, message, opts) {
  const err = new Error(`[unstorage] [${driver}] ${message}`, opts);
  if (Error.captureStackTrace) {
    Error.captureStackTrace(err, createError);
  }
  return err;
}
function createRequiredError(driver, name) {
  if (Array.isArray(name)) {
    return createError(
      driver,
      `Missing some of the required options ${name.map((n) => "`" + n + "`").join(", ")}`
    );
  }
  return createError(driver, `Missing required option \`${name}\`.`);
}

function ignoreNotfound(err) {
  return err.code === "ENOENT" || err.code === "EISDIR" ? null : err;
}
function ignoreExists(err) {
  return err.code === "EEXIST" ? null : err;
}
async function writeFile(path, data, encoding) {
  await ensuredir(dirname$1(path));
  return promises.writeFile(path, data, encoding);
}
function readFile(path, encoding) {
  return promises.readFile(path, encoding).catch(ignoreNotfound);
}
function unlink(path) {
  return promises.unlink(path).catch(ignoreNotfound);
}
function readdir(dir) {
  return promises.readdir(dir, { withFileTypes: true }).catch(ignoreNotfound).then((r) => r || []);
}
async function ensuredir(dir) {
  if (existsSync(dir)) {
    return;
  }
  await ensuredir(dirname$1(dir)).catch(ignoreExists);
  await promises.mkdir(dir).catch(ignoreExists);
}
async function readdirRecursive(dir, ignore, maxDepth) {
  if (ignore && ignore(dir)) {
    return [];
  }
  const entries = await readdir(dir);
  const files = [];
  await Promise.all(
    entries.map(async (entry) => {
      const entryPath = resolve$2(dir, entry.name);
      if (entry.isDirectory()) {
        if (maxDepth === void 0 || maxDepth > 0) {
          const dirFiles = await readdirRecursive(
            entryPath,
            ignore,
            maxDepth === void 0 ? void 0 : maxDepth - 1
          );
          files.push(...dirFiles.map((f) => entry.name + "/" + f));
        }
      } else {
        if (!(ignore && ignore(entry.name))) {
          files.push(entry.name);
        }
      }
    })
  );
  return files;
}
async function rmRecursive(dir) {
  const entries = await readdir(dir);
  await Promise.all(
    entries.map((entry) => {
      const entryPath = resolve$2(dir, entry.name);
      if (entry.isDirectory()) {
        return rmRecursive(entryPath).then(() => promises.rmdir(entryPath));
      } else {
        return promises.unlink(entryPath);
      }
    })
  );
}

const PATH_TRAVERSE_RE = /\.\.:|\.\.$/;
const DRIVER_NAME = "fs-lite";
const unstorage_47drivers_47fs_45lite = defineDriver((opts = {}) => {
  if (!opts.base) {
    throw createRequiredError(DRIVER_NAME, "base");
  }
  opts.base = resolve$2(opts.base);
  const r = (key) => {
    if (PATH_TRAVERSE_RE.test(key)) {
      throw createError(
        DRIVER_NAME,
        `Invalid key: ${JSON.stringify(key)}. It should not contain .. segments`
      );
    }
    const resolved = join(opts.base, key.replace(/:/g, "/"));
    return resolved;
  };
  return {
    name: DRIVER_NAME,
    options: opts,
    flags: {
      maxDepth: true
    },
    hasItem(key) {
      return existsSync(r(key));
    },
    getItem(key) {
      return readFile(r(key), "utf8");
    },
    getItemRaw(key) {
      return readFile(r(key));
    },
    async getMeta(key) {
      const { atime, mtime, size, birthtime, ctime } = await promises.stat(r(key)).catch(() => ({}));
      return { atime, mtime, size, birthtime, ctime };
    },
    setItem(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value, "utf8");
    },
    setItemRaw(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value);
    },
    removeItem(key) {
      if (opts.readOnly) {
        return;
      }
      return unlink(r(key));
    },
    getKeys(_base, topts) {
      return readdirRecursive(r("."), opts.ignore, topts?.maxDepth);
    },
    async clear() {
      if (opts.readOnly || opts.noClear) {
        return;
      }
      await rmRecursive(r("."));
    }
  };
});

const storage = createStorage({});

storage.mount('/assets', assets$1);

storage.mount('data', unstorage_47drivers_47fs_45lite({"driver":"fsLite","base":"./.data/kv"}));

function useStorage(base = "") {
  return base ? prefixStorage(storage, base) : storage;
}

const fastHash = /*@__PURE__*/ (() => globalThis.process?.getBuiltinModule?.("crypto")?.hash)();
const algorithm = "sha256";
const encoding = "base64url";
function digest(data) {
	if (fastHash) return fastHash(algorithm, data, encoding);
	const h = createHash(algorithm).update(data);
	return globalThis.process?.versions?.webcontainer ? h.digest().toString(encoding) : h.digest(encoding);
}

const Hasher = /* @__PURE__ */ (() => {
  class Hasher2 {
    buff = "";
    #context = /* @__PURE__ */ new Map();
    write(str) {
      this.buff += str;
    }
    dispatch(value) {
      const type = value === null ? "null" : typeof value;
      return this[type](value);
    }
    object(object) {
      if (object && typeof object.toJSON === "function") {
        return this.object(object.toJSON());
      }
      const objString = Object.prototype.toString.call(object);
      let objType = "";
      const objectLength = objString.length;
      objType = objectLength < 10 ? "unknown:[" + objString + "]" : objString.slice(8, objectLength - 1);
      objType = objType.toLowerCase();
      let objectNumber = null;
      if ((objectNumber = this.#context.get(object)) === void 0) {
        this.#context.set(object, this.#context.size);
      } else {
        return this.dispatch("[CIRCULAR:" + objectNumber + "]");
      }
      if (typeof Buffer !== "undefined" && Buffer.isBuffer && Buffer.isBuffer(object)) {
        this.write("buffer:");
        return this.write(object.toString("utf8"));
      }
      if (objType !== "object" && objType !== "function" && objType !== "asyncfunction") {
        if (this[objType]) {
          this[objType](object);
        } else {
          this.unknown(object, objType);
        }
      } else {
        const keys = Object.keys(object).sort();
        const extraKeys = [];
        this.write("object:" + (keys.length + extraKeys.length) + ":");
        const dispatchForKey = (key) => {
          this.dispatch(key);
          this.write(":");
          this.dispatch(object[key]);
          this.write(",");
        };
        for (const key of keys) {
          dispatchForKey(key);
        }
        for (const key of extraKeys) {
          dispatchForKey(key);
        }
      }
    }
    array(arr, unordered) {
      unordered = unordered === void 0 ? false : unordered;
      this.write("array:" + arr.length + ":");
      if (!unordered || arr.length <= 1) {
        for (const entry of arr) {
          this.dispatch(entry);
        }
        return;
      }
      const contextAdditions = /* @__PURE__ */ new Map();
      const entries = arr.map((entry) => {
        const hasher = new Hasher2();
        hasher.dispatch(entry);
        for (const [key, value] of hasher.#context) {
          contextAdditions.set(key, value);
        }
        return hasher.toString();
      });
      this.#context = contextAdditions;
      entries.sort();
      return this.array(entries, false);
    }
    date(date) {
      return this.write("date:" + date.toJSON());
    }
    symbol(sym) {
      return this.write("symbol:" + sym.toString());
    }
    unknown(value, type) {
      this.write(type);
      if (!value) {
        return;
      }
      this.write(":");
      if (value && typeof value.entries === "function") {
        return this.array(
          [...value.entries()],
          true
          /* ordered */
        );
      }
    }
    error(err) {
      return this.write("error:" + err.toString());
    }
    boolean(bool) {
      return this.write("bool:" + bool);
    }
    string(string) {
      this.write("string:" + string.length + ":");
      this.write(string);
    }
    function(fn) {
      this.write("fn:");
      if (isNativeFunction(fn)) {
        this.dispatch("[native]");
      } else {
        this.dispatch(fn.toString());
      }
    }
    number(number) {
      return this.write("number:" + number);
    }
    null() {
      return this.write("Null");
    }
    undefined() {
      return this.write("Undefined");
    }
    regexp(regex) {
      return this.write("regex:" + regex.toString());
    }
    arraybuffer(arr) {
      this.write("arraybuffer:");
      return this.dispatch(new Uint8Array(arr));
    }
    url(url) {
      return this.write("url:" + url.toString());
    }
    map(map) {
      this.write("map:");
      const arr = [...map];
      return this.array(arr, false);
    }
    set(set) {
      this.write("set:");
      const arr = [...set];
      return this.array(arr, false);
    }
    bigint(number) {
      return this.write("bigint:" + number.toString());
    }
  }
  for (const type of [
    "uint8array",
    "uint8clampedarray",
    "unt8array",
    "uint16array",
    "unt16array",
    "uint32array",
    "unt32array",
    "float32array",
    "float64array"
  ]) {
    Hasher2.prototype[type] = function(arr) {
      this.write(type + ":");
      return this.array([...arr], false);
    };
  }
  function isNativeFunction(f) {
    if (typeof f !== "function") {
      return false;
    }
    return Function.prototype.toString.call(f).slice(
      -15
      /* "[native code] }".length */
    ) === "[native code] }";
  }
  return Hasher2;
})();
function serialize(object) {
  const hasher = new Hasher();
  hasher.dispatch(object);
  return hasher.buff;
}
function hash(value) {
  return digest(typeof value === "string" ? value : serialize(value)).replace(/[-_]/g, "").slice(0, 10);
}

function defaultCacheOptions() {
  return {
    name: "_",
    base: "/cache",
    swr: true,
    maxAge: 1
  };
}
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions(), ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = opts.integrity || hash([fn, opts]);
  const validate = opts.validate || ((entry) => entry.value !== void 0);
  async function get(key, resolver, shouldInvalidateCache, event) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    let entry = await useStorage().getItem(cacheKey).catch((error) => {
      console.error(`[cache] Cache read error.`, error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }) || {};
    if (typeof entry !== "object") {
      entry = {};
      const error = new Error("Malformed data read from cache.");
      console.error("[cache]", error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }
    const ttl = (opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || validate(entry) === false;
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry.value = await pending[key];
      } catch (error) {
        if (!isPending) {
          delete pending[key];
        }
        throw error;
      }
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry) !== false) {
          let setOpts;
          if (opts.maxAge && !opts.swr) {
            setOpts = { ttl: opts.maxAge };
          }
          const promise = useStorage().setItem(cacheKey, entry, setOpts).catch((error) => {
            console.error(`[cache] Cache write error.`, error);
            useNitroApp().captureError(error, { event, tags: ["cache"] });
          });
          if (event?.waitUntil) {
            event.waitUntil(promise);
          }
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (entry.value === void 0) {
      await _resolvePromise;
    } else if (expired && event && event.waitUntil) {
      event.waitUntil(_resolvePromise);
    }
    if (opts.swr && validate(entry) !== false) {
      _resolvePromise.catch((error) => {
        console.error(`[cache] SWR handler error.`, error);
        useNitroApp().captureError(error, { event, tags: ["cache"] });
      });
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = await opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = await opts.shouldInvalidateCache?.(...args);
    const entry = await get(
      key,
      () => fn(...args),
      shouldInvalidateCache,
      args[0] && isEvent(args[0]) ? args[0] : void 0
    );
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
function cachedFunction(fn, opts = {}) {
  return defineCachedFunction(fn, opts);
}
function getKey(...args) {
  return args.length > 0 ? hash(args) : "";
}
function escapeKey(key) {
  return String(key).replace(/\W/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions()) {
  const variableHeaderNames = (opts.varies || []).filter(Boolean).map((h) => h.toLowerCase()).sort();
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const customKey = await opts.getKey?.(event);
      if (customKey) {
        return escapeKey(customKey);
      }
      const _path = event.node.req.originalUrl || event.node.req.url || event.path;
      let _pathname;
      try {
        _pathname = escapeKey(decodeURI(parseURL(_path).pathname)).slice(0, 16) || "index";
      } catch {
        _pathname = "-";
      }
      const _hashedPath = `${_pathname}.${hash(_path)}`;
      const _headers = variableHeaderNames.map((header) => [header, event.node.req.headers[header]]).map(([name, value]) => `${escapeKey(name)}.${hash(value)}`);
      return [_hashedPath, ..._headers].join(":");
    },
    validate: (entry) => {
      if (!entry.value) {
        return false;
      }
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      if (entry.value.headers.etag === "undefined" || entry.value.headers["last-modified"] === "undefined") {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: opts.integrity || hash([handler, opts])
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const variableHeaders = {};
      for (const header of variableHeaderNames) {
        const value = incomingEvent.node.req.headers[header];
        if (value !== void 0) {
          variableHeaders[header] = value;
        }
      }
      const reqProxy = cloneWithProxy(incomingEvent.node.req, {
        headers: variableHeaders
      });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        writableEnded: false,
        writableFinished: false,
        headersSent: false,
        closed: false,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2(void 0);
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return true;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            if (Array.isArray(headers2) || typeof headers2 === "string") {
              throw new TypeError("Raw headers  is not supported.");
            }
            for (const header in headers2) {
              const value = headers2[header];
              if (value !== void 0) {
                this.setHeader(
                  header,
                  value
                );
              }
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event.fetch = (url, fetchOptions) => fetchWithEvent$1(event, url, fetchOptions, {
        fetch: useNitroApp().localFetch
      });
      event.$fetch = (url, fetchOptions) => fetchWithEvent$1(event, url, fetchOptions, {
        fetch: globalThis.$fetch
      });
      event.waitUntil = incomingEvent.waitUntil;
      event.context = incomingEvent.context;
      event.context.cache = {
        options: _opts
      };
      const body = await handler(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = String(
        headers.Etag || headers.etag || `W/"${hash(body)}"`
      );
      headers["last-modified"] = String(
        headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString()
      );
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(
      event
    );
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      const value = response.headers[name];
      if (name === "set-cookie") {
        event.node.res.appendHeader(
          name,
          splitCookiesString(value)
        );
      } else {
        if (value !== void 0) {
          event.node.res.setHeader(name, value);
        }
      }
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

function klona(x) {
	if (typeof x !== 'object') return x;

	var k, tmp, str=Object.prototype.toString.call(x);

	if (str === '[object Object]') {
		if (x.constructor !== Object && typeof x.constructor === 'function') {
			tmp = new x.constructor();
			for (k in x) {
				if (x.hasOwnProperty(k) && tmp[k] !== x[k]) {
					tmp[k] = klona(x[k]);
				}
			}
		} else {
			tmp = {}; // null
			for (k in x) {
				if (k === '__proto__') {
					Object.defineProperty(tmp, k, {
						value: klona(x[k]),
						configurable: true,
						enumerable: true,
						writable: true,
					});
				} else {
					tmp[k] = klona(x[k]);
				}
			}
		}
		return tmp;
	}

	if (str === '[object Array]') {
		k = x.length;
		for (tmp=Array(k); k--;) {
			tmp[k] = klona(x[k]);
		}
		return tmp;
	}

	if (str === '[object Set]') {
		tmp = new Set;
		x.forEach(function (val) {
			tmp.add(klona(val));
		});
		return tmp;
	}

	if (str === '[object Map]') {
		tmp = new Map;
		x.forEach(function (val, key) {
			tmp.set(klona(key), klona(val));
		});
		return tmp;
	}

	if (str === '[object Date]') {
		return new Date(+x);
	}

	if (str === '[object RegExp]') {
		tmp = new RegExp(x.source, x.flags);
		tmp.lastIndex = x.lastIndex;
		return tmp;
	}

	if (str === '[object DataView]') {
		return new x.constructor( klona(x.buffer) );
	}

	if (str === '[object ArrayBuffer]') {
		return x.slice(0);
	}

	// ArrayBuffer.isView(x)
	// ~> `new` bcuz `Buffer.slice` => ref
	if (str.slice(-6) === 'Array]') {
		return new x.constructor(x);
	}

	return x;
}

const inlineAppConfig = {};



const appConfig = defuFn(inlineAppConfig);

const NUMBER_CHAR_RE = /\d/;
const STR_SPLITTERS = ["-", "_", "/", "."];
function isUppercase(char = "") {
  if (NUMBER_CHAR_RE.test(char)) {
    return void 0;
  }
  return char !== char.toLowerCase();
}
function splitByCase(str, separators) {
  const splitters = STR_SPLITTERS;
  const parts = [];
  if (!str || typeof str !== "string") {
    return parts;
  }
  let buff = "";
  let previousUpper;
  let previousSplitter;
  for (const char of str) {
    const isSplitter = splitters.includes(char);
    if (isSplitter === true) {
      parts.push(buff);
      buff = "";
      previousUpper = void 0;
      continue;
    }
    const isUpper = isUppercase(char);
    if (previousSplitter === false) {
      if (previousUpper === false && isUpper === true) {
        parts.push(buff);
        buff = char;
        previousUpper = isUpper;
        continue;
      }
      if (previousUpper === true && isUpper === false && buff.length > 1) {
        const lastChar = buff.at(-1);
        parts.push(buff.slice(0, Math.max(0, buff.length - 1)));
        buff = lastChar + char;
        previousUpper = isUpper;
        continue;
      }
    }
    buff += char;
    previousUpper = isUpper;
    previousSplitter = isSplitter;
  }
  parts.push(buff);
  return parts;
}
function kebabCase(str, joiner) {
  return str ? (Array.isArray(str) ? str : splitByCase(str)).map((p) => p.toLowerCase()).join(joiner) : "";
}
function snakeCase(str) {
  return kebabCase(str || "", "_");
}

function getEnv(key, opts) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[opts.prefix + envKey] ?? process.env[opts.altPrefix + envKey]
  );
}
function _isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function applyEnv(obj, opts, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey, opts);
    if (_isObject(obj[key])) {
      if (_isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
        applyEnv(obj[key], opts, subKey);
      } else if (envValue === void 0) {
        applyEnv(obj[key], opts, subKey);
      } else {
        obj[key] = envValue ?? obj[key];
      }
    } else {
      obj[key] = envValue ?? obj[key];
    }
    if (opts.envExpansion && typeof obj[key] === "string") {
      obj[key] = _expandFromEnv(obj[key]);
    }
  }
  return obj;
}
const envExpandRx = /\{\{([^{}]*)\}\}/g;
function _expandFromEnv(value) {
  return value.replace(envExpandRx, (match, key) => {
    return process.env[key] || match;
  });
}

const _inlineRuntimeConfig = {
  "app": {
    "baseURL": "/",
    "buildId": "41bdffe5-309d-4564-8019-77900a125c90",
    "buildAssetsDir": "/_nuxt/",
    "cdnURL": ""
  },
  "nitro": {
    "envPrefix": "NUXT_",
    "routeRules": {
      "/__nuxt_error": {
        "cache": false
      },
      "/api/**": {
        "proxy": {
          "to": "https://api.shermant.com/v1/**",
          "_proxyStripBase": "/api"
        }
      },
      "/oss/**": {
        "proxy": {
          "to": "https://oss.shermant.com/**",
          "_proxyStripBase": "/oss"
        }
      },
      "/_nuxt/builds/meta/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      },
      "/_nuxt/builds/**": {
        "headers": {
          "cache-control": "public, max-age=1, immutable"
        }
      },
      "/_nuxt/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      }
    }
  },
  "appSecret": "",
  "public": {
    "serverHost": "0.0.0.0",
    "serverPort": 3000,
    "siteName": "曾小满的盒子-ShermanBox",
    "siteDescription": "盒子里，是我的生活和我。",
    "siteKeywords": "曾小满,小满,个人网站,个人博客,ShareMan,ShareManT,ShareManTsang,ShermanT",
    "siteDomain": "https://shermant.com",
    "apiBaseurl": "https://api.shermant.com/v1",
    "ossBaseurl": "https://oss.shermant.com"
  },
  "sitemap": {
    "cacheMaxAgeSeconds": 600,
    "debug": false
  },
  "nuxt-site-config": {
    "stack": [
      {
        "_context": "system",
        "_priority": -15,
        "env": "production"
      },
      {
        "_context": "vendorEnv",
        "_priority": -5,
        "name": "曾小满的盒子-ShermanBox"
      },
      {
        "_priority": -3,
        "_context": "nuxt-site-config:config",
        "url": "https://shermant.com",
        "name": "曾小满的盒子-ShermanBox"
      }
    ],
    "version": "4.2.3",
    "debug": false,
    "multiTenancy": []
  }
};
const envOptions = {
  prefix: "NITRO_",
  altPrefix: _inlineRuntimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_",
  envExpansion: _inlineRuntimeConfig.nitro.envExpansion ?? process.env.NITRO_ENV_EXPANSION ?? false
};
const _sharedRuntimeConfig = _deepFreeze(
  applyEnv(klona(_inlineRuntimeConfig), envOptions)
);
function useRuntimeConfig(event) {
  if (!event) {
    return _sharedRuntimeConfig;
  }
  if (event.context.nitro.runtimeConfig) {
    return event.context.nitro.runtimeConfig;
  }
  const runtimeConfig = klona(_inlineRuntimeConfig);
  applyEnv(runtimeConfig, envOptions);
  event.context.nitro.runtimeConfig = runtimeConfig;
  return runtimeConfig;
}
_deepFreeze(klona(appConfig));
function _deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      _deepFreeze(value);
    }
  }
  return Object.freeze(object);
}
new Proxy(/* @__PURE__ */ Object.create(null), {
  get: (_, prop) => {
    console.warn(
      "Please use `useRuntimeConfig()` instead of accessing config directly."
    );
    const runtimeConfig = useRuntimeConfig();
    if (prop in runtimeConfig) {
      return runtimeConfig[prop];
    }
    return void 0;
  }
});

function createContext(opts = {}) {
  let currentInstance;
  let isSingleton = false;
  const checkConflict = (instance) => {
    if (currentInstance && currentInstance !== instance) {
      throw new Error("Context conflict");
    }
  };
  let als;
  if (opts.asyncContext) {
    const _AsyncLocalStorage = opts.AsyncLocalStorage || globalThis.AsyncLocalStorage;
    if (_AsyncLocalStorage) {
      als = new _AsyncLocalStorage();
    } else {
      console.warn("[unctx] `AsyncLocalStorage` is not provided.");
    }
  }
  const _getCurrentInstance = () => {
    if (als) {
      const instance = als.getStore();
      if (instance !== void 0) {
        return instance;
      }
    }
    return currentInstance;
  };
  return {
    use: () => {
      const _instance = _getCurrentInstance();
      if (_instance === void 0) {
        throw new Error("Context is not available");
      }
      return _instance;
    },
    tryUse: () => {
      return _getCurrentInstance();
    },
    set: (instance, replace) => {
      if (!replace) {
        checkConflict(instance);
      }
      currentInstance = instance;
      isSingleton = true;
    },
    unset: () => {
      currentInstance = void 0;
      isSingleton = false;
    },
    call: (instance, callback) => {
      checkConflict(instance);
      currentInstance = instance;
      try {
        return als ? als.run(instance, callback) : callback();
      } finally {
        if (!isSingleton) {
          currentInstance = void 0;
        }
      }
    },
    async callAsync(instance, callback) {
      currentInstance = instance;
      const onRestore = () => {
        currentInstance = instance;
      };
      const onLeave = () => currentInstance === instance ? onRestore : void 0;
      asyncHandlers.add(onLeave);
      try {
        const r = als ? als.run(instance, callback) : callback();
        if (!isSingleton) {
          currentInstance = void 0;
        }
        return await r;
      } finally {
        asyncHandlers.delete(onLeave);
      }
    }
  };
}
function createNamespace(defaultOpts = {}) {
  const contexts = {};
  return {
    get(key, opts = {}) {
      if (!contexts[key]) {
        contexts[key] = createContext({ ...defaultOpts, ...opts });
      }
      return contexts[key];
    }
  };
}
const _globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof global !== "undefined" ? global : {};
const globalKey = "__unctx__";
const defaultNamespace = _globalThis[globalKey] || (_globalThis[globalKey] = createNamespace());
const getContext = (key, opts = {}) => defaultNamespace.get(key, opts);
const asyncHandlersKey = "__unctx_async_handlers__";
const asyncHandlers = _globalThis[asyncHandlersKey] || (_globalThis[asyncHandlersKey] = /* @__PURE__ */ new Set());

getContext("nitro-app", {
  asyncContext: false,
  AsyncLocalStorage: void 0
});

function isPathInScope(pathname, base) {
  let canonical;
  try {
    const pre = pathname.replace(/%2f/gi, "/").replace(/%5c/gi, "\\");
    canonical = new URL(pre, "http://_").pathname;
  } catch {
    return false;
  }
  return !base || canonical === base || canonical.startsWith(base + "/");
}

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter$1({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler(ctx) {
  return eventHandler((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      let target = routeRules.redirect.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.redirect._redirectStripBase;
        if (strpBase) {
          if (!isPathInScope(event.path.split("?")[0], strpBase)) {
            throw createError$1({ statusCode: 400 });
          }
          targetPath = withoutBase(targetPath, strpBase);
        } else if (targetPath.startsWith("//")) {
          targetPath = targetPath.replace(/^\/+/, "/");
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return sendRedirect(event, target, routeRules.redirect.statusCode);
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          if (!isPathInScope(event.path.split("?")[0], strpBase)) {
            throw createError$1({ statusCode: 400 });
          }
          targetPath = withoutBase(targetPath, strpBase);
        } else if (targetPath.startsWith("//")) {
          targetPath = targetPath.replace(/^\/+/, "/");
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return proxyRequest(event, target, {
        fetch: ctx.localFetch,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(event.path.split("?")[0], useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError(error, { tags: [type] });
}
function trapUnhandledNodeErrors() {
  process.on(
    "unhandledRejection",
    (error) => _captureError(error, "unhandledRejection")
  );
  process.on(
    "uncaughtException",
    (error) => _captureError(error, "uncaughtException")
  );
}
function joinHeaders(value) {
  return Array.isArray(value) ? value.join(", ") : String(value);
}
function normalizeFetchResponse(response) {
  if (!response.headers.has("set-cookie")) {
    return response;
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers: normalizeCookieHeaders(response.headers)
  });
}
function normalizeCookieHeader(header = "") {
  return splitCookiesString(joinHeaders(header));
}
function normalizeCookieHeaders(headers) {
  const outgoingHeaders = new Headers();
  for (const [name, header] of headers) {
    if (name === "set-cookie") {
      for (const cookie of normalizeCookieHeader(header)) {
        outgoingHeaders.append("set-cookie", cookie);
      }
    } else {
      outgoingHeaders.set(name, joinHeaders(header));
    }
  }
  return outgoingHeaders;
}

//#region src/runtime/utils/event.ts
const ENC_PIPE_RE = /%7C/g;
const ENC_BRACKET_OPEN_RE = /%5B/g;
const ENC_BRACKET_CLOSE_RE = /%5D/g;
const ENC_ENC_SLASH_RE = /%252F/gi;
const HASH_RE = /#/g;
const QUESTION_MARK_RE = /\?/g;
function encodeEventPath(path) {
	const queryIndex = path.indexOf("?");
	if (queryIndex === -1) return encodeVueRouterPath(path);
	return encodeVueRouterPath(path.slice(0, queryIndex)) + path.slice(queryIndex);
}
function encodeVueRouterPath(path) {
	return encodeURI(path).replace(ENC_PIPE_RE, "|").replace(ENC_BRACKET_OPEN_RE, "[").replace(ENC_BRACKET_CLOSE_RE, "]").replace(HASH_RE, "%23").replace(QUESTION_MARK_RE, "%3F").replace(ENC_ENC_SLASH_RE, "%2F");
}
/**
* The response headers of an h3 v1 event, in the shape the renderer writes them in.
*
* Backed by the node response rather than a copy of it, so a header the app sets through
* h3 and a header the renderer sets are the same header, and both are sent.
*/
var NodeResponseHeaders = class {
	res;
	constructor(res) {
		this.res = res;
	}
	get(name) {
		const value = this.res.getHeader(name);
		if (value === void 0) return null;
		return Array.isArray(value) ? value.join(", ") : String(value);
	}
	has(name) {
		return this.res.hasHeader(name);
	}
	set(name, value) {
		this.res.setHeader(name, value);
	}
	append(name, value) {
		const existing = this.res.getHeader(name);
		if (existing === void 0) {
			this.res.setHeader(name, value);
			return;
		}
		this.res.setHeader(name, Array.isArray(existing) ? [...existing, value] : [String(existing), value]);
	}
	delete(name) {
		this.res.removeHeader(name);
	}
	getSetCookie() {
		const value = this.res.getHeader("set-cookie");
		if (value === void 0) return [];
		return Array.isArray(value) ? value.map(String) : [String(value)];
	}
	*entries() {
		const headers = this.res.getHeaders();
		for (const name of Object.keys(headers).sort()) {
			const value = headers[name];
			if (value === void 0) continue;
			if (name === "set-cookie" && Array.isArray(value)) for (const entry of value) yield [name, entry];
			else yield [name, Array.isArray(value) ? value.join(", ") : String(value)];
		}
	}
	*keys() {
		for (const [name] of this.entries()) yield name;
	}
	*values() {
		for (const [, value] of this.entries()) yield value;
	}
	forEach(callback, thisArg) {
		for (const [name, value] of this.entries()) callback.call(thisArg, value, name, this);
	}
	[Symbol.iterator]() {
		return this.entries();
	}
};
const PAYLOAD_METHODS = /* @__PURE__ */ new Set([
	"PATCH",
	"POST",
	"PUT",
	"DELETE"
]);
const BODY_READ_METHODS = /* @__PURE__ */ new Set([
	"arrayBuffer",
	"blob",
	"bytes",
	"formData",
	"json",
	"text"
]);
/**
* The request in the web-standard shape, with every read of its body served from the bytes
* h3 v1 caches on the node request.
*
* A body read here and a `readBody(event)` elsewhere in the same request therefore resolve
* to the same bytes whichever happens first, and reading the request twice - directly, from
* a clone, or as a stream - resolves the same bytes each time rather than the second read
* finding a stream the first has drained.
*/
function toWebRequest$1(event) {
	const existing = event.web?.request;
	if (existing) return existing;
	const method = event.method;
	if (!PAYLOAD_METHODS.has(method)) return new Request(getRequestURL(event), {
		method,
		headers: event.headers
	});
	const request = new Request(getRequestURL(event), {
		method,
		headers: event.headers,
		body: toBufferedBodyStream(event),
		duplex: "half"
	});
	const read = () => readRawBody(event, false).then((body) => body ? new Uint8Array(body) : /* @__PURE__ */ new Uint8Array());
	const copy = () => read().then((body) => new Response(body, { headers: request.headers }));
	const buffered = new Proxy(request, { get(target, property) {
		if (property === "bodyUsed") return false;
		if (property === "body") return toBufferedBodyStream(event);
		if (property === "clone") return () => buffered;
		if (typeof property === "string" && BODY_READ_METHODS.has(property)) return () => copy().then((response) => response[property]());
		const value = Reflect.get(target, property, target);
		return typeof value === "function" ? value.bind(target) : value;
	} });
	return buffered;
}
function toBufferedBodyStream(event) {
	return new ReadableStream({ async pull(controller) {
		const body = await readRawBody(event, false);
		if (body) controller.enqueue(new Uint8Array(body));
		controller.close();
	} });
}
/**
* The Nuxt context a request nitro made to itself was fetched with: `node-mock-http` carries
* it on the mock request rather than in the h3 event's own context. A request that arrives
* over the network has none, whoever sent it.
*/
function getFetchedRequestContext(event) {
	return event.node.req.__unenv__?.nuxt;
}
/** The event the SSR renderer reads, which reaches the h3 v1 event itself through `~app`. */
function toRequestEvent(event) {
	const requestEvent = toWebView(event);
	const fetchedWith = getFetchedRequestContext(event);
	if (fetchedWith) event.context.nuxt = {
		...fetchedWith,
		...event.context.nuxt
	};
	return requestEvent;
}
/**
* Describe an h3 v1 event in the web-standard shape, rather than adapting it in place:
* `event.req` and `event.res` already name the node request and response, and that is the
* shape `useRequestEvent()` and the render hooks must keep seeing.
*
* Everything is resolved on access, and the response is backed by the node response rather
* than a copy of it, so a header the application sets through h3 and a header the renderer
* sets are the same header.
*/
function toWebView(event, resolveURL = () => new URL(encodeEventPath(event.path), `${getRequestProtocol(event)}://${getRequestHost(event)}`)) {
	const node = event.node;
	let request;
	let url;
	const res = {
		get status() {
			return node.res.statusCode;
		},
		set status(status) {
			node.res.statusCode = status;
		},
		get statusText() {
			return node.res.statusMessage;
		},
		set statusText(statusText) {
			node.res.statusMessage = statusText;
		},
		headers: new NodeResponseHeaders(node.res)
	};
	const requestEvent = {
		context: event.context,
		res,
		get req() {
			return request ??= toWebRequest$1(event);
		},
		get url() {
			return url ??= resolveURL();
		},
		set url(value) {
			url = value;
			event._path = node.req.url = value.pathname + value.search;
		}
	};
	requestEvent["~app"] = event;
	return requestEvent;
}

//#region src/runtime/utils/error.ts
/**
* Nitro internal functions extracted from https://github.com/nitrojs/nitro/blob/v2/src/runtime/internal/utils.ts
*/
function isJsonRequest(event) {
	if (hasReqHeader(event, "accept", "text/html")) return false;
	return hasReqHeader(event, "accept", "application/json") || hasReqHeader(event, "user-agent", "curl/") || hasReqHeader(event, "user-agent", "httpie/") || hasReqHeader(event, "sec-fetch-mode", "cors") || event.path.startsWith("/api/") || event.path.endsWith(".json");
}
function hasReqHeader(event, name, includes) {
	const value = getRequestHeader(event, name);
	return !!(value && typeof value === "string" && value.toLowerCase().includes(includes));
}

const headSymbol = "usehead";
// @__NO_SIDE_EFFECTS__
function vueInstall(head) {
  const plugin = {
    install(app) {
      app.config.globalProperties.$unhead = head;
      app.config.globalProperties.$head = head;
      app.provide(headSymbol, head);
    }
  };
  return plugin.install;
}

const VueResolver = /* @__PURE__ */ Object.assign(
  (_, value) => isRef(value) ? toValue$1(value) : value,
  // identity for plain non-reactive values, so the SSR default init entry
  // keeps its precomputed fast path (see unhead/server createHead)
  { _static: true }
);

// @__NO_SIDE_EFFECTS__
function createHead(options = {}) {
  const head = createHead$1({
    ...options,
    propResolvers: [VueResolver]
  });
  head.install = vueInstall(head);
  return head;
}

const legacyPlugins = [DeprecationsPlugin, PromisesPlugin, TemplateParamsPlugin, AliasSortingPlugin];

const unheadOptions = {
  disableDefaults: true,
  plugins: legacyPlugins,
};

const renderSSRHeadOptions = {"omitLineBreaks":true};

const NUXT_PRERENDER_NO_SSR_ROUTES = ["/index.html","/200.html","/404.html"];
const NUXT_NO_SCRIPTS_PATTERNS = [];
const NUXT_PAGE_PATTERNS = ["/monument/2022","/page/log","/blog/:id","/day/:date","/idea/:id","/mailbox/:id","/movie/:id","/page/:url","/plan/:id","/project/:id","/word/:id","/blog","/day","/error","/idea","/mailbox","/monument","/movie","/plan","/project","/search","/timeline","/word","/*","/"];
const NUXT_SSR_STREAMING = false;
const appHead = {"meta":[{"charset":"utf-8"},{"name":"viewport","content":"width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no"},{"name":"description","content":"盒子里，是我的生活和我。"},{"name":"keywords","content":"曾小满,小满,个人网站,个人博客,ShareMan,ShareManT,ShareManTsang,ShermanT"}],"link":[{"rel":"icon","type":"image/x-icon","href":"/favicon.ico"},{"rel":"favicon","href":"/favicon.ico"},{"rel":"preconnect","href":"https://fonts.googleapis.cn"},{"rel":"preconnect","href":"https://fonts.gstatic.cn","crossorigin":""},{"rel":"stylesheet","href":"https://fonts.googleapis.cn/css2?family=Noto+Sans+SC:wght@400;500;700&family=Noto+Serif+SC:wght@600&family=Source+Code+Pro:wght@400;700&display=swap"}],"style":[],"script":[{"innerHTML":"(function(c,l,a,r,i,t,y){c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};t=l.createElement(r);t.async=1;t.src=\"https://www.clarity.ms/tag/\"+i;y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);})(window, document, \"clarity\", \"script\", \"ntwi7inprr\");","type":"text/javascript","tagPosition":"head"}],"noscript":[],"titleTemplate":"%s - 曾小满的盒子-ShermanBox","htmlAttrs":{"lang":"zh-CN"}};
const appRootTag = "div";
const appRootAttrs = {"id":"__nuxt"};
const appTeleportTag = "div";
const appTeleportAttrs = {"id":"teleports"};
const appSpaLoaderTag = "div";
const appSpaLoaderAttrs = {"id":"__nuxt-loader"};
const appId = "nuxt-app";

//#region src/runtime/handlers/error.ts
var error_default = async function errorhandler(error, event, { defaultHandler }) {
	if (event.handled) return;
	const isRenderingError = !!(event.context.nuxt?.["~rendering-error"] || getFetchedRequestContext(event)?.["~rendering-error"]);
	let errorCause;
	if (isJsonRequest(event)) {
		return;
	}
	const defaultRes = await defaultHandler(error, event, {
		json: true,
		silent: false
	});
	if ((error.status || error.statusCode || 500) === 404 && defaultRes.status === 302) {
		setResponseHeaders(event, defaultRes.headers);
		appendVary(event, "accept, sec-fetch-mode");
		setResponseStatus(event, defaultRes.status, defaultRes.statusText);
		return send(event, JSON.stringify(defaultRes.body, null, 2));
	}
	const errorObject = defaultRes.body;
	const url = new URL(errorObject.url);
	errorObject.url = withoutBase(url.pathname, useRuntimeConfig(event).app.baseURL) + url.search + url.hash;
	errorObject.message = error.unhandled ? errorObject.message || "Server Error" : error.message || errorObject.message || "Server Error";
	if (!error.unhandled) errorObject.data ||= error.data;
	errorObject.statusText ||= error.statusText || error.statusMessage;
	delete defaultRes.headers["content-type"];
	delete defaultRes.headers["content-security-policy"];
	setResponseHeaders(event, defaultRes.headers);
	appendVary(event, "accept, sec-fetch-mode");
	if (!isRenderingError) event.context.nuxt = {
		...event.context.nuxt,
		"~rendering-error": true
	};
	const res = isRenderingError ? null : await useNitroApp().localFetch(withQuery(joinURL(useRuntimeConfig(event).app.baseURL, "/__nuxt_error"), {
		...errorObject,
		...errorCause !== void 0
	}), {
		headers: event.headers,
		redirect: "manual",
		context: { nuxt: { "~rendering-error": true } }
	}).catch(() => null);
	if (event.handled) return;
	if (!res) {
		setResponseHeader(event, "Content-Type", "text/html;charset=UTF-8");
		const { template } = await import('../_/error-template.mjs');
		return send(event, template(errorObject));
	}
	let html = await res.text();
	for (const [header, value] of res.headers.entries()) {
		if (header === ERROR_PAGE_HEADER) continue;
		if (header === "set-cookie" || header === "x-nitro-prerender") {
			appendResponseHeader(event, header, value);
			continue;
		}
		setResponseHeader(event, header, value);
	}
	setResponseStatus(event, res.status && res.status !== 200 ? res.status : defaultRes.status, res.statusText || defaultRes.statusText);
	return send(event, html);
};
/** Set when the app's own error page could not render. */
const ERROR_PAGE_HEADER = "x-nuxt-error-page";
/**
* Add `value`'s tokens to the response `vary` header, keeping any already
* present. `*` absorbs everything else, since it means the response varies on
* all headers.
*/
function appendVary(event, value) {
	const incoming = parseVary(value);
	if (!incoming.length) return;
	const existing = parseVary(getResponseHeader(event, "vary"));
	if (existing.includes("*")) return;
	if (incoming.includes("*")) {
		setResponseHeader(event, "vary", "*");
		return;
	}
	const merged = existing.slice();
	for (const token of incoming) if (!merged.includes(token)) merged.push(token);
	setResponseHeader(event, "vary", merged.join(", "));
}
function parseVary(value) {
	return (Array.isArray(value) ? value : typeof value === "string" ? value.split(",") : []).map((token) => token.trim().toLowerCase()).filter(Boolean);
}

function defineNitroErrorHandler(handler) {
  return handler;
}

const errorHandler$1 = defineNitroErrorHandler(
  function defaultNitroErrorHandler(error, event) {
    const res = defaultHandler(error, event);
    setResponseHeaders(event, res.headers);
    setResponseStatus(event, res.status, res.statusText);
    return send(event, JSON.stringify(res.body, null, 2));
  }
);
function defaultHandler(error, event, opts) {
  const isSensitive = error.unhandled || error.fatal;
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage || "Server Error";
  const url = getRequestURL(event, { xForwardedHost: true, xForwardedProto: true });
  if (statusCode === 404) {
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      const redirectTo = `${baseURL}${url.pathname.slice(1)}${url.search}`;
      return {
        status: 302,
        statusText: "Found",
        headers: { location: redirectTo },
        body: `Redirecting...`
      };
    }
  }
  if (isSensitive && !opts?.silent) {
    const tags = [error.unhandled && "[unhandled]", error.fatal && "[fatal]"].filter(Boolean).join(" ");
    console.error(`[request error] ${tags} [${event.method}] ${url}
`, error);
  }
  const headers = {
    "content-type": "application/json",
    // Prevent browser from guessing the MIME types of resources.
    "x-content-type-options": "nosniff",
    // Prevent error page from being embedded in an iframe
    "x-frame-options": "DENY",
    // Prevent browsers from sending the Referer header
    "referrer-policy": "no-referrer",
    // Disable the execution of any js
    "content-security-policy": "script-src 'none'; frame-ancestors 'none';"
  };
  setResponseStatus(event, statusCode, statusMessage);
  if (statusCode === 404 || !getResponseHeader(event, "cache-control")) {
    headers["cache-control"] = "no-cache";
  }
  const body = {
    error: true,
    url: url.href,
    statusCode,
    statusMessage,
    message: isSensitive ? "Server Error" : error.message,
    data: isSensitive ? void 0 : error.data
  };
  return {
    status: statusCode,
    statusText: statusMessage,
    headers,
    body
  };
}

const errorHandlers = [error_default, errorHandler$1];

async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      await handler(error, event, { defaultHandler });
      if (event.handled) {
        return; // Response handled
      }
    } catch(error) {
      // Handler itself thrown, log and continue
      console.error(error);
    }
  }
  // H3 will handle fallback
}

const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_$";
const unsafeChars = /[<>\b\f\n\r\t\0\u2028\u2029]/g;
const reserved = /^(?:do|if|in|for|int|let|new|try|var|byte|case|char|else|enum|goto|long|this|void|with|await|break|catch|class|const|final|float|short|super|throw|while|yield|delete|double|export|import|native|return|switch|throws|typeof|boolean|default|extends|finally|package|private|abstract|continue|debugger|function|volatile|interface|protected|transient|implements|instanceof|synchronized)$/;
const escaped = {
  "<": "\\u003C",
  ">": "\\u003E",
  "/": "\\u002F",
  "\\": "\\\\",
  "\b": "\\b",
  "\f": "\\f",
  "\n": "\\n",
  "\r": "\\r",
  "	": "\\t",
  "\0": "\\0",
  "\u2028": "\\u2028",
  "\u2029": "\\u2029"
};
const objectProtoOwnPropertyNames = Object.getOwnPropertyNames(Object.prototype).sort().join("\0");
function devalue(value) {
  const counts = /* @__PURE__ */ new Map();
  let logNum = 0;
  function log(message) {
    if (logNum < 100) {
      console.warn(message);
      logNum += 1;
    }
  }
  function walk(thing) {
    if (typeof thing === "function") {
      log(`Cannot stringify a function ${thing.name}`);
      return;
    }
    if (counts.has(thing)) {
      counts.set(thing, counts.get(thing) + 1);
      return;
    }
    counts.set(thing, 1);
    if (!isPrimitive(thing)) {
      const type = getType(thing);
      switch (type) {
        case "Number":
        case "String":
        case "Boolean":
        case "Date":
        case "RegExp":
          return;
        case "Array":
          thing.forEach(walk);
          break;
        case "Set":
        case "Map":
          Array.from(thing).forEach(walk);
          break;
        default:
          const proto = Object.getPrototypeOf(thing);
          if (proto !== Object.prototype && proto !== null && Object.getOwnPropertyNames(proto).sort().join("\0") !== objectProtoOwnPropertyNames) {
            if (typeof thing.toJSON !== "function") {
              log(`Cannot stringify arbitrary non-POJOs ${thing.constructor.name}`);
            }
          } else if (Object.getOwnPropertySymbols(thing).length > 0) {
            log(`Cannot stringify POJOs with symbolic keys ${Object.getOwnPropertySymbols(thing).map((symbol) => symbol.toString())}`);
          } else {
            Object.keys(thing).forEach((key) => walk(thing[key]));
          }
      }
    }
  }
  walk(value);
  const names = /* @__PURE__ */ new Map();
  Array.from(counts).filter((entry) => entry[1] > 1).sort((a, b) => b[1] - a[1]).forEach((entry, i) => {
    names.set(entry[0], getName(i));
  });
  function stringify(thing) {
    if (names.has(thing)) {
      return names.get(thing);
    }
    if (isPrimitive(thing)) {
      return stringifyPrimitive(thing);
    }
    const type = getType(thing);
    switch (type) {
      case "Number":
      case "String":
      case "Boolean":
        return `Object(${stringify(thing.valueOf())})`;
      case "RegExp":
        return thing.toString();
      case "Date":
        return `new Date(${thing.getTime()})`;
      case "Array":
        const members = thing.map((v, i) => i in thing ? stringify(v) : "");
        const tail = thing.length === 0 || thing.length - 1 in thing ? "" : ",";
        return `[${members.join(",")}${tail}]`;
      case "Set":
      case "Map":
        return `new ${type}([${Array.from(thing).map(stringify).join(",")}])`;
      default:
        if (thing.toJSON) {
          let json = thing.toJSON();
          if (getType(json) === "String") {
            try {
              json = JSON.parse(json);
            } catch (e) {
            }
          }
          return stringify(json);
        }
        if (Object.getPrototypeOf(thing) === null) {
          if (Object.keys(thing).length === 0) {
            return "Object.create(null)";
          }
          return `Object.create(null,{${Object.keys(thing).map((key) => `${safeKey(key)}:{writable:true,enumerable:true,value:${stringify(thing[key])}}`).join(",")}})`;
        }
        return `{${Object.keys(thing).map((key) => `${safeKey(key)}:${stringify(thing[key])}`).join(",")}}`;
    }
  }
  const str = stringify(value);
  if (names.size) {
    const params = [];
    const statements = [];
    const values = [];
    names.forEach((name, thing) => {
      params.push(name);
      if (isPrimitive(thing)) {
        values.push(stringifyPrimitive(thing));
        return;
      }
      const type = getType(thing);
      switch (type) {
        case "Number":
        case "String":
        case "Boolean":
          values.push(`Object(${stringify(thing.valueOf())})`);
          break;
        case "RegExp":
          values.push(thing.toString());
          break;
        case "Date":
          values.push(`new Date(${thing.getTime()})`);
          break;
        case "Array":
          values.push(`Array(${thing.length})`);
          thing.forEach((v, i) => {
            statements.push(`${name}[${i}]=${stringify(v)}`);
          });
          break;
        case "Set":
          values.push("new Set");
          statements.push(`${name}.${Array.from(thing).map((v) => `add(${stringify(v)})`).join(".")}`);
          break;
        case "Map":
          values.push("new Map");
          statements.push(`${name}.${Array.from(thing).map(([k, v]) => `set(${stringify(k)}, ${stringify(v)})`).join(".")}`);
          break;
        default:
          values.push(Object.getPrototypeOf(thing) === null ? "Object.create(null)" : "{}");
          Object.keys(thing).forEach((key) => {
            statements.push(`${name}${safeProp(key)}=${stringify(thing[key])}`);
          });
      }
    });
    statements.push(`return ${str}`);
    return `(function(${params.join(",")}){${statements.join(";")}}(${values.join(",")}))`;
  } else {
    return str;
  }
}
function getName(num) {
  let name = "";
  do {
    name = chars[num % chars.length] + name;
    num = ~~(num / chars.length) - 1;
  } while (num >= 0);
  return reserved.test(name) ? `${name}0` : name;
}
function isPrimitive(thing) {
  return Object(thing) !== thing;
}
function stringifyPrimitive(thing) {
  if (typeof thing === "string") {
    return stringifyString(thing);
  }
  if (thing === void 0) {
    return "void 0";
  }
  if (thing === 0 && 1 / thing < 0) {
    return "-0";
  }
  const str = String(thing);
  if (typeof thing === "number") {
    return str.replace(/^(-)?0\./, "$1.");
  }
  return str;
}
function getType(thing) {
  return Object.prototype.toString.call(thing).slice(8, -1);
}
function escapeUnsafeChar(c) {
  return escaped[c] || c;
}
function escapeUnsafeChars(str) {
  return str.replace(unsafeChars, escapeUnsafeChar);
}
function safeKey(key) {
  return /^[_$a-zA-Z][_$a-zA-Z0-9]*$/.test(key) ? key : escapeUnsafeChars(JSON.stringify(key));
}
function safeProp(key) {
  return /^[_$a-zA-Z][_$a-zA-Z0-9]*$/.test(key) ? `.${key}` : `[${escapeUnsafeChars(JSON.stringify(key))}]`;
}
function stringifyString(str) {
  let result = '"';
  for (let i = 0; i < str.length; i += 1) {
    const char = str.charAt(i);
    const code = char.charCodeAt(0);
    if (char === '"') {
      result += '\\"';
    } else if (char in escaped) {
      result += escaped[char];
    } else if (code >= 55296 && code <= 57343) {
      const next = str.charCodeAt(i + 1);
      if (code <= 56319 && (next >= 56320 && next <= 57343)) {
        result += char + str[++i];
      } else {
        result += `\\u${code.toString(16).toUpperCase()}`;
      }
    } else {
      result += char;
    }
  }
  result += '"';
  return result;
}

const SiteConfigPriority = {
  nitro: -4,
  runtime: 0
};

function toValue(source) {
  if (typeof source === "function")
    return source();
  if (source && source.__v_isRef === true)
    return source.value;
  return source;
}
const NUXT_SITE_PREFIX = "NUXT_SITE_";
const NUXT_PUBLIC_SITE_PREFIX = "NUXT_PUBLIC_SITE_";
function envSiteConfig(env = {}) {
  const config = {};
  for (const key of Object.keys(env)) {
    const prefixLength = key.startsWith(NUXT_SITE_PREFIX) ? NUXT_SITE_PREFIX.length : key.startsWith(NUXT_PUBLIC_SITE_PREFIX) ? NUXT_PUBLIC_SITE_PREFIX.length : 0;
    if (!prefixLength)
      continue;
    const segments = key.slice(prefixLength).split("_");
    let configKey = segments[0].toLowerCase();
    for (let i = 1; i < segments.length; i++) {
      const segment = segments[i];
      configKey += segment[0]?.toUpperCase() + segment.slice(1).toLowerCase();
    }
    config[configKey] = env[key];
  }
  return config;
}

function normalizeSiteConfig(config) {
  if (typeof config.indexable !== "undefined")
    config.indexable = String(config.indexable) !== "false";
  if (typeof config.trailingSlash !== "undefined" && !config.trailingSlash)
    config.trailingSlash = String(config.trailingSlash) !== "false";
  if (config.url && !hasProtocol(String(config.url), { acceptRelative: true, strict: false }))
    config.url = withHttps(String(config.url));
  const keys = Object.keys(config).sort((a, b) => a.localeCompare(b));
  const newConfig = {};
  for (const k of keys)
    newConfig[k] = config[k];
  return newConfig;
}
function createSiteConfigStack(options) {
  const debug = options?.debug || false;
  const stack = [];
  function push(input) {
    if (!input || typeof input !== "object" || Object.keys(input).length === 0) {
      return () => {
      };
    }
    if (!input._context && debug) {
      let lastFunctionName = new Error("tmp").stack?.split("\n")[2]?.split(" ")[5];
      if (lastFunctionName?.includes("/"))
        lastFunctionName = "anonymous";
      input._context = lastFunctionName;
    }
    const entry = {};
    for (const k in input) {
      const val = input[k];
      if (typeof val !== "undefined" && val !== "")
        entry[k] = val;
    }
    if (!Object.keys(entry).some((k) => !k.startsWith("_"))) {
      return () => {
      };
    }
    stack.push(entry);
    return () => {
      const idx = stack.indexOf(entry);
      if (idx !== -1)
        stack.splice(idx, 1);
    };
  }
  function get(options2) {
    const siteConfig = {};
    if (options2?.debug)
      siteConfig._context = {};
    siteConfig._priority = {};
    for (const o in stack.sort((a, b) => (a._priority || 0) - (b._priority || 0))) {
      for (const k in stack[o]) {
        const key = k;
        const val = options2?.resolveRefs ? toValue(stack[o][k]) : stack[o][k];
        if (!k.startsWith("_") && typeof val !== "undefined" && val !== "") {
          siteConfig[k] = val;
          if (typeof stack[o]._priority !== "undefined" && stack[o]._priority !== -1) {
            siteConfig._priority[key] = stack[o]._priority;
          }
          if (options2?.debug)
            siteConfig._context[key] = stack[o]._context?.[key] || stack[o]._context || "anonymous";
        }
      }
    }
    return options2?.skipNormalize ? siteConfig : normalizeSiteConfig(siteConfig);
  }
  return {
    stack,
    push,
    get
  };
}

function fetchWithEvent(event, request, options) {
  return event.$fetch(request, options)
}

function withoutQuery(path) {
  const queryIndex = path.indexOf("?");
  return queryIndex === -1 ? path : path.slice(0, queryIndex);
}
function createNitroRouteRuleMatcher(runtimeConfig) {
  const { nitro, app } = runtimeConfig;
  const baseURL = app?.baseURL || "/";
  const _routeRulesMatcher = toRouteMatcher(
    createRouter$1({
      routes: Object.fromEntries(
        Object.entries(nitro?.routeRules || {}).map(([path, rules]) => [withoutTrailingSlash(path), rules])
      )
    })
  );
  return (pathOrUrl) => {
    const path = pathOrUrl[0] === "/" ? pathOrUrl : parseURL(pathOrUrl, baseURL).pathname;
    return defu({}, ..._routeRulesMatcher.matchAll(
      withoutBase(withoutTrailingSlash(withoutQuery(path)), baseURL)
    ).reverse());
  };
}

function getSiteRouteRules(event) {
  const nitroRouteRules = getRouteRules(event);
  const routeRules = nitroRouteRules;
  return {
    site: routeRules.site,
    // Nitro 3 removes matched false rules, while Nuxt treats a missing ssr rule as no-SSR.
    ssr: routeRules.ssr ?? false
  };
}

function getSiteConfig(e, _options) {
  e.context.siteConfig = e.context.siteConfig || createSiteConfigStack();
  const options = defu(_options, useRuntimeConfig(e)["nuxt-site-config"], { debug: false });
  return e.context.siteConfig.get(options);
}

const _nQ_8HELyICAm5vbpVjgHnAYQAdWDkdXg8nyccDmnnzc = defineNitroPlugin(async (nitroApp) => {
  nitroApp.hooks.hook("render:html", async (ctx, { event }) => {
    const routeOptions = getSiteRouteRules(event);
    const isIsland = process.env.NUXT_COMPONENT_ISLANDS && event.path.startsWith("/__nuxt_island");
    event.path;
    const noSSR = !!process.env.NUXT_NO_SSR || event.context.nuxt?.noSSR || routeOptions.ssr === false && !isIsland || (false);
    if (noSSR) {
      const siteConfig = Object.fromEntries(
        Object.entries(getSiteConfig(event)).map(([k, v]) => [k, toValue(v)])
      );
      ctx.body.push(`<script>window.__NUXT_SITE_CONFIG__=${devalue(siteConfig)}<\/script>`);
    }
  });
});

function defineNitroPlugin(def) {
  return def;
}

const nitroAppKey = /* @__PURE__ */ Symbol.for("sherman-box.nuxt.nitro-app");
const _FTvGgIoxtaVDyXgdNrVoLNieOHHoyI97tHwcMvjw7Jg = defineNitroPlugin((nitroApp) => {
  globalThis[nitroAppKey] = nitroApp;
});

const plugins = [
  _nQ_8HELyICAm5vbpVjgHnAYQAdWDkdXg8nyccDmnnzc,
_FTvGgIoxtaVDyXgdNrVoLNieOHHoyI97tHwcMvjw7Jg
];

const assets = {
  "/README.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"1b3-gTFOSQz0sYaL46rOmUJhcivaZ9s\"",
    "mtime": "2026-10-14T03:03:54.606Z",
    "size": 435,
    "path": "../public/README.md"
  },
  "/favicon.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"118b-uhK/EcF1CY9tZWFch7NrI5kNE8c\"",
    "mtime": "2026-10-14T03:03:54.606Z",
    "size": 4491,
    "path": "../public/favicon.ico"
  },
  "/icon.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"3d8-hst4xPB1gedluLt55UJsK0Sh14A\"",
    "mtime": "2026-10-14T03:03:54.618Z",
    "size": 984,
    "path": "../public/icon.svg.br"
  },
  "/icon.png": {
    "type": "image/png",
    "etag": "\"32aa-KMeNgc4ne5rJ+abBo5qMGva+Lmg\"",
    "mtime": "2026-10-14T03:03:54.606Z",
    "size": 12970,
    "path": "../public/icon.png"
  },
  "/icon.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"48e-scsTnL2McZuj6HhYwwAJV4AhEqg\"",
    "mtime": "2026-10-14T03:03:54.617Z",
    "size": 1166,
    "path": "../public/icon.svg.gz"
  },
  "/_nuxt/B2EmxrpI.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"1a8b-a8Mtd378IlCsrQk6zFGyzFMSK1Q\"",
    "mtime": "2026-10-14T03:03:54.590Z",
    "size": 6795,
    "path": "../public/_nuxt/B2EmxrpI.js"
  },
  "/_nuxt/B2EmxrpI.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"5af-SA2ARlHroSvuGCRcwchYajBVE6w\"",
    "mtime": "2026-10-14T03:03:54.618Z",
    "size": 1455,
    "path": "../public/_nuxt/B2EmxrpI.js.br"
  },
  "/_nuxt/B5mpj5Ch.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"461-S3pIbIL+k7+I/lYVPIsRn5O5N6Q\"",
    "mtime": "2026-10-14T03:03:54.590Z",
    "size": 1121,
    "path": "../public/_nuxt/B5mpj5Ch.js"
  },
  "/_nuxt/B2EmxrpI.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"669-bX22wsMiV25TwCwF+HbH+BMKmNg\"",
    "mtime": "2026-10-14T03:03:54.618Z",
    "size": 1641,
    "path": "../public/_nuxt/B2EmxrpI.js.gz"
  },
  "/icon.svg": {
    "type": "image/svg+xml",
    "encoding": null,
    "etag": "\"1513-bDs7E66eCb9b6tT/4zhsBqYXRhw\"",
    "mtime": "2026-10-14T03:03:54.606Z",
    "size": 5395,
    "path": "../public/icon.svg"
  },
  "/_nuxt/B5mpj5Ch.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"21e-/mNzzMb8DUqfrizPJ8U3OjkbMfE\"",
    "mtime": "2026-10-14T03:03:54.618Z",
    "size": 542,
    "path": "../public/_nuxt/B5mpj5Ch.js.br"
  },
  "/_nuxt/B5mpj5Ch.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"26a-i/ihhy0oKI2DLDp5cnZehBu69Qk\"",
    "mtime": "2026-10-14T03:03:54.618Z",
    "size": 618,
    "path": "../public/_nuxt/B5mpj5Ch.js.gz"
  },
  "/_nuxt/B6Wce-Xz.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"1283c-zMO5iNRUaW9fWKoU1KBkACNvPyk\"",
    "mtime": "2026-10-14T03:03:54.591Z",
    "size": 75836,
    "path": "../public/_nuxt/B6Wce-Xz.js"
  },
  "/_nuxt/B6Wce-Xz.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"678f-xdT2SGdxQaOaZdNDluun8Ek6ziw\"",
    "mtime": "2026-10-14T03:03:54.680Z",
    "size": 26511,
    "path": "../public/_nuxt/B6Wce-Xz.js.br"
  },
  "/_nuxt/B6Wce-Xz.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"71d4-hwMujfVGZojYw67d/f0oVoLxOXk\"",
    "mtime": "2026-10-14T03:03:54.628Z",
    "size": 29140,
    "path": "../public/_nuxt/B6Wce-Xz.js.gz"
  },
  "/_nuxt/B8Py3xKo.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1a80-i1o8AXEYsHca3AOtTbmsW0uAJSg\"",
    "mtime": "2026-10-14T03:03:54.654Z",
    "size": 6784,
    "path": "../public/_nuxt/B8Py3xKo.js.br"
  },
  "/_nuxt/B8Py3xKo.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"9f3a-IwQK/6ZjEmLPZl+oRKcn1DigSaE\"",
    "mtime": "2026-10-14T03:03:54.591Z",
    "size": 40762,
    "path": "../public/_nuxt/B8Py3xKo.js"
  },
  "/_nuxt/B8Py3xKo.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1ee9-iX5tHOViEYfvCdEU/R9D6qTrnx4\"",
    "mtime": "2026-10-14T03:03:54.618Z",
    "size": 7913,
    "path": "../public/_nuxt/B8Py3xKo.js.gz"
  },
  "/_nuxt/BAYm-95o.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"54c-6Af7CzC1E4CdYK7Ld6eSJrY2KrY\"",
    "mtime": "2026-10-14T03:03:54.591Z",
    "size": 1356,
    "path": "../public/_nuxt/BAYm-95o.js"
  },
  "/_nuxt/BAYm-95o.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"22d-bH0kOYTJeqWO8fHTjrAs+D/9ciw\"",
    "mtime": "2026-10-14T03:03:54.618Z",
    "size": 557,
    "path": "../public/_nuxt/BAYm-95o.js.br"
  },
  "/_nuxt/BAYm-95o.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"264-NdtnFU0k9sWjT42LJFhFek1m2yE\"",
    "mtime": "2026-10-14T03:03:54.618Z",
    "size": 612,
    "path": "../public/_nuxt/BAYm-95o.js.gz"
  },
  "/_nuxt/BCf3vwVN.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"5059-mJFJ7VU9UcadrFsw8JgHMhKp53Q\"",
    "mtime": "2026-10-14T03:03:54.594Z",
    "size": 20569,
    "path": "../public/_nuxt/BCf3vwVN.js"
  },
  "/_nuxt/BCf3vwVN.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"773-FkzO4KsdVbNaVZkgmFBkYgldZYM\"",
    "mtime": "2026-10-14T03:03:54.639Z",
    "size": 1907,
    "path": "../public/_nuxt/BCf3vwVN.js.br"
  },
  "/_nuxt/BCf3vwVN.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"8a3-3lNtRNfTkMr/mZgR3pq6x2nb+vc\"",
    "mtime": "2026-10-14T03:03:54.629Z",
    "size": 2211,
    "path": "../public/_nuxt/BCf3vwVN.js.gz"
  },
  "/_nuxt/2022.CI97tUjD.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2fd-8ocnKwZUrLkXrsEefFnY+Y/I4vo\"",
    "mtime": "2026-10-14T03:03:54.590Z",
    "size": 765,
    "path": "../public/_nuxt/2022.CI97tUjD.css"
  },
  "/_nuxt/BGlPB6jn.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"a43-IrhiXc7wbkgxDmm6vAlmlcLXG4Q\"",
    "mtime": "2026-10-14T03:03:54.591Z",
    "size": 2627,
    "path": "../public/_nuxt/BGlPB6jn.js"
  },
  "/_nuxt/BGlPB6jn.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"4a9-nSDGjtoZLpTE3zTV+igNPJYXPvI\"",
    "mtime": "2026-10-14T03:03:54.629Z",
    "size": 1193,
    "path": "../public/_nuxt/BGlPB6jn.js.br"
  },
  "/_nuxt/BGlPB6jn.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"5c1-bd46xxq4MuzPzfzy7nDtIqxNcXQ\"",
    "mtime": "2026-10-14T03:03:54.628Z",
    "size": 1473,
    "path": "../public/_nuxt/BGlPB6jn.js.gz"
  },
  "/_nuxt/BQcQMFMX.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"16ac-MPnI8Fg6TF0u5+k+NGBnGCIAzXM\"",
    "mtime": "2026-10-14T03:03:54.591Z",
    "size": 5804,
    "path": "../public/_nuxt/BQcQMFMX.js"
  },
  "/_nuxt/BQcQMFMX.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"837-YhyhGvRRXnajhNR4NYkiN2a415E\"",
    "mtime": "2026-10-14T03:03:54.629Z",
    "size": 2103,
    "path": "../public/_nuxt/BQcQMFMX.js.br"
  },
  "/_nuxt/BQcQMFMX.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"926-FeopDiXOWKHETKsP6QFqgQn34lQ\"",
    "mtime": "2026-10-14T03:03:54.629Z",
    "size": 2342,
    "path": "../public/_nuxt/BQcQMFMX.js.gz"
  },
  "/_nuxt/BTYKGEwI.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"520f-N+ySqKPAeqzM8YPupsSSLRDnoqo\"",
    "mtime": "2026-10-14T03:03:54.591Z",
    "size": 21007,
    "path": "../public/_nuxt/BTYKGEwI.js"
  },
  "/_nuxt/BTYKGEwI.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"a71-0fyaFmi/GEol1EbDlGweIQNnk80\"",
    "mtime": "2026-10-14T03:03:54.654Z",
    "size": 2673,
    "path": "../public/_nuxt/BTYKGEwI.js.br"
  },
  "/_nuxt/BTYKGEwI.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"c51-s6E9yyS+ICyj6g+4sW3q9z7V4wA\"",
    "mtime": "2026-10-14T03:03:54.639Z",
    "size": 3153,
    "path": "../public/_nuxt/BTYKGEwI.js.gz"
  },
  "/_nuxt/BVi8M5iI.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"233-jwNHs6NLhTKPfX5MdOpBIcMSfsg\"",
    "mtime": "2026-10-14T03:03:54.591Z",
    "size": 563,
    "path": "../public/_nuxt/BVi8M5iI.js"
  },
  "/_nuxt/BJ4YEVfk.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"118-VBE5oi0M080RQoWHLgTiMuewm0U\"",
    "mtime": "2026-10-14T03:03:54.601Z",
    "size": 280,
    "path": "../public/_nuxt/BJ4YEVfk.js"
  },
  "/_nuxt/BVqjzWu3.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"577-mKyvcPWjZQduBxiMV3wwxHpNX4c\"",
    "mtime": "2026-10-14T03:03:54.653Z",
    "size": 1399,
    "path": "../public/_nuxt/BVqjzWu3.js.br"
  },
  "/_nuxt/BVqjzWu3.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"64b-6nvMrjfP/k/jNZG+vVhGFKApEYo\"",
    "mtime": "2026-10-14T03:03:54.653Z",
    "size": 1611,
    "path": "../public/_nuxt/BVqjzWu3.js.gz"
  },
  "/_nuxt/BVqjzWu3.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"cd3-ksKw/K1pws+dKp5bprf74dCY9/0\"",
    "mtime": "2026-10-14T03:03:54.591Z",
    "size": 3283,
    "path": "../public/_nuxt/BVqjzWu3.js"
  },
  "/_nuxt/BX74yS-0.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"306b-bw+JDLYXmWd3ehnybfvEEyNEUX8\"",
    "mtime": "2026-10-14T03:03:54.711Z",
    "size": 12395,
    "path": "../public/_nuxt/BX74yS-0.js.br"
  },
  "/_nuxt/BX74yS-0.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"147e3-ucKvvhQKhI7NeERSNyAN2oTZBE4\"",
    "mtime": "2026-10-14T03:03:54.591Z",
    "size": 83939,
    "path": "../public/_nuxt/BX74yS-0.js"
  },
  "/_nuxt/BX74yS-0.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3996-yZ3Nqy3YfjXE+sYKjZuk1iW6DcI\"",
    "mtime": "2026-10-14T03:03:54.654Z",
    "size": 14742,
    "path": "../public/_nuxt/BX74yS-0.js.gz"
  },
  "/_nuxt/BY-I11O_.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"16f2-WLU8H7OO7HBTznhOc1saph5DjNM\"",
    "mtime": "2026-10-14T03:03:54.679Z",
    "size": 5874,
    "path": "../public/_nuxt/BY-I11O_.js.br"
  },
  "/_nuxt/BY-I11O_.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"4054-pojOFkXVN21KFlcDnEWMToRtblU\"",
    "mtime": "2026-10-14T03:03:54.591Z",
    "size": 16468,
    "path": "../public/_nuxt/BY-I11O_.js"
  },
  "/_nuxt/BYNC_zTf.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"b846-4hzLXFoNga5d3Gbt6UYnLO2mmyg\"",
    "mtime": "2026-10-14T03:03:54.591Z",
    "size": 47174,
    "path": "../public/_nuxt/BYNC_zTf.js"
  },
  "/_nuxt/BbfPvQbx.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"fc3-bUkiePMFk5xIaCc6/GOrCjqQM7Q\"",
    "mtime": "2026-10-14T03:03:54.591Z",
    "size": 4035,
    "path": "../public/_nuxt/BbfPvQbx.js"
  },
  "/_nuxt/BbfPvQbx.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"63f-OYSMOX5fxS+GulL9YzlQ+n7QOFk\"",
    "mtime": "2026-10-14T03:03:54.679Z",
    "size": 1599,
    "path": "../public/_nuxt/BbfPvQbx.js.br"
  },
  "/_nuxt/BYNC_zTf.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"79e2-FbWSUUzl+LgDTiEYtyy2udhvot4\"",
    "mtime": "2026-10-14T03:03:54.679Z",
    "size": 31202,
    "path": "../public/_nuxt/BYNC_zTf.js.gz"
  },
  "/_nuxt/BYNC_zTf.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"7805-5x3/WycB1IB8XScwrJh4ACE8Wi4\"",
    "mtime": "2026-10-14T03:03:54.698Z",
    "size": 30725,
    "path": "../public/_nuxt/BYNC_zTf.js.br"
  },
  "/_nuxt/BY-I11O_.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"195d-f54qlTsm5a077GEF6QTFoPS33/s\"",
    "mtime": "2026-10-14T03:03:54.654Z",
    "size": 6493,
    "path": "../public/_nuxt/BY-I11O_.js.gz"
  },
  "/_nuxt/BbfPvQbx.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"723-kSRh/dPMr2+X3fvT/2Q+nZ76Ejw\"",
    "mtime": "2026-10-14T03:03:54.679Z",
    "size": 1827,
    "path": "../public/_nuxt/BbfPvQbx.js.gz"
  },
  "/_nuxt/BcdsfY5K.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"9b11-BdMLTjlpWjjs6CvDQN5F44AeeQc\"",
    "mtime": "2026-10-14T03:03:54.592Z",
    "size": 39697,
    "path": "../public/_nuxt/BcdsfY5K.js"
  },
  "/_nuxt/BcdsfY5K.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"e50-8BEgtgavYkPPOsMRbyZ8ihTECM4\"",
    "mtime": "2026-10-14T03:03:54.694Z",
    "size": 3664,
    "path": "../public/_nuxt/BcdsfY5K.js.br"
  },
  "/_nuxt/BcdsfY5K.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1109-tsk+rp50kgIHYlApidz1n9kUvcg\"",
    "mtime": "2026-10-14T03:03:54.679Z",
    "size": 4361,
    "path": "../public/_nuxt/BcdsfY5K.js.gz"
  },
  "/_nuxt/BlOWbgTh.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"299e-3h0oZPiyHTNjZtDuWFf8XpChbW4\"",
    "mtime": "2026-10-14T03:03:54.765Z",
    "size": 10654,
    "path": "../public/_nuxt/BlOWbgTh.js.br"
  },
  "/_nuxt/BlOWbgTh.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"1612d-KjdSE4ccYE+j3A1Xduaeywv9cWU\"",
    "mtime": "2026-10-14T03:03:54.592Z",
    "size": 90413,
    "path": "../public/_nuxt/BlOWbgTh.js"
  },
  "/_nuxt/BlOWbgTh.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"32fa-XBgC60PF8OxClSx6kgI4RQrjF8Q\"",
    "mtime": "2026-10-14T03:03:54.694Z",
    "size": 13050,
    "path": "../public/_nuxt/BlOWbgTh.js.gz"
  },
  "/_nuxt/BnD7lqe8.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"1554-JP2Nh0SbFo3vCCbnkBp3JNgUUc0\"",
    "mtime": "2026-10-14T03:03:54.591Z",
    "size": 5460,
    "path": "../public/_nuxt/BnD7lqe8.js"
  },
  "/_nuxt/Blocker.CLzBPAoL.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"e0-PHEjTQqaCkQw97BXhZ47zRI5T0Y\"",
    "mtime": "2026-10-14T03:03:54.592Z",
    "size": 224,
    "path": "../public/_nuxt/Blocker.CLzBPAoL.css"
  },
  "/_nuxt/BnD7lqe8.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"636-DI0FSv5giXclP/OcJK9bwTtaM5I\"",
    "mtime": "2026-10-14T03:03:54.702Z",
    "size": 1590,
    "path": "../public/_nuxt/BnD7lqe8.js.br"
  },
  "/_nuxt/BnD7lqe8.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"751-izr5oRbyGckOizlEaIM/x6w76Mg\"",
    "mtime": "2026-10-14T03:03:54.698Z",
    "size": 1873,
    "path": "../public/_nuxt/BnD7lqe8.js.gz"
  },
  "/_nuxt/BpKmk05n.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"42b-BASenlzgRHmMyb/WleaBDEi+c9A\"",
    "mtime": "2026-10-14T03:03:54.592Z",
    "size": 1067,
    "path": "../public/_nuxt/BpKmk05n.js"
  },
  "/_nuxt/BpKmk05n.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1f4-oNBsMjWMTj0dpg+fpQDUEolvhlw\"",
    "mtime": "2026-10-14T03:03:54.698Z",
    "size": 500,
    "path": "../public/_nuxt/BpKmk05n.js.br"
  },
  "/_nuxt/BpKmk05n.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"221-iWy2/W5gQwX6IHoB3JKxT/puHuk\"",
    "mtime": "2026-10-14T03:03:54.698Z",
    "size": 545,
    "path": "../public/_nuxt/BpKmk05n.js.gz"
  },
  "/_nuxt/Bq7JSvFV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"377-dXDBAAKD7ynBbum9QnEViCA+A6g\"",
    "mtime": "2026-10-14T03:03:54.591Z",
    "size": 887,
    "path": "../public/_nuxt/Bq7JSvFV.js"
  },
  "/_nuxt/Br4VMMQb.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"1309-uPTuZQyNuJw3OVtVMRLgN+6pK7k\"",
    "mtime": "2026-10-14T03:03:54.591Z",
    "size": 4873,
    "path": "../public/_nuxt/Br4VMMQb.js"
  },
  "/_nuxt/Br4VMMQb.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"734-C1tgLuYkB/JcKVSjX8AJqveDqd0\"",
    "mtime": "2026-10-14T03:03:54.702Z",
    "size": 1844,
    "path": "../public/_nuxt/Br4VMMQb.js.br"
  },
  "/_nuxt/Br4VMMQb.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"80e-7HEwKWwjNcgF8WNBUDpPrbtzIXk\"",
    "mtime": "2026-10-14T03:03:54.702Z",
    "size": 2062,
    "path": "../public/_nuxt/Br4VMMQb.js.gz"
  },
  "/_nuxt/Btn.DxhIDkpq.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"228-6snncJtu+NpyQ+zxYylYBtmguoM\"",
    "mtime": "2026-10-14T03:03:54.591Z",
    "size": 552,
    "path": "../public/_nuxt/Btn.DxhIDkpq.css"
  },
  "/_nuxt/Bxk3u5Vr.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"7c8-NzZvlHuXuueyIcYaB36QZ8BnxSI\"",
    "mtime": "2026-10-14T03:03:54.592Z",
    "size": 1992,
    "path": "../public/_nuxt/Bxk3u5Vr.js"
  },
  "/_nuxt/Bs8ywZ6F.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"4976-1b+zIS/7ezQQg9JDhl3wxTYbSFs\"",
    "mtime": "2026-10-14T03:03:54.708Z",
    "size": 18806,
    "path": "../public/_nuxt/Bs8ywZ6F.js.gz"
  },
  "/_nuxt/Bs8ywZ6F.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"3a8c-1S3G0q5/5E1AcczOhL80yGW8ZvA\"",
    "mtime": "2026-10-14T03:03:54.884Z",
    "size": 14988,
    "path": "../public/_nuxt/Bs8ywZ6F.js.br"
  },
  "/_nuxt/Bxk3u5Vr.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"37b-SOC2T5Vc7w7VN7zhUSdoZM8CdT0\"",
    "mtime": "2026-10-14T03:03:54.709Z",
    "size": 891,
    "path": "../public/_nuxt/Bxk3u5Vr.js.br"
  },
  "/_nuxt/Bs8ywZ6F.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"2897f-sbSz2DGIlbx7O1OyyG5haGKxJhs\"",
    "mtime": "2026-10-14T03:03:54.592Z",
    "size": 166271,
    "path": "../public/_nuxt/Bs8ywZ6F.js"
  },
  "/_nuxt/Bxk3u5Vr.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3f0-2rfhtA2NUroyvqxfgrgSVkRfSEc\"",
    "mtime": "2026-10-14T03:03:54.709Z",
    "size": 1008,
    "path": "../public/_nuxt/Bxk3u5Vr.js.gz"
  },
  "/_nuxt/C6mQVgol.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"f11-rLYxaafx2t7ss16mpwQd0jnKa1c\"",
    "mtime": "2026-10-14T03:03:54.592Z",
    "size": 3857,
    "path": "../public/_nuxt/C6mQVgol.js"
  },
  "/_nuxt/C6mQVgol.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"587-Av8ej0hDjHTELPjnC2xy5smw/1M\"",
    "mtime": "2026-10-14T03:03:54.710Z",
    "size": 1415,
    "path": "../public/_nuxt/C6mQVgol.js.br"
  },
  "/_nuxt/C6mQVgol.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"671-/oBPgj8aqUWP4SkDSmvGmfQ1/8U\"",
    "mtime": "2026-10-14T03:03:54.709Z",
    "size": 1649,
    "path": "../public/_nuxt/C6mQVgol.js.gz"
  },
  "/_nuxt/C6r0mAar.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"832-uDqRpgNGU3kbPqVgPnKChOjtZOc\"",
    "mtime": "2026-10-14T03:03:54.592Z",
    "size": 2098,
    "path": "../public/_nuxt/C6r0mAar.js"
  },
  "/_nuxt/C6r0mAar.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"382-Bum1IpZ0cCHSjuIsb8Tq8Sj5OF8\"",
    "mtime": "2026-10-14T03:03:54.712Z",
    "size": 898,
    "path": "../public/_nuxt/C6r0mAar.js.br"
  },
  "/_nuxt/C8DRF5pe.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"16ace-TlQHX9bl9OBtGwvXiphXV7D8Wbs\"",
    "mtime": "2026-10-14T03:03:54.592Z",
    "size": 92878,
    "path": "../public/_nuxt/C8DRF5pe.js"
  },
  "/_nuxt/C6r0mAar.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3dc-BVMK/FWx19MG9wZW+HMLARewyqM\"",
    "mtime": "2026-10-14T03:03:54.712Z",
    "size": 988,
    "path": "../public/_nuxt/C6r0mAar.js.gz"
  },
  "/_nuxt/C8DRF5pe.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"379a-bQJEqlI2FRTYakmJRlU62rW9JRI\"",
    "mtime": "2026-10-14T03:03:54.807Z",
    "size": 14234,
    "path": "../public/_nuxt/C8DRF5pe.js.br"
  },
  "/_nuxt/C8DRF5pe.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"42d6-nWdS+xCczfDb7eE7kDMYbBsEktk\"",
    "mtime": "2026-10-14T03:03:54.712Z",
    "size": 17110,
    "path": "../public/_nuxt/C8DRF5pe.js.gz"
  },
  "/_nuxt/C9GI3bBo.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2c6-fTD2+StZM/03g0pquNiiHUNS6EE\"",
    "mtime": "2026-10-14T03:03:54.593Z",
    "size": 710,
    "path": "../public/_nuxt/C9GI3bBo.js"
  },
  "/_nuxt/C9WvjvIA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"11e-1mgp2DV/JbQ3QXs2u25DTzwMPAg\"",
    "mtime": "2026-10-14T03:03:54.592Z",
    "size": 286,
    "path": "../public/_nuxt/C9WvjvIA.js"
  },
  "/_nuxt/CCblgKSp.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"6d4-6NvhCw/Gtq5lQ3gz6E9JMRYBYQ4\"",
    "mtime": "2026-10-14T03:03:54.592Z",
    "size": 1748,
    "path": "../public/_nuxt/CCblgKSp.js"
  },
  "/_nuxt/CCblgKSp.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2e0-CQfdj0+83ibW24xQd0ayVhoObiQ\"",
    "mtime": "2026-10-14T03:03:54.758Z",
    "size": 736,
    "path": "../public/_nuxt/CCblgKSp.js.br"
  },
  "/_nuxt/CEWAUFz_.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"3d8ae-KiZm7U/2uK+8kdKarzXeuXltpf8\"",
    "mtime": "2026-10-14T03:03:55.909Z",
    "size": 252078,
    "path": "../public/_nuxt/CEWAUFz_.js.br"
  },
  "/_nuxt/CGQcPVLU.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3e8-zlNRULrozBn/lRH/nzvacRRDIrY\"",
    "mtime": "2026-10-14T03:03:54.592Z",
    "size": 1000,
    "path": "../public/_nuxt/CGQcPVLU.js"
  },
  "/_nuxt/CCblgKSp.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"344-P/l73X9jt7dEcwSXG4/MsUJrxHI\"",
    "mtime": "2026-10-14T03:03:54.758Z",
    "size": 836,
    "path": "../public/_nuxt/CCblgKSp.js.gz"
  },
  "/_nuxt/CH8WHhhf.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"f7e-KduCQvYkDbxZnTJPqhVBXk817DU\"",
    "mtime": "2026-10-14T03:03:54.592Z",
    "size": 3966,
    "path": "../public/_nuxt/CH8WHhhf.js"
  },
  "/_nuxt/CEWAUFz_.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"4dfec-7Ko65/bnmhTbRsVBuW3XNeLc80g\"",
    "mtime": "2026-10-14T03:03:55.040Z",
    "size": 319468,
    "path": "../public/_nuxt/CEWAUFz_.js.gz"
  },
  "/_nuxt/CH8WHhhf.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"584-WMGwyZQ0T5oj845b62ivpDvnTFk\"",
    "mtime": "2026-10-14T03:03:54.770Z",
    "size": 1412,
    "path": "../public/_nuxt/CH8WHhhf.js.br"
  },
  "/_nuxt/CH8WHhhf.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"65b-Hc1a0Hehy+xU+1BZ85mhoo/Jft4\"",
    "mtime": "2026-10-14T03:03:54.770Z",
    "size": 1627,
    "path": "../public/_nuxt/CH8WHhhf.js.gz"
  },
  "/_nuxt/CIanoVQR.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"d3f-pecp7bTQVH7wuizgHRM3Zvp6oSE\"",
    "mtime": "2026-10-14T03:03:54.592Z",
    "size": 3391,
    "path": "../public/_nuxt/CIanoVQR.js"
  },
  "/_nuxt/CGTBn6pR.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"24a-DkHh2gNc36wkXoQdlHubvvDKM0o\"",
    "mtime": "2026-10-14T03:03:54.593Z",
    "size": 586,
    "path": "../public/_nuxt/CGTBn6pR.js"
  },
  "/_nuxt/CIanoVQR.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"56e-61CSuJJ/PBpOwPm4yxwgWfduBkU\"",
    "mtime": "2026-10-14T03:03:54.793Z",
    "size": 1390,
    "path": "../public/_nuxt/CIanoVQR.js.br"
  },
  "/_nuxt/CIanoVQR.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"609-quPlO8OPr/BAE0KSeOSci1M0JNI\"",
    "mtime": "2026-10-14T03:03:54.793Z",
    "size": 1545,
    "path": "../public/_nuxt/CIanoVQR.js.gz"
  },
  "/_nuxt/CEWAUFz_.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"ec570-HkTpwu9UccnUbgJiMTeQVmVb5jE\"",
    "mtime": "2026-10-14T03:03:54.595Z",
    "size": 968048,
    "path": "../public/_nuxt/CEWAUFz_.js"
  },
  "/_nuxt/CJOeTw9s.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"4dca-rYcLyK0uC8XKM3gtnqq1sQfwDuA\"",
    "mtime": "2026-10-14T03:03:55.006Z",
    "size": 19914,
    "path": "../public/_nuxt/CJOeTw9s.js.br"
  },
  "/_nuxt/CJOeTw9s.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"5f16-UHjgjmq0nWoZnqcvspn361zPIp4\"",
    "mtime": "2026-10-14T03:03:54.812Z",
    "size": 24342,
    "path": "../public/_nuxt/CJOeTw9s.js.gz"
  },
  "/_nuxt/CO-pth4P.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"398b-cbaq/BfKD8CVa7HYhw0MY8U1ouM\"",
    "mtime": "2026-10-14T03:03:54.594Z",
    "size": 14731,
    "path": "../public/_nuxt/CO-pth4P.js"
  },
  "/_nuxt/CO-pth4P.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"12b3-qgr8ee4lA6cXdJ1HLj/GWcE7uT4\"",
    "mtime": "2026-10-14T03:03:54.812Z",
    "size": 4787,
    "path": "../public/_nuxt/CO-pth4P.js.br"
  },
  "/_nuxt/CJOeTw9s.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"21462-LPiaKQ4ik5wSNT6pXqTPHGLRiDo\"",
    "mtime": "2026-10-14T03:03:54.593Z",
    "size": 136290,
    "path": "../public/_nuxt/CJOeTw9s.js"
  },
  "/_nuxt/CO-pth4P.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1748-qBluq+ifpqIzZZ2Pwb/xIJGxUJg\"",
    "mtime": "2026-10-14T03:03:54.812Z",
    "size": 5960,
    "path": "../public/_nuxt/CO-pth4P.js.gz"
  },
  "/_nuxt/CPI27SfD.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"499-pby4TdpBSZVIxRXyQDwcWd6if6o\"",
    "mtime": "2026-10-14T03:03:54.593Z",
    "size": 1177,
    "path": "../public/_nuxt/CPI27SfD.js"
  },
  "/_nuxt/CPI27SfD.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"27d-wz/JLxIeXorIZusqR3DWy/bMZv4\"",
    "mtime": "2026-10-14T03:03:54.829Z",
    "size": 637,
    "path": "../public/_nuxt/CPI27SfD.js.gz"
  },
  "/_nuxt/CPI27SfD.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"241-lIlHA7keqDf2HueNdUxXMtNQWVg\"",
    "mtime": "2026-10-14T03:03:54.829Z",
    "size": 577,
    "path": "../public/_nuxt/CPI27SfD.js.br"
  },
  "/_nuxt/CRCFt6Xy.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"6e5e-4ZpMa6hjDlQio3HD0ZjP53nTCOs\"",
    "mtime": "2026-10-14T03:03:55.052Z",
    "size": 28254,
    "path": "../public/_nuxt/CRCFt6Xy.js.br"
  },
  "/_nuxt/CRCFt6Xy.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"8d82-L5niBD8Tk0ExYKYQ779kIz9uYNY\"",
    "mtime": "2026-10-14T03:03:54.886Z",
    "size": 36226,
    "path": "../public/_nuxt/CRCFt6Xy.js.gz"
  },
  "/_nuxt/CRT16HBL.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"279f-lBD3PskIe+p2T9cqfyi0KbS6o2Y\"",
    "mtime": "2026-10-14T03:03:54.886Z",
    "size": 10143,
    "path": "../public/_nuxt/CRT16HBL.js.br"
  },
  "/_nuxt/CRCFt6Xy.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"3408d-2Y0rM/+oCxNK23FdiYVzhd/P0pU\"",
    "mtime": "2026-10-14T03:03:54.593Z",
    "size": 213133,
    "path": "../public/_nuxt/CRCFt6Xy.js"
  },
  "/_nuxt/CRT16HBL.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"1b5f8-sDZ5GeM2ltuq2I+EyMX27cL4XUo\"",
    "mtime": "2026-10-14T03:03:54.593Z",
    "size": 112120,
    "path": "../public/_nuxt/CRT16HBL.js"
  },
  "/_nuxt/CRT16HBL.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"35a7-SWZjRLm+47RCljlEq8jnzBvwgGU\"",
    "mtime": "2026-10-14T03:03:54.886Z",
    "size": 13735,
    "path": "../public/_nuxt/CRT16HBL.js.gz"
  },
  "/_nuxt/CRy7nL4H.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"31-tvzNZa+9GjHSTDj2sA9bim4MfwE\"",
    "mtime": "2026-10-14T03:03:54.593Z",
    "size": 49,
    "path": "../public/_nuxt/CRy7nL4H.js"
  },
  "/_nuxt/CS7OIP7Q.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1e71-xMl5o10Y38F3XMnf6djuiUyJA+w\"",
    "mtime": "2026-10-14T03:03:55.006Z",
    "size": 7793,
    "path": "../public/_nuxt/CS7OIP7Q.js.br"
  },
  "/_nuxt/CSF65pKM.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"c4-bXYuhqMAH/WsUmMtsdLkP9DzEsI\"",
    "mtime": "2026-10-14T03:03:54.593Z",
    "size": 196,
    "path": "../public/_nuxt/CSF65pKM.js"
  },
  "/_nuxt/CS7OIP7Q.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2810-Wbkr6vt1MePwBMYbw7G1N1/3DOU\"",
    "mtime": "2026-10-14T03:03:54.923Z",
    "size": 10256,
    "path": "../public/_nuxt/CS7OIP7Q.js.gz"
  },
  "/_nuxt/CS7OIP7Q.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"1082e-Qt3B6zREc3iOPuZPlAfhT+RoTO4\"",
    "mtime": "2026-10-14T03:03:54.593Z",
    "size": 67630,
    "path": "../public/_nuxt/CS7OIP7Q.js"
  },
  "/_nuxt/CX_9SrJ8.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"f81f-KNa8eeI65ZSldWZxJSD7FZgs978\"",
    "mtime": "2026-10-14T03:03:54.593Z",
    "size": 63519,
    "path": "../public/_nuxt/CX_9SrJ8.js"
  },
  "/_nuxt/CX_9SrJ8.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2285-Gif7wCXQGkWtZB3ycNaIl+EMVlE\"",
    "mtime": "2026-10-14T03:03:55.035Z",
    "size": 8837,
    "path": "../public/_nuxt/CX_9SrJ8.js.br"
  },
  "/_nuxt/CX_9SrJ8.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2930-bVEVjtNjYBVNnMICb0rGGZ6nKqo\"",
    "mtime": "2026-10-14T03:03:55.006Z",
    "size": 10544,
    "path": "../public/_nuxt/CX_9SrJ8.js.gz"
  },
  "/_nuxt/CXlJ-Q8t.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"11147-eJlA9JMjrh+Zajj8Z0MYGFCQNq0\"",
    "mtime": "2026-10-14T03:03:54.593Z",
    "size": 69959,
    "path": "../public/_nuxt/CXlJ-Q8t.js"
  },
  "/_nuxt/CXlJ-Q8t.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2823-lCoAoBsWReO49wLuF8KE+I/BQws\"",
    "mtime": "2026-10-14T03:03:55.035Z",
    "size": 10275,
    "path": "../public/_nuxt/CXlJ-Q8t.js.br"
  },
  "/_nuxt/CXlJ-Q8t.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"303c-6GqOfOqdN3Cimv34MeSyj/sRVHw\"",
    "mtime": "2026-10-14T03:03:55.035Z",
    "size": 12348,
    "path": "../public/_nuxt/CXlJ-Q8t.js.gz"
  },
  "/_nuxt/CZD_uU4x.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"d495-rkuuZ+WQz/w+oqibdQk07ujNZZY\"",
    "mtime": "2026-10-14T03:03:54.594Z",
    "size": 54421,
    "path": "../public/_nuxt/CZD_uU4x.js"
  },
  "/_nuxt/CZD_uU4x.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"28d6-yKXSGEnefQDv2AnoGv6mKmtHNv4\"",
    "mtime": "2026-10-14T03:03:55.046Z",
    "size": 10454,
    "path": "../public/_nuxt/CZD_uU4x.js.br"
  },
  "/_nuxt/CZD_uU4x.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2fcd-Ak36mkXK6V+cFADbpzev/6eCb/4\"",
    "mtime": "2026-10-14T03:03:55.035Z",
    "size": 12237,
    "path": "../public/_nuxt/CZD_uU4x.js.gz"
  },
  "/_nuxt/CZyDtQ9l.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"5fa8-s9AeuhqXmPHFqg3KijAM3pGik9M\"",
    "mtime": "2026-10-14T03:03:54.594Z",
    "size": 24488,
    "path": "../public/_nuxt/CZyDtQ9l.js"
  },
  "/_nuxt/CZyDtQ9l.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"d84-576Ob+RfcZiaUfXEWX8B4PWMS7Y\"",
    "mtime": "2026-10-14T03:03:55.037Z",
    "size": 3460,
    "path": "../public/_nuxt/CZyDtQ9l.js.br"
  },
  "/_nuxt/CZyDtQ9l.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"fd9-zzQTrtkgha9qpvAS05J8D+0C1B0\"",
    "mtime": "2026-10-14T03:03:55.037Z",
    "size": 4057,
    "path": "../public/_nuxt/CZyDtQ9l.js.gz"
  },
  "/_nuxt/Card.G8M3Y9cQ.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"fa-bod32o5HBf/MVR/cxQWc1j3DKh0\"",
    "mtime": "2026-10-14T03:03:54.593Z",
    "size": 250,
    "path": "../public/_nuxt/Card.G8M3Y9cQ.css"
  },
  "/_nuxt/CategoryBox.BxKyFRkZ.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3b5-/JLDnoRHuMI1KSrjozhiC0MLr1k\"",
    "mtime": "2026-10-14T03:03:54.593Z",
    "size": 949,
    "path": "../public/_nuxt/CategoryBox.BxKyFRkZ.css"
  },
  "/_nuxt/Ce4vQFvB.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"20c3-gqMY8qrk/yzG/EpCXLPueSa3J60\"",
    "mtime": "2026-10-14T03:03:54.593Z",
    "size": 8387,
    "path": "../public/_nuxt/Ce4vQFvB.js"
  },
  "/_nuxt/Ce4vQFvB.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"c6d-Rq2cAobg1fCwRG+DdZhp2Aw0gEA\"",
    "mtime": "2026-10-14T03:03:55.048Z",
    "size": 3181,
    "path": "../public/_nuxt/Ce4vQFvB.js.br"
  },
  "/_nuxt/Ce4vQFvB.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"e2e-PSnDaAk0KeHWXR/TYvTaQmYerJ0\"",
    "mtime": "2026-10-14T03:03:55.046Z",
    "size": 3630,
    "path": "../public/_nuxt/Ce4vQFvB.js.gz"
  },
  "/_nuxt/CfQOth17.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"b63-Mj5GQebw+6m5robIxrgY8ske4k0\"",
    "mtime": "2026-10-14T03:03:54.593Z",
    "size": 2915,
    "path": "../public/_nuxt/CfQOth17.js"
  },
  "/_nuxt/CfQOth17.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"523-leZrvWmR7Jjpslz+zobPTKxD+E0\"",
    "mtime": "2026-10-14T03:03:55.048Z",
    "size": 1315,
    "path": "../public/_nuxt/CfQOth17.js.br"
  },
  "/_nuxt/CfQOth17.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"5e6-q6Ei6XFsIzXhNOLRb7R9vr8z3GM\"",
    "mtime": "2026-10-14T03:03:55.048Z",
    "size": 1510,
    "path": "../public/_nuxt/CfQOth17.js.gz"
  },
  "/_nuxt/Cfo4ibeV.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"1915-fFESWXAPwtpOf9JsGDq31bLCQW8\"",
    "mtime": "2026-10-14T03:03:54.594Z",
    "size": 6421,
    "path": "../public/_nuxt/Cfo4ibeV.js"
  },
  "/_nuxt/Cfo4ibeV.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"84d-PwhjwUxTXZBbgNHvJkZWA8fnEYM\"",
    "mtime": "2026-10-14T03:03:55.049Z",
    "size": 2125,
    "path": "../public/_nuxt/Cfo4ibeV.js.br"
  },
  "/_nuxt/Cfo4ibeV.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"9a4-gBww4yu0i0TCjUJl5kYIiWPpf18\"",
    "mtime": "2026-10-14T03:03:55.048Z",
    "size": 2468,
    "path": "../public/_nuxt/Cfo4ibeV.js.gz"
  },
  "/_nuxt/Cfvh-qpK.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"5016-LhdMVm33vCU9DVOrtCNhfX7wNLE\"",
    "mtime": "2026-10-14T03:03:54.597Z",
    "size": 20502,
    "path": "../public/_nuxt/Cfvh-qpK.js"
  },
  "/_nuxt/Cfvh-qpK.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1e10-YDwtJKw3jK3BqcWwFbl+GEJ766M\"",
    "mtime": "2026-10-14T03:03:55.067Z",
    "size": 7696,
    "path": "../public/_nuxt/Cfvh-qpK.js.br"
  },
  "/_nuxt/Cfvh-qpK.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2127-4fNgajEjaJN5N1dOXM93DbWPMKM\"",
    "mtime": "2026-10-14T03:03:55.049Z",
    "size": 8487,
    "path": "../public/_nuxt/Cfvh-qpK.js.gz"
  },
  "/_nuxt/CjaD7GZO.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"98ef-qVdAqSgbbv09mGa8fXYIPA0iSdg\"",
    "mtime": "2026-10-14T03:03:54.594Z",
    "size": 39151,
    "path": "../public/_nuxt/CjaD7GZO.js"
  },
  "/_nuxt/CjaD7GZO.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1deb-0PG3edPMoEG57sLkGjLvpXQpvG8\"",
    "mtime": "2026-10-14T03:03:55.051Z",
    "size": 7659,
    "path": "../public/_nuxt/CjaD7GZO.js.gz"
  },
  "/_nuxt/CjaD7GZO.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"197b-/HJUVbNxu8rwfwZPdHRL5N1uy90\"",
    "mtime": "2026-10-14T03:03:55.091Z",
    "size": 6523,
    "path": "../public/_nuxt/CjaD7GZO.js.br"
  },
  "/_nuxt/Cjo4dTJS.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3fd-gGkj/1aFeoI/CCGBpLlPvIwhcmM\"",
    "mtime": "2026-10-14T03:03:54.593Z",
    "size": 1021,
    "path": "../public/_nuxt/Cjo4dTJS.js"
  },
  "/_nuxt/Comment.CnrHHgid.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"611-7cSD5GKmdXR+Id3J3uNL2e8I208\"",
    "mtime": "2026-10-14T03:03:54.594Z",
    "size": 1553,
    "path": "../public/_nuxt/Comment.CnrHHgid.css"
  },
  "/_nuxt/Comment.CnrHHgid.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"1be-1TJfU2+KOiQw4zytLdJbIISVGTk\"",
    "mtime": "2026-10-14T03:03:55.052Z",
    "size": 446,
    "path": "../public/_nuxt/Comment.CnrHHgid.css.br"
  },
  "/_nuxt/Comment.CnrHHgid.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"24e-4xx6TLCyU97+U9E3Hjpz30pDSVU\"",
    "mtime": "2026-10-14T03:03:55.052Z",
    "size": 590,
    "path": "../public/_nuxt/Comment.CnrHHgid.css.gz"
  },
  "/_nuxt/CrRdQ_J8.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"334d-/+JBbOH1av6CkGZv9UNj+JWNF38\"",
    "mtime": "2026-10-14T03:03:54.594Z",
    "size": 13133,
    "path": "../public/_nuxt/CrRdQ_J8.js"
  },
  "/_nuxt/CrRdQ_J8.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1187-Yi6SEOioARjmvc9ZUnJbabHSZQ4\"",
    "mtime": "2026-10-14T03:03:55.063Z",
    "size": 4487,
    "path": "../public/_nuxt/CrRdQ_J8.js.br"
  },
  "/_nuxt/CrRdQ_J8.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"149c-APERfBtV9ABcwpFQLKpc2/FZYgg\"",
    "mtime": "2026-10-14T03:03:55.063Z",
    "size": 5276,
    "path": "../public/_nuxt/CrRdQ_J8.js.gz"
  },
  "/_nuxt/CrnJebJY.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"e23-1/01v2j0hn4Pp1Ln9U29A9Kx+MU\"",
    "mtime": "2026-10-14T03:03:54.594Z",
    "size": 3619,
    "path": "../public/_nuxt/CrnJebJY.js"
  },
  "/_nuxt/CrnJebJY.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"54c-qyiCeMUkahbviZvgbl10GaextYo\"",
    "mtime": "2026-10-14T03:03:55.076Z",
    "size": 1356,
    "path": "../public/_nuxt/CrnJebJY.js.br"
  },
  "/_nuxt/CrnJebJY.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"624-lRpXnOcSrrQolosmfoP71sLo2PI\"",
    "mtime": "2026-10-14T03:03:55.067Z",
    "size": 1572,
    "path": "../public/_nuxt/CrnJebJY.js.gz"
  },
  "/_nuxt/CustomText.DisFWttn.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"b6-j6KRt5usUhfgJyEoe6gEBvFaSnI\"",
    "mtime": "2026-10-14T03:03:54.594Z",
    "size": 182,
    "path": "../public/_nuxt/CustomText.DisFWttn.css"
  },
  "/_nuxt/D-9OCkCf.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"e9b1-wNoFUcVFEm/F7L1DQqvXgc4Q1Ok\"",
    "mtime": "2026-10-14T03:03:54.595Z",
    "size": 59825,
    "path": "../public/_nuxt/D-9OCkCf.js"
  },
  "/_nuxt/D-9OCkCf.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2466-uWQtCt8vv/IbZSy0SP/FXY2YQyM\"",
    "mtime": "2026-10-14T03:03:55.127Z",
    "size": 9318,
    "path": "../public/_nuxt/D-9OCkCf.js.br"
  },
  "/_nuxt/D-9OCkCf.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2a93-bCgc8gbXtI9QZE11LiyI2HFN4Es\"",
    "mtime": "2026-10-14T03:03:55.076Z",
    "size": 10899,
    "path": "../public/_nuxt/D-9OCkCf.js.gz"
  },
  "/_nuxt/D-saP4yj.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"224b-nGYi/AJ0WX8iB2dNh6RB8RRNbEY\"",
    "mtime": "2026-10-14T03:03:54.594Z",
    "size": 8779,
    "path": "../public/_nuxt/D-saP4yj.js"
  },
  "/_nuxt/D-saP4yj.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"6f3-3spwsJEzzFFwa1DsRoKjvQd9cNA\"",
    "mtime": "2026-10-14T03:03:55.077Z",
    "size": 1779,
    "path": "../public/_nuxt/D-saP4yj.js.br"
  },
  "/_nuxt/D-saP4yj.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"7ee-+uqv64glVAmprTPSHEQGf+MtZds\"",
    "mtime": "2026-10-14T03:03:55.077Z",
    "size": 2030,
    "path": "../public/_nuxt/D-saP4yj.js.gz"
  },
  "/_nuxt/D0YHTmrP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"307-1FAQXR6bkGf5plKnOgctwN19wkY\"",
    "mtime": "2026-10-14T03:03:54.595Z",
    "size": 775,
    "path": "../public/_nuxt/D0YHTmrP.js"
  },
  "/_nuxt/D0j5Mwnz.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"fc3-PZeJLJ7iU0ApgeZPSZRI16/Bhr8\"",
    "mtime": "2026-10-14T03:03:54.594Z",
    "size": 4035,
    "path": "../public/_nuxt/D0j5Mwnz.js"
  },
  "/_nuxt/D0j5Mwnz.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"5a4-1dR0guleBo1pmU+2saxkJ1mULRY\"",
    "mtime": "2026-10-14T03:03:55.082Z",
    "size": 1444,
    "path": "../public/_nuxt/D0j5Mwnz.js.br"
  },
  "/_nuxt/D0j5Mwnz.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"6b8-71WWem6nsFYhIPYEeMNuwf/0jSA\"",
    "mtime": "2026-10-14T03:03:55.082Z",
    "size": 1720,
    "path": "../public/_nuxt/D0j5Mwnz.js.gz"
  },
  "/_nuxt/D4YtX_0h.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"a1a-Tc9i4/xgTOh9VyeFedu/bSXczWQ\"",
    "mtime": "2026-10-14T03:03:54.594Z",
    "size": 2586,
    "path": "../public/_nuxt/D4YtX_0h.js"
  },
  "/_nuxt/D4YtX_0h.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"430-E9+k4L4Univ0FVPjpw+jrc2F4MA\"",
    "mtime": "2026-10-14T03:03:55.086Z",
    "size": 1072,
    "path": "../public/_nuxt/D4YtX_0h.js.br"
  },
  "/_nuxt/D4YtX_0h.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"4b4-bBIiJ38Hw4Yy823lrq3Db9Z7Eaw\"",
    "mtime": "2026-10-14T03:03:55.086Z",
    "size": 1204,
    "path": "../public/_nuxt/D4YtX_0h.js.gz"
  },
  "/_nuxt/D7nzPzJy.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"cd2-thFyzYIoQF5P96riyj+ZFbnCz8U\"",
    "mtime": "2026-10-14T03:03:54.595Z",
    "size": 3282,
    "path": "../public/_nuxt/D7nzPzJy.js"
  },
  "/_nuxt/D7nzPzJy.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"564-7t5HhuvVtlYqhEkwPo/WKtGKvWs\"",
    "mtime": "2026-10-14T03:03:55.090Z",
    "size": 1380,
    "path": "../public/_nuxt/D7nzPzJy.js.br"
  },
  "/_nuxt/D7nzPzJy.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"5e5-S1x+Bj2D8RSgigrDhrRtCKWxXcg\"",
    "mtime": "2026-10-14T03:03:55.090Z",
    "size": 1509,
    "path": "../public/_nuxt/D7nzPzJy.js.gz"
  },
  "/_nuxt/D83hSOGR.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"128d3-hpMCkmEHE/6SsLoWI8Mtw1xA5Ew\"",
    "mtime": "2026-10-14T03:03:54.595Z",
    "size": 75987,
    "path": "../public/_nuxt/D83hSOGR.js"
  },
  "/_nuxt/D83hSOGR.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"24ca-yWKXqupBoSYGyLB6ABK8jfVKq+w\"",
    "mtime": "2026-10-14T03:03:55.144Z",
    "size": 9418,
    "path": "../public/_nuxt/D83hSOGR.js.br"
  },
  "/_nuxt/D83hSOGR.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2d4e-5y8E+JetWNq2LnMO+Lo1ppasV94\"",
    "mtime": "2026-10-14T03:03:55.091Z",
    "size": 11598,
    "path": "../public/_nuxt/D83hSOGR.js.gz"
  },
  "/_nuxt/D9WzmH9C.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"38b-EjGbtMVKSZ5iSIQTLmx/A7x+n90\"",
    "mtime": "2026-10-14T03:03:54.595Z",
    "size": 907,
    "path": "../public/_nuxt/D9WzmH9C.js"
  },
  "/_nuxt/DC4zTXfO.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"2704-waMx/W348mOrCpMon6mhzOmHPQM\"",
    "mtime": "2026-10-14T03:03:54.594Z",
    "size": 9988,
    "path": "../public/_nuxt/DC4zTXfO.js"
  },
  "/_nuxt/DC4zTXfO.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"ee9-hKwYtlAA30s9fVjKn/SqdWNyPNA\"",
    "mtime": "2026-10-14T03:03:55.120Z",
    "size": 3817,
    "path": "../public/_nuxt/DC4zTXfO.js.br"
  },
  "/_nuxt/DC4zTXfO.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1071-RMusx85vWVEqZ7yRgNphRsvkgDQ\"",
    "mtime": "2026-10-14T03:03:55.120Z",
    "size": 4209,
    "path": "../public/_nuxt/DC4zTXfO.js.gz"
  },
  "/_nuxt/DFhYur8N.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"5f62-BSpDL2gHpvPlj/5JI1O7TZGWnA4\"",
    "mtime": "2026-10-14T03:03:54.595Z",
    "size": 24418,
    "path": "../public/_nuxt/DFhYur8N.js"
  },
  "/_nuxt/DFhYur8N.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1fba-vIGU2apx5NMGACS8EP5p/bEuSoQ\"",
    "mtime": "2026-10-14T03:03:55.120Z",
    "size": 8122,
    "path": "../public/_nuxt/DFhYur8N.js.br"
  },
  "/_nuxt/DFhYur8N.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"23ff-e4W8TsH8NX2YWamTVG//uAmOKtI\"",
    "mtime": "2026-10-14T03:03:55.120Z",
    "size": 9215,
    "path": "../public/_nuxt/DFhYur8N.js.gz"
  },
  "/_nuxt/DMwEXZbT.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"da-545OZ2lSFTqMxH3nEW4ACUjsg+w\"",
    "mtime": "2026-10-14T03:03:54.594Z",
    "size": 218,
    "path": "../public/_nuxt/DMwEXZbT.js"
  },
  "/_nuxt/DNvb-mDF.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"a0a-+8VrRsAqA4uiMNVn07tMFtTXBbU\"",
    "mtime": "2026-10-14T03:03:54.595Z",
    "size": 2570,
    "path": "../public/_nuxt/DNvb-mDF.js"
  },
  "/_nuxt/DNvb-mDF.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"41f-Qr+uMy/JZvs6NZtD42RIZFJ0uMk\"",
    "mtime": "2026-10-14T03:03:55.125Z",
    "size": 1055,
    "path": "../public/_nuxt/DNvb-mDF.js.br"
  },
  "/_nuxt/DNvb-mDF.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"4a5-X9/yRNZZWm6bycusup49skW2AvQ\"",
    "mtime": "2026-10-14T03:03:55.124Z",
    "size": 1189,
    "path": "../public/_nuxt/DNvb-mDF.js.gz"
  },
  "/_nuxt/DQD_g528.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"56c6-32y+X7cxnrmAjIqwayUbLfJH9jo\"",
    "mtime": "2026-10-14T03:03:54.595Z",
    "size": 22214,
    "path": "../public/_nuxt/DQD_g528.js"
  },
  "/_nuxt/DQD_g528.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"a85-m3+kNvXmuHOrDj6HKv4439qJ8/A\"",
    "mtime": "2026-10-14T03:03:55.147Z",
    "size": 2693,
    "path": "../public/_nuxt/DQD_g528.js.br"
  },
  "/_nuxt/DQD_g528.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"c92-rq1VYOWq5bifWj/rNqM9yGWh0eQ\"",
    "mtime": "2026-10-14T03:03:55.127Z",
    "size": 3218,
    "path": "../public/_nuxt/DQD_g528.js.gz"
  },
  "/_nuxt/DQzRQykB.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"a7f-rhLJvo8ES93uM9l9a/blSGYcCBk\"",
    "mtime": "2026-10-14T03:03:54.595Z",
    "size": 2687,
    "path": "../public/_nuxt/DQzRQykB.js"
  },
  "/_nuxt/DQzRQykB.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"3ed-xeKp+rAVcP7WCy4+dGDo/QVZCmU\"",
    "mtime": "2026-10-14T03:03:55.133Z",
    "size": 1005,
    "path": "../public/_nuxt/DQzRQykB.js.br"
  },
  "/_nuxt/DQzRQykB.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"4a0-GZMIyfj0jSZQtwtDbh1zig+wkyA\"",
    "mtime": "2026-10-14T03:03:55.133Z",
    "size": 1184,
    "path": "../public/_nuxt/DQzRQykB.js.gz"
  },
  "/_nuxt/DUnisXQO.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"8d4-T4wCofeJwkkqJM94mHEa3NwdCvw\"",
    "mtime": "2026-10-14T03:03:54.595Z",
    "size": 2260,
    "path": "../public/_nuxt/DUnisXQO.js"
  },
  "/_nuxt/DUnisXQO.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"3bf-Sgiglqjecb1wcX/S2sPHI7jEviY\"",
    "mtime": "2026-10-14T03:03:55.134Z",
    "size": 959,
    "path": "../public/_nuxt/DUnisXQO.js.br"
  },
  "/_nuxt/DUnisXQO.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"45d-F7jGLeWRtgKu7cMQUz1cny4wS7U\"",
    "mtime": "2026-10-14T03:03:55.134Z",
    "size": 1117,
    "path": "../public/_nuxt/DUnisXQO.js.gz"
  },
  "/_nuxt/DVjM6mC1.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"a27-PiwZSBPrGs+d9LhiEHDtKu1QsOw\"",
    "mtime": "2026-10-14T03:03:54.595Z",
    "size": 2599,
    "path": "../public/_nuxt/DVjM6mC1.js"
  },
  "/_nuxt/DVjM6mC1.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"47b-4R/W1YKVi38TcTXIsd77kqNBFyw\"",
    "mtime": "2026-10-14T03:03:55.134Z",
    "size": 1147,
    "path": "../public/_nuxt/DVjM6mC1.js.br"
  },
  "/_nuxt/DVjM6mC1.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"51b-XdJpdbZzC8nXYCI1tOI0FdkQ7Rg\"",
    "mtime": "2026-10-14T03:03:55.134Z",
    "size": 1307,
    "path": "../public/_nuxt/DVjM6mC1.js.gz"
  },
  "/_nuxt/DXPYF4MY.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"6d9-IwDNRpSAbAjqDP+E9ss9IhQHfBk\"",
    "mtime": "2026-10-14T03:03:54.595Z",
    "size": 1753,
    "path": "../public/_nuxt/DXPYF4MY.js"
  },
  "/_nuxt/DXPYF4MY.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"32f-SsvWtV8vdQ3VC/T4JatQFq51SZc\"",
    "mtime": "2026-10-14T03:03:55.143Z",
    "size": 815,
    "path": "../public/_nuxt/DXPYF4MY.js.br"
  },
  "/_nuxt/DXPYF4MY.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"379-QVvYSdtpyeK8UsGs1TcGGu2PXAY\"",
    "mtime": "2026-10-14T03:03:55.143Z",
    "size": 889,
    "path": "../public/_nuxt/DXPYF4MY.js.gz"
  },
  "/_nuxt/DaHUyXxF.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"23a57-2W0GenMQKl8vtd4FVTCSMzscwEo\"",
    "mtime": "2026-10-14T03:03:55.891Z",
    "size": 146007,
    "path": "../public/_nuxt/DaHUyXxF.js.br"
  },
  "/_nuxt/DdTCpZzg.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"c1b7-/lqlFdof6dhVfSC13caecgE6gyY\"",
    "mtime": "2026-10-14T03:03:54.596Z",
    "size": 49591,
    "path": "../public/_nuxt/DdTCpZzg.js"
  },
  "/_nuxt/DdTCpZzg.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1ce4-+sprEPghqcnyEWzhy63fRhWIPDo\"",
    "mtime": "2026-10-14T03:03:55.269Z",
    "size": 7396,
    "path": "../public/_nuxt/DdTCpZzg.js.br"
  },
  "/_nuxt/DaHUyXxF.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2aec1-IMrXvoL4O0pU8jrjVCLQKwRmTaE\"",
    "mtime": "2026-10-14T03:03:55.391Z",
    "size": 175809,
    "path": "../public/_nuxt/DaHUyXxF.js.gz"
  },
  "/_nuxt/DhN7LKPx.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"487-sTF3DLQeBIRrhcc+/AQuxWirNa4\"",
    "mtime": "2026-10-14T03:03:54.595Z",
    "size": 1159,
    "path": "../public/_nuxt/DhN7LKPx.js"
  },
  "/_nuxt/DhN7LKPx.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"22c-M2X06freRyFS9uo54kRGkCjdU00\"",
    "mtime": "2026-10-14T03:03:55.206Z",
    "size": 556,
    "path": "../public/_nuxt/DhN7LKPx.js.br"
  },
  "/_nuxt/DhN7LKPx.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"26f-Ip9esIt4YTq3R1KF+dtDGKs/hhY\"",
    "mtime": "2026-10-14T03:03:55.206Z",
    "size": 623,
    "path": "../public/_nuxt/DhN7LKPx.js.gz"
  },
  "/_nuxt/DdTCpZzg.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"21d6-mMpW/u0Pjk0+cr65Dh0r8ozblX0\"",
    "mtime": "2026-10-14T03:03:55.154Z",
    "size": 8662,
    "path": "../public/_nuxt/DdTCpZzg.js.gz"
  },
  "/_nuxt/DjD8__q3.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"150a2-HXKhZ00mLnXQSGwPkU3rc0VRczk\"",
    "mtime": "2026-10-14T03:03:54.595Z",
    "size": 86178,
    "path": "../public/_nuxt/DjD8__q3.js"
  },
  "/_nuxt/DjD8__q3.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"597c-irGJWXRtozpI/N9YBy58F01n05A\"",
    "mtime": "2026-10-14T03:03:55.324Z",
    "size": 22908,
    "path": "../public/_nuxt/DjD8__q3.js.br"
  },
  "/_nuxt/DjD8__q3.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"5e1c-/hRO7YJ8x/2nVhHd1tXpH2aM8tk\"",
    "mtime": "2026-10-14T03:03:55.270Z",
    "size": 24092,
    "path": "../public/_nuxt/DjD8__q3.js.gz"
  },
  "/_nuxt/Dk60Kzj3.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"3fea-ykIL1cmtjT/RTvF17UUFvvwvaa0\"",
    "mtime": "2026-10-14T03:03:55.381Z",
    "size": 16362,
    "path": "../public/_nuxt/Dk60Kzj3.js.br"
  },
  "/_nuxt/Dk60Kzj3.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"5054-xjQvK6S85sFnrUMPNcs2DnU5f80\"",
    "mtime": "2026-10-14T03:03:55.324Z",
    "size": 20564,
    "path": "../public/_nuxt/Dk60Kzj3.js.gz"
  },
  "/_nuxt/DlNU78l3.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"78f4-Kajb/3p94yGARq0QIBy5zGRvGec\"",
    "mtime": "2026-10-14T03:03:54.596Z",
    "size": 30964,
    "path": "../public/_nuxt/DlNU78l3.js"
  },
  "/_nuxt/DlNU78l3.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"61d-sY/EgMvTcsVZ49Zs/6vnnTx7tTw\"",
    "mtime": "2026-10-14T03:03:55.270Z",
    "size": 1565,
    "path": "../public/_nuxt/DlNU78l3.js.br"
  },
  "/_nuxt/Dk60Kzj3.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"1d78d-XGwxtcmPYiG7DFted6X6MuWvgpQ\"",
    "mtime": "2026-10-14T03:03:54.596Z",
    "size": 120717,
    "path": "../public/_nuxt/Dk60Kzj3.js"
  },
  "/_nuxt/DlNU78l3.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"7fc-LD484HC3NNP6VcCjA8K7P6vV8w0\"",
    "mtime": "2026-10-14T03:03:55.270Z",
    "size": 2044,
    "path": "../public/_nuxt/DlNU78l3.js.gz"
  },
  "/_nuxt/Dla4zvXa.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"d4ce-gGQD6qEP/W7ZRdSer92mNvsGWYg\"",
    "mtime": "2026-10-14T03:03:54.596Z",
    "size": 54478,
    "path": "../public/_nuxt/Dla4zvXa.js"
  },
  "/_nuxt/DaHUyXxF.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"a1d67-DpuAr34wo+R5GY476YpFXjjpfcc\"",
    "mtime": "2026-10-14T03:03:54.596Z",
    "size": 662887,
    "path": "../public/_nuxt/DaHUyXxF.js"
  },
  "/_nuxt/Dla4zvXa.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1cc2-tT6STzF2lWTOe3skURnbdWn0D2g\"",
    "mtime": "2026-10-14T03:03:55.333Z",
    "size": 7362,
    "path": "../public/_nuxt/Dla4zvXa.js.br"
  },
  "/_nuxt/Dla4zvXa.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"22a4-UnLy3PJIheN+L3UHcAHyczGpVVo\"",
    "mtime": "2026-10-14T03:03:55.333Z",
    "size": 8868,
    "path": "../public/_nuxt/Dla4zvXa.js.gz"
  },
  "/_nuxt/DoEnXPkC.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2d2d-Z9DlcMZ+8x3mnvp3bMHWXgXW5IA\"",
    "mtime": "2026-10-14T03:03:55.381Z",
    "size": 11565,
    "path": "../public/_nuxt/DoEnXPkC.js.gz"
  },
  "/_nuxt/DoEnXPkC.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"25f5-gxZe5KvjMX0lX5yLULFi59Z1dxM\"",
    "mtime": "2026-10-14T03:03:55.384Z",
    "size": 9717,
    "path": "../public/_nuxt/DoEnXPkC.js.br"
  },
  "/_nuxt/DoEnXPkC.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"107c1-ZvMOhK4vlEdUW4YOnP3z+aRERJM\"",
    "mtime": "2026-10-14T03:03:54.597Z",
    "size": 67521,
    "path": "../public/_nuxt/DoEnXPkC.js"
  },
  "/_nuxt/Dpit6csX.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"130d9-5csXOylFSUA8JWUW3odFkLu/PSE\"",
    "mtime": "2026-10-14T03:03:54.596Z",
    "size": 78041,
    "path": "../public/_nuxt/Dpit6csX.js"
  },
  "/_nuxt/Dpit6csX.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2719-U/a5uZkq1fs4TMKHhoZru5lPJCA\"",
    "mtime": "2026-10-14T03:03:55.409Z",
    "size": 10009,
    "path": "../public/_nuxt/Dpit6csX.js.br"
  },
  "/_nuxt/Dpit6csX.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2f26-/AFQiGeub8QWa88gWJkD/0LxQfI\"",
    "mtime": "2026-10-14T03:03:55.383Z",
    "size": 12070,
    "path": "../public/_nuxt/Dpit6csX.js.gz"
  },
  "/_nuxt/DsTF1-7j.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2a0-tozmaKAALAsfVmSpAjeHSmIo8t0\"",
    "mtime": "2026-10-14T03:03:55.391Z",
    "size": 672,
    "path": "../public/_nuxt/DsTF1-7j.js.br"
  },
  "/_nuxt/DsTF1-7j.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"635-zCtQIBr1FuNDb4/UjIm5tG8tAxA\"",
    "mtime": "2026-10-14T03:03:54.597Z",
    "size": 1589,
    "path": "../public/_nuxt/DsTF1-7j.js"
  },
  "/_nuxt/DsTF1-7j.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2f2-S2MNM+5Rx7cJzLHIqiuPPG/eBX8\"",
    "mtime": "2026-10-14T03:03:55.391Z",
    "size": 754,
    "path": "../public/_nuxt/DsTF1-7j.js.gz"
  },
  "/_nuxt/FWEZXKig.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"19d9-vneXp/9wHPNZbC0QV7kllq4tvLk\"",
    "mtime": "2026-10-14T03:03:54.597Z",
    "size": 6617,
    "path": "../public/_nuxt/FWEZXKig.js"
  },
  "/_nuxt/FWEZXKig.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"413-Juvz1LgVI6kMHMdv7sndHrj4ZWI\"",
    "mtime": "2026-10-14T03:03:55.395Z",
    "size": 1043,
    "path": "../public/_nuxt/FWEZXKig.js.br"
  },
  "/_nuxt/FWEZXKig.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"4b5-ewVOKZUHP6CukTI78WgTrQi1bjA\"",
    "mtime": "2026-10-14T03:03:55.395Z",
    "size": 1205,
    "path": "../public/_nuxt/FWEZXKig.js.gz"
  },
  "/_nuxt/FormItem.CmSOro24.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"21d-78vxuTE0m6ri48mZMTifIIFPC7A\"",
    "mtime": "2026-10-14T03:03:54.597Z",
    "size": 541,
    "path": "../public/_nuxt/FormItem.CmSOro24.css"
  },
  "/_nuxt/G-JxC2Ai.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"1580-iK+WeMQGHlLCJKc6KEkV4gPQlwg\"",
    "mtime": "2026-10-14T03:03:54.597Z",
    "size": 5504,
    "path": "../public/_nuxt/G-JxC2Ai.js"
  },
  "/_nuxt/G-JxC2Ai.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"502-vXbemsEU0j8r40/e+PObtoEAFi0\"",
    "mtime": "2026-10-14T03:03:55.407Z",
    "size": 1282,
    "path": "../public/_nuxt/G-JxC2Ai.js.br"
  },
  "/_nuxt/G-JxC2Ai.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"5a9-5YOh6lb0KRTIkE1tewKAFaCB8/c\"",
    "mtime": "2026-10-14T03:03:55.407Z",
    "size": 1449,
    "path": "../public/_nuxt/G-JxC2Ai.js.gz"
  },
  "/_nuxt/GDeLawt4.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"11c5d-FlWDyebpbxIL2w6GWZBnY6AtVWo\"",
    "mtime": "2026-10-14T03:03:54.597Z",
    "size": 72797,
    "path": "../public/_nuxt/GDeLawt4.js"
  },
  "/_nuxt/GDeLawt4.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"28df-UeFtTpUGnV6Q35UzxEG7pT5qqa4\"",
    "mtime": "2026-10-14T03:03:55.468Z",
    "size": 10463,
    "path": "../public/_nuxt/GDeLawt4.js.br"
  },
  "/_nuxt/GDeLawt4.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"310c-67NuL/evzpD5ao2mcyGssGUOTOA\"",
    "mtime": "2026-10-14T03:03:55.409Z",
    "size": 12556,
    "path": "../public/_nuxt/GDeLawt4.js.gz"
  },
  "/_nuxt/InfoBox.aXwElSbB.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"440-7ciaIFKUYAvX+pHh9UD+DNLAfmI\"",
    "mtime": "2026-10-14T03:03:54.597Z",
    "size": 1088,
    "path": "../public/_nuxt/InfoBox.aXwElSbB.css"
  },
  "/_nuxt/InfoBox.aXwElSbB.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1fa-NhSuj23np6ClTUXKkYaSyrnINas\"",
    "mtime": "2026-10-14T03:03:55.459Z",
    "size": 506,
    "path": "../public/_nuxt/InfoBox.aXwElSbB.css.gz"
  },
  "/_nuxt/InfoBox.aXwElSbB.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"175-AcmEhqWyvS5aZ0GsbNkPA3syiJ0\"",
    "mtime": "2026-10-14T03:03:55.459Z",
    "size": 373,
    "path": "../public/_nuxt/InfoBox.aXwElSbB.css.br"
  },
  "/_nuxt/InfoCell.BZcAw-4w.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"205-gQjbszmxrraYVjp74J292MMnUG0\"",
    "mtime": "2026-10-14T03:03:54.597Z",
    "size": 517,
    "path": "../public/_nuxt/InfoCell.BZcAw-4w.css"
  },
  "/_nuxt/K3hG5gE5.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"e2f8-75vmy79J2JNtLkGfbLlqu1O9yto\"",
    "mtime": "2026-10-14T03:03:54.598Z",
    "size": 58104,
    "path": "../public/_nuxt/K3hG5gE5.js"
  },
  "/_nuxt/K3hG5gE5.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2230-BEi1kUM/RjB5oHRN6uignS6yxpE\"",
    "mtime": "2026-10-14T03:03:55.459Z",
    "size": 8752,
    "path": "../public/_nuxt/K3hG5gE5.js.br"
  },
  "/_nuxt/K3hG5gE5.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2859-o6FIGEgoGzjKeSXVfKhS8zf/PP8\"",
    "mtime": "2026-10-14T03:03:55.459Z",
    "size": 10329,
    "path": "../public/_nuxt/K3hG5gE5.js.gz"
  },
  "/_nuxt/Loading.D33LpJEe.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"37e-r31g56TWJ0fdKmylULPlH2Zb0yw\"",
    "mtime": "2026-10-14T03:03:54.598Z",
    "size": 894,
    "path": "../public/_nuxt/Loading.D33LpJEe.css"
  },
  "/_nuxt/MLdz5LJX.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"9255-R1iBgQlQ3zlaXQzo3xfP+R+Bgrg\"",
    "mtime": "2026-10-14T03:03:54.598Z",
    "size": 37461,
    "path": "../public/_nuxt/MLdz5LJX.js"
  },
  "/_nuxt/MLdz5LJX.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"132a-q0YIe3J+FEAtWjHGHj/p+3esZys\"",
    "mtime": "2026-10-14T03:03:55.501Z",
    "size": 4906,
    "path": "../public/_nuxt/MLdz5LJX.js.br"
  },
  "/_nuxt/MLdz5LJX.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"16a1-Ha7RBF009pW25znvLCIhqN6Rkcg\"",
    "mtime": "2026-10-14T03:03:55.467Z",
    "size": 5793,
    "path": "../public/_nuxt/MLdz5LJX.js.gz"
  },
  "/_nuxt/Markdown.DrUKK4sG.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"4b4-8O4e5SLVpbf+8V5V9aYLeNPjbqY\"",
    "mtime": "2026-10-14T03:03:55.468Z",
    "size": 1204,
    "path": "../public/_nuxt/Markdown.DrUKK4sG.css.br"
  },
  "/_nuxt/Markdown.DrUKK4sG.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"1216-BiTKjMupqQrJDhxN8XYyt/39z/M\"",
    "mtime": "2026-10-14T03:03:54.597Z",
    "size": 4630,
    "path": "../public/_nuxt/Markdown.DrUKK4sG.css"
  },
  "/_nuxt/N9XRDATe.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"4ec-+R7DWucUbb+TcEDcY0hNQu09MEA\"",
    "mtime": "2026-10-14T03:03:54.599Z",
    "size": 1260,
    "path": "../public/_nuxt/N9XRDATe.js"
  },
  "/_nuxt/N9XRDATe.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"273-KNGERScouSWrv7MyYHo1g9MOQe8\"",
    "mtime": "2026-10-14T03:03:55.468Z",
    "size": 627,
    "path": "../public/_nuxt/N9XRDATe.js.br"
  },
  "/_nuxt/Markdown.DrUKK4sG.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"59c-VSTOOE8chJlBEKQLiyF7a8O3df4\"",
    "mtime": "2026-10-14T03:03:55.468Z",
    "size": 1436,
    "path": "../public/_nuxt/Markdown.DrUKK4sG.css.gz"
  },
  "/_nuxt/Nameplate.DUkfeUSC.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3af-oO6Ktq0QpqSRcucpajsxp3BDhBY\"",
    "mtime": "2026-10-14T03:03:54.598Z",
    "size": 943,
    "path": "../public/_nuxt/Nameplate.DUkfeUSC.css"
  },
  "/_nuxt/Pagination.DU4HcdLP.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"141-o20ttjZjobYAMU0aFqzhH0m+57g\"",
    "mtime": "2026-10-14T03:03:54.597Z",
    "size": 321,
    "path": "../public/_nuxt/Pagination.DU4HcdLP.css"
  },
  "/_nuxt/Pic.BO7L4o4O.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"164-R6rIxxCy7mcgOpdSjEuXG4bscaA\"",
    "mtime": "2026-10-14T03:03:54.598Z",
    "size": 356,
    "path": "../public/_nuxt/Pic.BO7L4o4O.css"
  },
  "/_nuxt/N9XRDATe.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2a9-INgk/WA95DtWU+fJx/wAXyfBwmI\"",
    "mtime": "2026-10-14T03:03:55.468Z",
    "size": 681,
    "path": "../public/_nuxt/N9XRDATe.js.gz"
  },
  "/_nuxt/Poqnl_Rf.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"858-BEGO732pxSckFjHJv0iD+zzS34Q\"",
    "mtime": "2026-10-14T03:03:55.477Z",
    "size": 2136,
    "path": "../public/_nuxt/Poqnl_Rf.js.br"
  },
  "/_nuxt/Poqnl_Rf.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"1f29-/Exwg7Xl4ENrdIJE3R8Qp8x3bMU\"",
    "mtime": "2026-10-14T03:03:54.600Z",
    "size": 7977,
    "path": "../public/_nuxt/Poqnl_Rf.js"
  },
  "/_nuxt/Poqnl_Rf.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"9c2-xqH7UcAYxIdST/7Be3CBAb+LSfg\"",
    "mtime": "2026-10-14T03:03:55.477Z",
    "size": 2498,
    "path": "../public/_nuxt/Poqnl_Rf.js.gz"
  },
  "/_nuxt/PwBohCvG.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"851-jq+naK9+sq9oY7AgdjRqI96XA5o\"",
    "mtime": "2026-10-14T03:03:54.598Z",
    "size": 2129,
    "path": "../public/_nuxt/PwBohCvG.js"
  },
  "/_nuxt/PwBohCvG.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"457-eiI0nJCmNFB1zg/Ik1uIKqis9sU\"",
    "mtime": "2026-10-14T03:03:55.477Z",
    "size": 1111,
    "path": "../public/_nuxt/PwBohCvG.js.gz"
  },
  "/_nuxt/PwBohCvG.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"3ce-6SBAdtQ2i1O/dKs8KsNboQExhtU\"",
    "mtime": "2026-10-14T03:03:55.477Z",
    "size": 974,
    "path": "../public/_nuxt/PwBohCvG.js.br"
  },
  "/_nuxt/Tabs.CgLtIr0J.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"24a-DVA04woIgiBhv0j8CVCjQdxrpkI\"",
    "mtime": "2026-10-14T03:03:54.599Z",
    "size": 586,
    "path": "../public/_nuxt/Tabs.CgLtIr0J.css"
  },
  "/_nuxt/QrCode.BMe4TxXI.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"ae-rw2TRfZx/2oinz/S0tpaA0ovvGI\"",
    "mtime": "2026-10-14T03:03:54.599Z",
    "size": 174,
    "path": "../public/_nuxt/QrCode.BMe4TxXI.css"
  },
  "/_nuxt/Tag.vtX9vP0R.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"18d-bB7rXz0Ixb095Umc4YHIbYcmuE8\"",
    "mtime": "2026-10-14T03:03:54.598Z",
    "size": 397,
    "path": "../public/_nuxt/Tag.vtX9vP0R.css"
  },
  "/_nuxt/Timeline.57u0BgXG.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"58f-MypvrEVxan5EhgoCeHnOmTcKgto\"",
    "mtime": "2026-10-14T03:03:54.600Z",
    "size": 1423,
    "path": "../public/_nuxt/Timeline.57u0BgXG.css"
  },
  "/_nuxt/Timeline.57u0BgXG.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"1b4-2MBo+FRqiBW78eev8MLedu0gytw\"",
    "mtime": "2026-10-14T03:03:55.479Z",
    "size": 436,
    "path": "../public/_nuxt/Timeline.57u0BgXG.css.br"
  },
  "/_nuxt/Timeline.57u0BgXG.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"243-cRfXHOs8L2K4UDTzPVPURqBCZC0\"",
    "mtime": "2026-10-14T03:03:55.479Z",
    "size": 579,
    "path": "../public/_nuxt/Timeline.57u0BgXG.css.gz"
  },
  "/_nuxt/Tip.Ig-Zd5Bp.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"141-xmLmtSlTWP9PndFfMhIQ6/5DrnM\"",
    "mtime": "2026-10-14T03:03:54.600Z",
    "size": 321,
    "path": "../public/_nuxt/Tip.Ig-Zd5Bp.css"
  },
  "/_nuxt/TujgbBRr.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"7e7c-Pgwly6mQjsS32qwN2qPBJlmPyng\"",
    "mtime": "2026-10-14T03:03:54.598Z",
    "size": 32380,
    "path": "../public/_nuxt/TujgbBRr.js"
  },
  "/_nuxt/TujgbBRr.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"f40-4Rv08JuL48/VN3DJw3ipUyExUd8\"",
    "mtime": "2026-10-14T03:03:55.505Z",
    "size": 3904,
    "path": "../public/_nuxt/TujgbBRr.js.br"
  },
  "/_nuxt/U8sipnkg.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"fb6-hYuTk2a3cl3UH1e+7Cam52hBJZs\"",
    "mtime": "2026-10-14T03:03:54.599Z",
    "size": 4022,
    "path": "../public/_nuxt/U8sipnkg.js"
  },
  "/_nuxt/TujgbBRr.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"11fb-NawBXgnEYVO7x3wBZRgr4KCwka4\"",
    "mtime": "2026-10-14T03:03:55.501Z",
    "size": 4603,
    "path": "../public/_nuxt/TujgbBRr.js.gz"
  },
  "/_nuxt/U8sipnkg.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"a8a-B2LDAixb63Aao+H2Swq5kjQEvQI\"",
    "mtime": "2026-10-14T03:03:55.501Z",
    "size": 2698,
    "path": "../public/_nuxt/U8sipnkg.js.gz"
  },
  "/_nuxt/U8sipnkg.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"98e-qW5g4byVo6ohzmJ0pXw/YHmbxlg\"",
    "mtime": "2026-10-14T03:03:55.501Z",
    "size": 2446,
    "path": "../public/_nuxt/U8sipnkg.js.br"
  },
  "/_nuxt/UBVbUXIo.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"15dd-7fFs/Bp772qAGPr/Ar1VD8HPgdw\"",
    "mtime": "2026-10-14T03:03:54.600Z",
    "size": 5597,
    "path": "../public/_nuxt/UBVbUXIo.js"
  },
  "/_nuxt/UBVbUXIo.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"db3-5ekzwwNsCsyA/ZhbClwtDKyFvFE\"",
    "mtime": "2026-10-14T03:03:55.501Z",
    "size": 3507,
    "path": "../public/_nuxt/UBVbUXIo.js.br"
  },
  "/_nuxt/UBVbUXIo.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"ec6-VLOTkKJkommHCHsT/O5AuHJUkEk\"",
    "mtime": "2026-10-14T03:03:55.501Z",
    "size": 3782,
    "path": "../public/_nuxt/UBVbUXIo.js.gz"
  },
  "/_nuxt/Waterfall.Dxs8oOPS.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"188-v92vRcb+UyqEMS/2QH/wDQ/zyl0\"",
    "mtime": "2026-10-14T03:03:54.600Z",
    "size": 392,
    "path": "../public/_nuxt/Waterfall.Dxs8oOPS.css"
  },
  "/_nuxt/VVmmdr2a.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3f3-WEIbpmcYEKDOrjCbK8e2BC3cG4o\"",
    "mtime": "2026-10-14T03:03:54.600Z",
    "size": 1011,
    "path": "../public/_nuxt/VVmmdr2a.js"
  },
  "/_nuxt/_date_.oUQzMbBE.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"364-W5LbHdYXle1hLIdSfqGCt9qOJOc\"",
    "mtime": "2026-10-14T03:03:54.599Z",
    "size": 868,
    "path": "../public/_nuxt/_date_.oUQzMbBE.css"
  },
  "/_nuxt/_id_.BTS9Ys6v.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"430-WySVi4BdPROOrlnPmtK0b6P0xsc\"",
    "mtime": "2026-10-14T03:03:54.599Z",
    "size": 1072,
    "path": "../public/_nuxt/_id_.BTS9Ys6v.css"
  },
  "/_nuxt/_id_.BTS9Ys6v.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"173-nIkQOB5MNVLjh8Q2Dygl1na1h1g\"",
    "mtime": "2026-10-14T03:03:55.504Z",
    "size": 371,
    "path": "../public/_nuxt/_id_.BTS9Ys6v.css.br"
  },
  "/_nuxt/_id_.BTS9Ys6v.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1e7-H4HVHqMVda/3E/gJ7eQUu5Fnglg\"",
    "mtime": "2026-10-14T03:03:55.504Z",
    "size": 487,
    "path": "../public/_nuxt/_id_.BTS9Ys6v.css.gz"
  },
  "/_nuxt/_id_.BV60pC98.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1e3-CusMRl0hh5TDQbkHbcckS97UWmk\"",
    "mtime": "2026-10-14T03:03:54.600Z",
    "size": 483,
    "path": "../public/_nuxt/_id_.BV60pC98.css"
  },
  "/_nuxt/_id_.CHOutMAu.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"188-564m35t0Vxbrs69N/NfsJr05YLM\"",
    "mtime": "2026-10-14T03:03:54.600Z",
    "size": 392,
    "path": "../public/_nuxt/_id_.CHOutMAu.css"
  },
  "/_nuxt/_id_.CcmrSn0a.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"7df-/4fu0P86uPIjAVaD53v2G20yfP8\"",
    "mtime": "2026-10-14T03:03:54.600Z",
    "size": 2015,
    "path": "../public/_nuxt/_id_.CcmrSn0a.css"
  },
  "/_nuxt/_id_.CcmrSn0a.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"245-InQRbWkIrTBKiMg8e0Gl7UUesp4\"",
    "mtime": "2026-10-14T03:03:55.505Z",
    "size": 581,
    "path": "../public/_nuxt/_id_.CcmrSn0a.css.br"
  },
  "/_nuxt/_id_.CcmrSn0a.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2d9-3cDmGCtK/RP+/ijS3toGPjduMio\"",
    "mtime": "2026-10-14T03:03:55.505Z",
    "size": 729,
    "path": "../public/_nuxt/_id_.CcmrSn0a.css.gz"
  },
  "/_nuxt/_id_.Cnc0GXSB.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"bcf-MXjsPmrf716N3oyVVWkGXai2Yfg\"",
    "mtime": "2026-10-14T03:03:54.600Z",
    "size": 3023,
    "path": "../public/_nuxt/_id_.Cnc0GXSB.css"
  },
  "/_nuxt/_id_.Cnc0GXSB.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"287-CfOX+c5r5jaF/6NBz2wur3WStsU\"",
    "mtime": "2026-10-14T03:03:55.507Z",
    "size": 647,
    "path": "../public/_nuxt/_id_.Cnc0GXSB.css.br"
  },
  "/_nuxt/_id_.kWbcarf2.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"188-H42yp1b0Yt6Ldi42pTg+rXT7wWQ\"",
    "mtime": "2026-10-14T03:03:54.600Z",
    "size": 392,
    "path": "../public/_nuxt/_id_.kWbcarf2.css"
  },
  "/_nuxt/_id_.Cnc0GXSB.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"31d-CVyiGf4/bCMB4imViuctmHehOA8\"",
    "mtime": "2026-10-14T03:03:55.505Z",
    "size": 797,
    "path": "../public/_nuxt/_id_.Cnc0GXSB.css.gz"
  },
  "/_nuxt/_id_.nYGl48p3.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3b8-mAXlziMRGkUaAPHeD+uYh70VA7c\"",
    "mtime": "2026-10-14T03:03:54.600Z",
    "size": 952,
    "path": "../public/_nuxt/_id_.nYGl48p3.css"
  },
  "/_nuxt/_url_.x1XGuNl0.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1-rcg7GeeTSRscbqD9i0bNnzLlkvw\"",
    "mtime": "2026-10-14T03:03:54.600Z",
    "size": 1,
    "path": "../public/_nuxt/_url_.x1XGuNl0.css"
  },
  "/_nuxt/blog.BO5-fYCO.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"2b4-xZiDSLefZD/Xzg91aXw+9c3mwRo\"",
    "mtime": "2026-10-14T03:03:55.512Z",
    "size": 692,
    "path": "../public/_nuxt/blog.BO5-fYCO.css.br"
  },
  "/_nuxt/blog.BO5-fYCO.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"b60-b8InYtAcuErCyFkUZCGoNMkfY/A\"",
    "mtime": "2026-10-14T03:03:54.600Z",
    "size": 2912,
    "path": "../public/_nuxt/blog.BO5-fYCO.css"
  },
  "/_nuxt/default.3xdodjjn.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"e80-AnlKrSoEy3rj0BgLlSLmwfQBTuI\"",
    "mtime": "2026-10-14T03:03:54.600Z",
    "size": 3712,
    "path": "../public/_nuxt/default.3xdodjjn.css"
  },
  "/_nuxt/blog.BO5-fYCO.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"366-OB9eX93+tQy5tgRNObnDeM2mYkA\"",
    "mtime": "2026-10-14T03:03:55.507Z",
    "size": 870,
    "path": "../public/_nuxt/blog.BO5-fYCO.css.gz"
  },
  "/_nuxt/default.3xdodjjn.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"388-4N34Rfogi0qOOXWsyqi2poTzlFU\"",
    "mtime": "2026-10-14T03:03:55.514Z",
    "size": 904,
    "path": "../public/_nuxt/default.3xdodjjn.css.br"
  },
  "/_nuxt/default.3xdodjjn.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"462-BOi2mX5o8PxRNWLQHQ8k9z1dt+Q\"",
    "mtime": "2026-10-14T03:03:55.514Z",
    "size": 1122,
    "path": "../public/_nuxt/default.3xdodjjn.css.gz"
  },
  "/_nuxt/entry.Bpc69712.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"adfe-Q2Fm/evu5YjXkV56dNrGXWtO2Sw\"",
    "mtime": "2026-10-14T03:03:54.600Z",
    "size": 44542,
    "path": "../public/_nuxt/entry.Bpc69712.css"
  },
  "/_nuxt/error-404.DpKY_dMl.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"a8d-ikaaK5LbtZuaZygnIu5mAjYDRiQ\"",
    "mtime": "2026-10-14T03:03:54.601Z",
    "size": 2701,
    "path": "../public/_nuxt/error-404.DpKY_dMl.css"
  },
  "/_nuxt/entry.Bpc69712.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"5b36-sWJjgxSjMLa8EjFxBuocRXm33Jc\"",
    "mtime": "2026-10-14T03:03:55.586Z",
    "size": 23350,
    "path": "../public/_nuxt/entry.Bpc69712.css.br"
  },
  "/_nuxt/error-404.DpKY_dMl.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"306-LIM2eRDhJFGqaY43LbO/BRnQeLE\"",
    "mtime": "2026-10-14T03:03:55.516Z",
    "size": 774,
    "path": "../public/_nuxt/error-404.DpKY_dMl.css.br"
  },
  "/_nuxt/error-404.DpKY_dMl.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"395-Afq1INxScLepuzSomqPGZY9rtXE\"",
    "mtime": "2026-10-14T03:03:55.516Z",
    "size": 917,
    "path": "../public/_nuxt/error-404.DpKY_dMl.css.gz"
  },
  "/_nuxt/entry.Bpc69712.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"6217-ZeJjeZM9qLRWqZJAQBf3HYcuOTQ\"",
    "mtime": "2026-10-14T03:03:55.516Z",
    "size": 25111,
    "path": "../public/_nuxt/entry.Bpc69712.css.gz"
  },
  "/_nuxt/error-500.CmR4p1fc.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"79f-oUFNPOuVEcj5aJV0yQGGzo21VAE\"",
    "mtime": "2026-10-14T03:03:54.601Z",
    "size": 1951,
    "path": "../public/_nuxt/error-500.CmR4p1fc.css"
  },
  "/_nuxt/error-500.CmR4p1fc.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"25f-6Q3lx5aTOxjQVhwglbWq7qvDEXQ\"",
    "mtime": "2026-10-14T03:03:55.516Z",
    "size": 607,
    "path": "../public/_nuxt/error-500.CmR4p1fc.css.br"
  },
  "/_nuxt/error-500.CmR4p1fc.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2cf-D/A8OwHO76F+QwqNgODaf0Xf51s\"",
    "mtime": "2026-10-14T03:03:55.516Z",
    "size": 719,
    "path": "../public/_nuxt/error-500.CmR4p1fc.css.gz"
  },
  "/_nuxt/footer.ZctD1T3p.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"5d8-Je5WmUKb8d9nGoe39EuxDwEvn9E\"",
    "mtime": "2026-10-14T03:03:54.600Z",
    "size": 1496,
    "path": "../public/_nuxt/footer.ZctD1T3p.css"
  },
  "/_nuxt/footer.ZctD1T3p.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"177-oIn0Z4S0Xb5UXcV0Xf1NsUEsaoY\"",
    "mtime": "2026-10-14T03:03:55.542Z",
    "size": 375,
    "path": "../public/_nuxt/footer.ZctD1T3p.css.br"
  },
  "/_nuxt/footer.ZctD1T3p.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"208-5UVJBne+R42ZTBE5ezxn6ZZS/ss\"",
    "mtime": "2026-10-14T03:03:55.542Z",
    "size": 520,
    "path": "../public/_nuxt/footer.ZctD1T3p.css.gz"
  },
  "/_nuxt/iconfont.BiDdEdlJ.eot": {
    "type": "application/vnd.ms-fontobject",
    "encoding": null,
    "etag": "\"8270-YtDJd0o1N+XR4Dr4O+t2MJHbhho\"",
    "mtime": "2026-10-14T03:03:54.601Z",
    "size": 33392,
    "path": "../public/_nuxt/iconfont.BiDdEdlJ.eot"
  },
  "/_nuxt/iconfont.BiDdEdlJ.eot.br": {
    "type": "application/vnd.ms-fontobject",
    "encoding": "br",
    "etag": "\"5279-eIM7sGh3FReHjlxCyEXSMKitgm4\"",
    "mtime": "2026-10-14T03:03:55.641Z",
    "size": 21113,
    "path": "../public/_nuxt/iconfont.BiDdEdlJ.eot.br"
  },
  "/_nuxt/iconfont.BiDdEdlJ.eot.gz": {
    "type": "application/vnd.ms-fontobject",
    "encoding": "gzip",
    "etag": "\"5744-2PoMAISAtOQwqcxyLdMIdY0ssTQ\"",
    "mtime": "2026-10-14T03:03:55.575Z",
    "size": 22340,
    "path": "../public/_nuxt/iconfont.BiDdEdlJ.eot.gz"
  },
  "/_nuxt/iconfont.BjTYkzhu.svg": {
    "type": "image/svg+xml",
    "encoding": null,
    "etag": "\"26f26-1x0vWtEuZDCPdYoRw8cZdOjHDFA\"",
    "mtime": "2026-10-14T03:03:54.600Z",
    "size": 159526,
    "path": "../public/_nuxt/iconfont.BjTYkzhu.svg"
  },
  "/_nuxt/iconfont.BjTYkzhu.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"c6ed-Gt175dppWa1W+C/0AsCvMjzcOao\"",
    "mtime": "2026-10-14T03:03:55.743Z",
    "size": 50925,
    "path": "../public/_nuxt/iconfont.BjTYkzhu.svg.br"
  },
  "/_nuxt/iconfont.BjTYkzhu.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"e00c-E7RB+02muHepKoyGQum/nzkwLzw\"",
    "mtime": "2026-10-14T03:03:55.650Z",
    "size": 57356,
    "path": "../public/_nuxt/iconfont.BjTYkzhu.svg.gz"
  },
  "/_nuxt/iconfont.BnpRSb6O.woff": {
    "type": "font/woff",
    "etag": "\"5638-PJ0U/NE+GtrwQ86lWBWvpUztdkM\"",
    "mtime": "2026-10-14T03:03:54.601Z",
    "size": 22072,
    "path": "../public/_nuxt/iconfont.BnpRSb6O.woff"
  },
  "/_nuxt/iconfont.C-toOeox.ttf": {
    "type": "font/ttf",
    "encoding": null,
    "etag": "\"81c8-q2b2V55dxWo2Yp4/XauHUUWnk7c\"",
    "mtime": "2026-10-14T03:03:54.601Z",
    "size": 33224,
    "path": "../public/_nuxt/iconfont.C-toOeox.ttf"
  },
  "/_nuxt/iconfont.C-toOeox.ttf.br": {
    "type": "font/ttf",
    "encoding": "br",
    "etag": "\"521a-CRIeWClwThoZQt4bCPZHBziee7g\"",
    "mtime": "2026-10-14T03:03:55.650Z",
    "size": 21018,
    "path": "../public/_nuxt/iconfont.C-toOeox.ttf.br"
  },
  "/_nuxt/iconfont.C-toOeox.ttf.gz": {
    "type": "font/ttf",
    "encoding": "gzip",
    "etag": "\"570f-0F540jACxRw5NxJWdnLfW997YsQ\"",
    "mtime": "2026-10-14T03:03:55.650Z",
    "size": 22287,
    "path": "../public/_nuxt/iconfont.C-toOeox.ttf.gz"
  },
  "/_nuxt/idea.CKprUw3V.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"191-iYGRj7yF25CLt47ZYIGlDBCYcs4\"",
    "mtime": "2026-10-14T03:03:54.601Z",
    "size": 401,
    "path": "../public/_nuxt/idea.CKprUw3V.css"
  },
  "/_nuxt/ihUJ7T1l.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"2ba6-R24tuBtq9gvF2P4/M/MpReJAeFE\"",
    "mtime": "2026-10-14T03:03:54.601Z",
    "size": 11174,
    "path": "../public/_nuxt/ihUJ7T1l.js"
  },
  "/_nuxt/ihUJ7T1l.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1112-XMuiYu/lBRbX7R6+nFHe2/Zin4s\"",
    "mtime": "2026-10-14T03:03:55.650Z",
    "size": 4370,
    "path": "../public/_nuxt/ihUJ7T1l.js.gz"
  },
  "/_nuxt/ihUJ7T1l.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"efd-1bbP/WvGfpYgylbu51ktugKMOfc\"",
    "mtime": "2026-10-14T03:03:55.650Z",
    "size": 3837,
    "path": "../public/_nuxt/ihUJ7T1l.js.br"
  },
  "/_nuxt/imageLoading.B9tTISS5.gif": {
    "type": "image/gif",
    "etag": "\"1ce7-GR5DrS16cg6Yx3L3Gbi9BXmfiJ0\"",
    "mtime": "2026-10-14T03:03:54.601Z",
    "size": 7399,
    "path": "../public/_nuxt/imageLoading.B9tTISS5.gif"
  },
  "/_nuxt/log.bdhZetZb.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2f8-gR/nr82+J7Jy1GpxIGJ2RaTlREo\"",
    "mtime": "2026-10-14T03:03:54.601Z",
    "size": 760,
    "path": "../public/_nuxt/log.bdhZetZb.css"
  },
  "/_nuxt/mailbox.0_krQ1J-.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"466-1hvZVWHpiAcT99RdVyb3m0a8uGI\"",
    "mtime": "2026-10-14T03:03:54.601Z",
    "size": 1126,
    "path": "../public/_nuxt/mailbox.0_krQ1J-.css"
  },
  "/_nuxt/mailbox.0_krQ1J-.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"20e-IcTTt595hLcNWFAizBm0BGsF93g\"",
    "mtime": "2026-10-14T03:03:55.655Z",
    "size": 526,
    "path": "../public/_nuxt/mailbox.0_krQ1J-.css.gz"
  },
  "/_nuxt/movie.D1_GJRUE.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"5b5-QYMyZeExHrrkXmBdnLJ5JceNtnM\"",
    "mtime": "2026-10-14T03:03:54.601Z",
    "size": 1461,
    "path": "../public/_nuxt/movie.D1_GJRUE.css"
  },
  "/_nuxt/mailbox.0_krQ1J-.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"18c-EH8B5o6PuN87G/bnJKOZjz9P0lE\"",
    "mtime": "2026-10-14T03:03:55.655Z",
    "size": 396,
    "path": "../public/_nuxt/mailbox.0_krQ1J-.css.br"
  },
  "/_nuxt/movie.D1_GJRUE.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"233-lB/4sEQDZVABlgxS2fmU0rWnsHk\"",
    "mtime": "2026-10-14T03:03:55.658Z",
    "size": 563,
    "path": "../public/_nuxt/movie.D1_GJRUE.css.gz"
  },
  "/_nuxt/movie.D1_GJRUE.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"1ad-H3A+WeWfDc4/YJsUezFyHPojwA4\"",
    "mtime": "2026-10-14T03:03:55.658Z",
    "size": 429,
    "path": "../public/_nuxt/movie.D1_GJRUE.css.br"
  },
  "/_nuxt/oU8m6k9c.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"a05-p2fR9K153937T3EntqWJxlXMtLs\"",
    "mtime": "2026-10-14T03:03:54.601Z",
    "size": 2565,
    "path": "../public/_nuxt/oU8m6k9c.js"
  },
  "/_nuxt/oU8m6k9c.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"3de-VX0k8islMvqGs/u2wBQHy49Dd38\"",
    "mtime": "2026-10-14T03:03:55.658Z",
    "size": 990,
    "path": "../public/_nuxt/oU8m6k9c.js.br"
  },
  "/_nuxt/oU8m6k9c.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"465-wFiV6Gy3ZZUhSPtvixxItBoGYCM\"",
    "mtime": "2026-10-14T03:03:55.658Z",
    "size": 1125,
    "path": "../public/_nuxt/oU8m6k9c.js.gz"
  },
  "/_nuxt/pNignmeK.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"b3f-BfQcliPUDr9xDguJpotJ7Fjcez8\"",
    "mtime": "2026-10-14T03:03:54.602Z",
    "size": 2879,
    "path": "../public/_nuxt/pNignmeK.js"
  },
  "/_nuxt/pNignmeK.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"4db-sBNI39xRU0NLqA+LecmVvR2vPH8\"",
    "mtime": "2026-10-14T03:03:55.658Z",
    "size": 1243,
    "path": "../public/_nuxt/pNignmeK.js.br"
  },
  "/_nuxt/pNignmeK.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"577-aaqFH4hev0Bk4b9qMZlavaNYg0I\"",
    "mtime": "2026-10-14T03:03:55.658Z",
    "size": 1399,
    "path": "../public/_nuxt/pNignmeK.js.gz"
  },
  "/_nuxt/pages.HC3vUOhK.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"280-pWTaMMdo8Ys08p+FYs+T+WmGzbM\"",
    "mtime": "2026-10-14T03:03:54.601Z",
    "size": 640,
    "path": "../public/_nuxt/pages.HC3vUOhK.css"
  },
  "/_nuxt/project.CctEISua.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"28-ZFFXtW0Q+ObHak3iWAmiYtSvuz4\"",
    "mtime": "2026-10-14T03:03:54.602Z",
    "size": 40,
    "path": "../public/_nuxt/project.CctEISua.css"
  },
  "/_nuxt/plan.DXU3TQgC.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"39a-dJH4F8RwhknkMXJ2vuM8/ye9z/M\"",
    "mtime": "2026-10-14T03:03:54.601Z",
    "size": 922,
    "path": "../public/_nuxt/plan.DXU3TQgC.css"
  },
  "/_nuxt/row.CvXe9su3.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"47c0-GmgJsPcXPZs3Go5sFf7fHvlrLcY\"",
    "mtime": "2026-10-14T03:03:54.602Z",
    "size": 18368,
    "path": "../public/_nuxt/row.CvXe9su3.css"
  },
  "/_nuxt/row.CvXe9su3.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"334-VfCLlgbTaadE7s/wWpRzq5eiX2M\"",
    "mtime": "2026-10-14T03:03:55.672Z",
    "size": 820,
    "path": "../public/_nuxt/row.CvXe9su3.css.br"
  },
  "/_nuxt/row.CvXe9su3.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"65c-LxVBT9H2ly/IXp2V9Zdz3L1BJFM\"",
    "mtime": "2026-10-14T03:03:55.672Z",
    "size": 1628,
    "path": "../public/_nuxt/row.CvXe9su3.css.gz"
  },
  "/_nuxt/search.BMqU8gVA.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"8b-RzgxFE9zSoAWxjexlfrqKwDuFXQ\"",
    "mtime": "2026-10-14T03:03:54.602Z",
    "size": 139,
    "path": "../public/_nuxt/search.BMqU8gVA.css"
  },
  "/_nuxt/tIe5wCTV.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"e0a1-bpXID8qdTIwgu/ayMJIVhM80+rk\"",
    "mtime": "2026-10-14T03:03:54.602Z",
    "size": 57505,
    "path": "../public/_nuxt/tIe5wCTV.js"
  },
  "/_nuxt/tIe5wCTV.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2c56-yEyViBF2ryHp+874lhg17e2vA/w\"",
    "mtime": "2026-10-14T03:03:55.730Z",
    "size": 11350,
    "path": "../public/_nuxt/tIe5wCTV.js.gz"
  },
  "/_nuxt/tIe5wCTV.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"24b7-rXYnuLPHreJq5Q/RZTRZXHrLP9Y\"",
    "mtime": "2026-10-14T03:03:55.730Z",
    "size": 9399,
    "path": "../public/_nuxt/tIe5wCTV.js.br"
  },
  "/_nuxt/timeline.zp0vpKgx.css": {
    "type": "text/css; charset=utf-8",
    "encoding": null,
    "etag": "\"734-gdFj6K28bgxR5ezvp41o8fKL/AM\"",
    "mtime": "2026-10-14T03:03:54.602Z",
    "size": 1844,
    "path": "../public/_nuxt/timeline.zp0vpKgx.css"
  },
  "/_nuxt/timeline.zp0vpKgx.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"207-DQ63fsFdxA/d45HMJGa9ewyNS1M\"",
    "mtime": "2026-10-14T03:03:55.733Z",
    "size": 519,
    "path": "../public/_nuxt/timeline.zp0vpKgx.css.br"
  },
  "/_nuxt/timeline.zp0vpKgx.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"29a-N/C0a6ivWJSkyyk8rAhcG/YlBwM\"",
    "mtime": "2026-10-14T03:03:55.733Z",
    "size": 666,
    "path": "../public/_nuxt/timeline.zp0vpKgx.css.gz"
  },
  "/_nuxt/word.5eeAGD50.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"d1-WB5ejsrNMqHGCqYJjrO5OlcABno\"",
    "mtime": "2026-10-14T03:03:54.602Z",
    "size": 209,
    "path": "../public/_nuxt/word.5eeAGD50.css"
  },
  "/_nuxt/xojyKzHw.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"6da-G2QWzVcbtjFd3QpTcEkbCrT2sCU\"",
    "mtime": "2026-10-14T03:03:55.733Z",
    "size": 1754,
    "path": "../public/_nuxt/xojyKzHw.js.br"
  },
  "/_nuxt/xojyKzHw.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"1276-fyBEMjvOtW3oSLNh/vxTCB4P7kQ\"",
    "mtime": "2026-10-14T03:03:54.602Z",
    "size": 4726,
    "path": "../public/_nuxt/xojyKzHw.js"
  },
  "/_nuxt/yJ-P2AkA.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"b37-/j9kS2M/2qmS2b65O89Ori0O+pw\"",
    "mtime": "2026-10-14T03:03:54.602Z",
    "size": 2871,
    "path": "../public/_nuxt/yJ-P2AkA.js"
  },
  "/_nuxt/xojyKzHw.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"82f-XEwQxZqZixL4RbyccA2gmN2HlJE\"",
    "mtime": "2026-10-14T03:03:55.733Z",
    "size": 2095,
    "path": "../public/_nuxt/xojyKzHw.js.gz"
  },
  "/_nuxt/yJ-P2AkA.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"4be-Db1AZXiUe+ECVSvHUVhnrOth5PA\"",
    "mtime": "2026-10-14T03:03:55.735Z",
    "size": 1214,
    "path": "../public/_nuxt/yJ-P2AkA.js.br"
  },
  "/_nuxt/yUETK85q.js": {
    "type": "text/javascript; charset=utf-8",
    "encoding": null,
    "etag": "\"6d0-AoDcpTC3sCmklNBBBJ2gb1t0VZo\"",
    "mtime": "2026-10-14T03:03:54.602Z",
    "size": 1744,
    "path": "../public/_nuxt/yUETK85q.js"
  },
  "/_nuxt/yUETK85q.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"288-CuXR3Ufe08LgNc7k39grMJjzdbU\"",
    "mtime": "2026-10-14T03:03:55.735Z",
    "size": 648,
    "path": "../public/_nuxt/yUETK85q.js.br"
  },
  "/_nuxt/yJ-P2AkA.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"55c-AuR6JumOf/TqVpvSh8c9pmnAt8w\"",
    "mtime": "2026-10-14T03:03:55.735Z",
    "size": 1372,
    "path": "../public/_nuxt/yJ-P2AkA.js.gz"
  },
  "/_nuxt/yUETK85q.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2d5-meyW4WcsM1LCXZx4iXg3QOO9c0Y\"",
    "mtime": "2026-10-14T03:03:55.735Z",
    "size": 725,
    "path": "../public/_nuxt/yUETK85q.js.gz"
  },
  "/_nuxt/builds/latest.json": {
    "type": "application/json",
    "etag": "\"47-J7msrR1bhm4vhVq61uR37lznC4w\"",
    "mtime": "2026-10-14T03:03:54.574Z",
    "size": 71,
    "path": "../public/_nuxt/builds/latest.json"
  },
  "/_nuxt/builds/meta/41bdffe5-309d-4564-8019-77900a125c90.json": {
    "type": "application/json",
    "etag": "\"58-Flz7pKeQXAT/q+rXHHaILZkT4Gk\"",
    "mtime": "2026-10-14T03:03:54.572Z",
    "size": 88,
    "path": "../public/_nuxt/builds/meta/41bdffe5-309d-4564-8019-77900a125c90.json"
  }
};

const _DRIVE_LETTER_START_RE = /^[A-Za-z]:\//;
function normalizeWindowsPath(input = "") {
  if (!input) {
    return input;
  }
  return input.replace(/\\/g, "/").replace(_DRIVE_LETTER_START_RE, (r) => r.toUpperCase());
}
const _IS_ABSOLUTE_RE = /^[/\\](?![/\\])|^[/\\]{2}(?!\.)|^[A-Za-z]:[/\\]/;
const _DRIVE_LETTER_RE = /^[A-Za-z]:$/;
const _ROOT_FOLDER_RE = /^\/([A-Za-z]:)?$/;
function cwd() {
  if (typeof process !== "undefined" && typeof process.cwd === "function") {
    return process.cwd().replace(/\\/g, "/");
  }
  return "/";
}
const resolve$1 = function(...arguments_) {
  arguments_ = arguments_.map((argument) => normalizeWindowsPath(argument));
  let resolvedPath = "";
  let resolvedAbsolute = false;
  for (let index = arguments_.length - 1; index >= -1 && !resolvedAbsolute; index--) {
    const path = index >= 0 ? arguments_[index] : cwd();
    if (!path || path.length === 0) {
      continue;
    }
    resolvedPath = `${path}/${resolvedPath}`;
    resolvedAbsolute = isAbsolute(path);
  }
  resolvedPath = normalizeString(resolvedPath, !resolvedAbsolute);
  if (resolvedAbsolute && !isAbsolute(resolvedPath)) {
    return `/${resolvedPath}`;
  }
  return resolvedPath.length > 0 ? resolvedPath : ".";
};
function normalizeString(path, allowAboveRoot) {
  let res = "";
  let lastSegmentLength = 0;
  let lastSlash = -1;
  let dots = 0;
  let char = null;
  for (let index = 0; index <= path.length; ++index) {
    if (index < path.length) {
      char = path[index];
    } else if (char === "/") {
      break;
    } else {
      char = "/";
    }
    if (char === "/") {
      if (lastSlash === index - 1 || dots === 1) ; else if (dots === 2) {
        if (res.length < 2 || lastSegmentLength !== 2 || res[res.length - 1] !== "." || res[res.length - 2] !== ".") {
          if (res.length > 2) {
            const lastSlashIndex = res.lastIndexOf("/");
            if (lastSlashIndex === -1) {
              res = "";
              lastSegmentLength = 0;
            } else {
              res = res.slice(0, lastSlashIndex);
              lastSegmentLength = res.length - 1 - res.lastIndexOf("/");
            }
            lastSlash = index;
            dots = 0;
            continue;
          } else if (res.length > 0) {
            res = "";
            lastSegmentLength = 0;
            lastSlash = index;
            dots = 0;
            continue;
          }
        }
        if (allowAboveRoot) {
          res += res.length > 0 ? "/.." : "..";
          lastSegmentLength = 2;
        }
      } else {
        if (res.length > 0) {
          res += `/${path.slice(lastSlash + 1, index)}`;
        } else {
          res = path.slice(lastSlash + 1, index);
        }
        lastSegmentLength = index - lastSlash - 1;
      }
      lastSlash = index;
      dots = 0;
    } else if (char === "." && dots !== -1) {
      ++dots;
    } else {
      dots = -1;
    }
  }
  return res;
}
const isAbsolute = function(p) {
  return _IS_ABSOLUTE_RE.test(p);
};
const relative = function(from, to) {
  const _from = resolve$1(from).replace(_ROOT_FOLDER_RE, "$1").split("/");
  const _to = resolve$1(to).replace(_ROOT_FOLDER_RE, "$1").split("/");
  if (_to[0][1] === ":" && _from[0][1] === ":" && _from[0] !== _to[0]) {
    return _to.join("/");
  }
  const _fromCopy = [..._from];
  for (const segment of _fromCopy) {
    if (_to[0] !== segment) {
      break;
    }
    _from.shift();
    _to.shift();
  }
  return [..._from.map(() => ".."), ..._to].join("/");
};
const dirname = function(p) {
  const segments = normalizeWindowsPath(p).replace(/\/$/, "").split("/").slice(0, -1);
  if (segments.length === 1 && _DRIVE_LETTER_RE.test(segments[0])) {
    segments[0] += "/";
  }
  return segments.join("/") || (isAbsolute(p) ? "/" : ".");
};

function readAsset (id) {
  const serverDir = dirname(fileURLToPath(globalThis._importMeta_.url));
  return promises.readFile(resolve$1(serverDir, assets[id].path))
}

const publicAssetBases = {"/_nuxt/builds/meta/":{"maxAge":31536000},"/_nuxt/builds/":{"maxAge":1},"/_nuxt/":{"maxAge":31536000}};

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return true
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = { gzip: ".gz", br: ".br" };
const _g_tsVx = eventHandler((event) => {
  if (event.method && !METHODS.has(event.method)) {
    return;
  }
  let id = decodePath(
    withLeadingSlash(withoutTrailingSlash(parseURL(event.path).pathname))
  );
  let asset;
  const encodingHeader = String(
    getRequestHeader(event, "accept-encoding") || ""
  );
  const encodings = [
    ...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(),
    ""
  ];
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      removeResponseHeader(event, "Cache-Control");
      throw createError$1({ statusCode: 404 });
    }
    return;
  }
  if (asset.encoding !== void 0) {
    appendResponseHeader(event, "Vary", "Accept-Encoding");
  }
  const ifNotMatch = getRequestHeader(event, "if-none-match") === asset.etag;
  if (ifNotMatch) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  const ifModifiedSinceH = getRequestHeader(event, "if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  if (asset.type && !getResponseHeader(event, "Content-Type")) {
    setResponseHeader(event, "Content-Type", asset.type);
  }
  if (asset.etag && !getResponseHeader(event, "ETag")) {
    setResponseHeader(event, "ETag", asset.etag);
  }
  if (asset.mtime && !getResponseHeader(event, "Last-Modified")) {
    setResponseHeader(event, "Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !getResponseHeader(event, "Content-Encoding")) {
    setResponseHeader(event, "Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !getResponseHeader(event, "Content-Length")) {
    setResponseHeader(event, "Content-Length", asset.size);
  }
  return readAsset(id);
});

const E=globalThis.process?.env||Object.create(null),I=globalThis.process||{env:E},O=void 0!==I&&I.env&&I.env.NODE_ENV||void 0;I.platform||"";!!I.stdout?.isTTY;!!E.DEBUG;"test"===O||!!E.TEST;"production"===O||"production"===E.MODE;const c="dev"===O||"development"===O||"development"===E.MODE,d=(I.versions?.node||"").replace(/^v/,"")||null;Number(d?.split(".")[0])||null;const f=!!I?.versions?.node;!!I?.versions?.nub;const g="Bun"in globalThis,Y="Deno"in globalThis,p="fastly"in globalThis,b="Netlify"in globalThis,m="EdgeRuntime"in globalThis,v="Cloudflare-Workers"===globalThis.navigator?.userAgent,V=[[b,"netlify"],[m,"edge-light"],[v,"workerd"],[p,"fastly"],[Y,"deno"],[g,"bun"],[f,"node"]];const H=function(){const E=V.find(E=>E[0]);if(E)return {name:E[1]}}();H?.name||"";

const PROTOCOL_RE = /^https?:\/\//;
const TRAILING_SLASH_RE = /\/$/;
function isLocalhostHost(host) {
  if (!host || host.startsWith("localhost") || host.startsWith("127.") || host.startsWith("0.0.0.0"))
    return true;
  const hostname = host.startsWith("[") ? host.slice(0, host.indexOf("]") + 1) : host;
  return hostname === "[::1]" || hostname === "::1" || hostname === "[::]" || hostname === "::";
}
function extractHostname(host) {
  if (host.startsWith("[")) {
    const close = host.indexOf("]");
    return close !== -1 ? host.slice(0, close + 1) : host;
  }
  const colonCount = host.split(":").length - 1;
  return colonCount === 1 ? host.slice(0, host.indexOf(":")) : host;
}
function splitHostPort(host) {
  if (host.startsWith("[")) {
    const close = host.indexOf("]");
    const hostname = close !== -1 ? host.slice(0, close + 1) : host;
    const port = close !== -1 && host[close + 1] === ":" ? host.slice(close + 2) : "";
    const normalized = hostname === "[::1]" || hostname === "[::]" ? "localhost" : hostname;
    return { host: normalized, port };
  }
  if (host === "0.0.0.0" || host.startsWith("0.0.0.0:")) {
    const i = host.indexOf(":");
    return { host: "localhost", port: i !== -1 ? host.slice(i + 1) : "" };
  }
  const colonCount = host.split(":").length - 1;
  if (colonCount === 1) {
    const i = host.indexOf(":");
    return { host: host.slice(0, i), port: host.slice(i + 1) };
  }
  if (colonCount > 1) {
    const normalized = host === "::1" || host === "::" ? "localhost" : `[${host}]`;
    return { host: normalized, port: "" };
  }
  return { host, port: "" };
}
function getNitroOrigin$1(ctx = {}) {
  const isDev = ctx.isDev ?? c;
  const isPrerender = ctx.isPrerender ?? false;
  let host = "";
  let port = "";
  let protocol = process.env.NITRO_SSL_CERT && process.env.NITRO_SSL_KEY ? "https" : "http";
  if (isDev || isPrerender) {
    const devEnv = process.env.__NUXT_DEV__ || process.env.NUXT_VITE_NODE_OPTIONS;
    if (devEnv) {
      const parsed = JSON.parse(devEnv);
      const origin = parsed.proxy?.url || parsed.baseURL?.replace("/__nuxt_vite_node__", "");
      host = origin.replace(PROTOCOL_RE, "").replace(TRAILING_SLASH_RE, "");
      protocol = origin.startsWith("https") ? "https" : "http";
    }
  }
  if (isDev && isLocalhostHost(host) && ctx.requestHost) {
    const reqHost = extractHostname(ctx.requestHost);
    if (reqHost && !isLocalhostHost(reqHost)) {
      host = ctx.requestHost;
      protocol = ctx.requestProtocol || protocol;
    }
  }
  if (!host && ctx.requestHost) {
    host = ctx.requestHost;
    protocol = ctx.requestProtocol || protocol;
  }
  if (!host) {
    host = process.env.NITRO_HOST || process.env.HOST || "";
    if (isDev)
      port = process.env.NITRO_PORT || process.env.PORT || "3000";
  }
  const split = splitHostPort(host);
  host = split.host;
  if (split.port)
    port = split.port;
  host = process.env.NUXT_SITE_HOST_OVERRIDE || host;
  port = process.env.NUXT_SITE_PORT_OVERRIDE || port;
  if (host.startsWith("http://") || host.startsWith("https://")) {
    protocol = host.startsWith("https://") ? "https" : "http";
    host = host.replace(PROTOCOL_RE, "");
  } else if (!isDev && (!host || !isLocalhostHost(host))) {
    protocol = "https";
  }
  return `${protocol}://${host}${port ? `:${port}` : ""}/`;
}

function getNitroOrigin(e) {
  return getNitroOrigin$1({
    isDev: false,
    isPrerender: false,
    requestHost: e ? getRequestHost(e, { xForwardedHost: true }) : void 0,
    requestProtocol: e ? getRequestProtocol(e, { xForwardedProto: true }) : void 0
  });
}

const PORT_SUFFIX_RE = /:\d+$/;
const serverEnvSiteConfig = envSiteConfig(globalThis._importMeta_.env || {});
const _dMZTdp = eventHandler(async (e) => {
  if (e.context._initedSiteConfig)
    return;
  const runtimeConfig = useRuntimeConfig(e);
  const config = runtimeConfig["nuxt-site-config"];
  const nitroApp = useNitroApp();
  const siteConfig = e.context.siteConfig || createSiteConfigStack({
    debug: config.debug
  });
  const nitroOrigin = getNitroOrigin(e);
  e.context.siteConfigNitroOrigin = nitroOrigin;
  {
    siteConfig.push({
      _context: "nitro:init",
      _priority: SiteConfigPriority.nitro,
      url: nitroOrigin
    });
  }
  siteConfig.push({
    _context: "runtimeEnv",
    _priority: SiteConfigPriority.runtime,
    ...runtimeConfig.site || {},
    ...runtimeConfig.public.site || {},
    ...serverEnvSiteConfig
  });
  const buildStack = config.stack || [];
  buildStack.forEach((c) => siteConfig.push(c));
  const routeRules = getSiteRouteRules(e);
  if (routeRules.site) {
    siteConfig.push({
      _context: "route-rules",
      ...routeRules.site
    });
  }
  if (config.multiTenancy) {
    const host = parseURL(nitroOrigin).host?.replace(PORT_SUFFIX_RE, "") || "";
    const tenant = config.multiTenancy?.find((t) => t.hosts.includes(host));
    if (tenant) {
      siteConfig.push({
        _context: `multi-tenancy:${host}`,
        _priority: SiteConfigPriority.runtime,
        ...tenant.config
      });
    }
  }
  const ctx = { siteConfig, event: e };
  await nitroApp.hooks.callHook("site-config:init", ctx);
  e.context.siteConfig = ctx.siteConfig;
  e.context._initedSiteConfig = true;
});

const FILE_EXT_RE = /\.[0-9a-z]+$/i;
function resolveSitePath(pathOrUrl, options) {
  let path = pathOrUrl;
  if (hasProtocol(pathOrUrl, { strict: false, acceptRelative: true })) {
    const parsed = parseURL(pathOrUrl);
    path = parsed.pathname;
  }
  const base = withLeadingSlash(options.base || "/");
  if (base !== "/" && path.startsWith(base)) {
    path = path.slice(base.length);
  }
  let origin = withoutTrailingSlash(options.absolute ? options.siteUrl : "");
  if (base !== "/" && origin.endsWith(base)) {
    origin = origin.slice(0, origin.indexOf(base));
  }
  const baseWithOrigin = options.withBase ? withBase(base, origin || "/") : origin;
  const resolvedUrl = withBase(path, baseWithOrigin);
  return path === "/" && !options.withBase ? withTrailingSlash(resolvedUrl) : fixSlashes(options.trailingSlash, resolvedUrl);
}
const fileExtensions = [
  // Images
  "jpg",
  "jpeg",
  "png",
  "gif",
  "bmp",
  "webp",
  "svg",
  "ico",
  // Documents
  "pdf",
  "doc",
  "docx",
  "xls",
  "xlsx",
  "ppt",
  "pptx",
  "txt",
  "md",
  "markdown",
  // Archives
  "zip",
  "rar",
  "7z",
  "tar",
  "gz",
  // Audio
  "mp3",
  "wav",
  "flac",
  "ogg",
  "opus",
  "m4a",
  "aac",
  "midi",
  "mid",
  // Video
  "mp4",
  "avi",
  "mkv",
  "mov",
  "wmv",
  "flv",
  "webm",
  // Web
  "html",
  "css",
  "js",
  "json",
  "xml",
  "tsx",
  "jsx",
  "ts",
  "vue",
  "svelte",
  "xsl",
  "rss",
  "atom",
  // Programming
  "php",
  "py",
  "rb",
  "java",
  "c",
  "cpp",
  "h",
  "go",
  // Data formats
  "csv",
  "tsv",
  "sql",
  "yaml",
  "yml",
  // Fonts
  "woff",
  "woff2",
  "ttf",
  "otf",
  "eot",
  // Executables/Binaries
  "exe",
  "msi",
  "apk",
  "ipa",
  "dmg",
  "iso",
  "bin",
  // Scripts/Config
  "bat",
  "cmd",
  "sh",
  "env",
  "htaccess",
  "conf",
  "toml",
  "ini",
  // Package formats
  "deb",
  "rpm",
  "jar",
  "war",
  // E-books
  "epub",
  "mobi",
  // Common temporary/backup files
  "log",
  "tmp",
  "bak",
  "old",
  "sav"
];
function isPathFile(path) {
  const lastSegment = path.split("/").pop();
  const ext = (lastSegment || path).match(FILE_EXT_RE)?.[0];
  return !!(ext && fileExtensions.includes(ext.replace(".", "")));
}
function fixSlashes(trailingSlash, pathOrUrl) {
  const $url = parseURL(pathOrUrl);
  if (isPathFile($url.pathname))
    return pathOrUrl;
  const fixedPath = trailingSlash ? withTrailingSlash($url.pathname) : withoutTrailingSlash($url.pathname);
  return `${$url.protocol ? `${$url.protocol}//` : ""}${$url.host || ""}${fixedPath}${$url.search || ""}${$url.hash || ""}`;
}

function createSitePathResolver(e, options = {}) {
  const siteConfig = getSiteConfig(e);
  const nitroOrigin = getNitroOrigin(e);
  const nuxtBase = useRuntimeConfig(e).app.baseURL || "/";
  return (path) => {
    return resolveSitePath(path, {
      ...options,
      siteUrl: options.canonical !== false || false ? siteConfig.url : nitroOrigin,
      trailingSlash: siteConfig.trailingSlash,
      base: nuxtBase
    });
  };
}

const staticConfig = {"isI18nMapped":false,"sitemapName":"sitemap.xml","isMultiSitemap":false,"excludeAppSources":[],"cacheMaxAgeSeconds":600,"experimentalStreaming":false,"autoLastmod":false,"defaultSitemapsChunkSize":1000,"minify":false,"sortEntries":true,"discoverImages":true,"discoverVideos":true,"sitemapsPathPrefix":"/__sitemap__/","isNuxtContentDocumentDriven":false,"xsl":"/__sitemap__/style.xsl","xslTips":true,"xslColumns":[{"label":"URL","width":"50%"},{"label":"Images","width":"25%","select":"count(image:image)"},{"label":"Last Updated","width":"25%","select":"concat(substring(sitemap:lastmod,0,11),concat(' ', substring(sitemap:lastmod,12,5)),concat(' ', substring(sitemap:lastmod,20,6)))"}],"credits":true,"version":"8.6.1","sitemaps":{"sitemap.xml":{"sitemapName":"sitemap.xml","route":"sitemap.xml","defaults":{"changefreq":"daily","priority":1},"include":[],"exclude":["/_**","/_nuxt/**"],"includeAppSources":true}}};

function isUnlocalizedLocalePage(page) {
  return page._tag === "unlocalized" && typeof page.path === "string";
}
function matchesUnlocalizedLocalePage(page, path) {
  if (matchPagePattern(page.path, path))
    return true;
  if (!page.subtree)
    return false;
  const subtreePattern = `${page.path === "/" ? "" : page.path.replace(/\/$/, "")}/[...__nuxtSeoSubtree]`;
  return !!matchPagePattern(subtreePattern, path);
}
function normalizeHost(value) {
  const input = value.trim();
  return parseURL(input.startsWith("//") ? `https:${input}` : input.includes("://") ? input : `https://${input}`).host?.toLowerCase() || "";
}
function localeDomains(locale) {
  return [...locale.domains || [], ...locale.domain ? [locale.domain] : []];
}
function resolveI18nDomain(host, i18n) {
  const normalizedHost = host ? normalizeHost(host) : "";
  const domains = i18n.locales.map((locale) => ({
    locale,
    hosts: localeDomains(locale).map(normalizeHost),
    defaults: locale.defaultForDomains?.map(normalizeHost) || []
  }));
  const matches = normalizedHost ? domains.filter((entry) => entry.hosts.includes(normalizedHost) || entry.defaults.includes(normalizedHost)) : [];
  if (!matches.length)
    return { _tag: "unknown", defaultLocale: i18n.defaultLocale, locales: i18n.locales };
  const defaultLocale = matches.find((entry) => entry.defaults.includes(normalizedHost))?.locale || (matches.length === 1 ? matches[0].locale : void 0);
  return {
    _tag: "known",
    defaultLocale: defaultLocale?.code || i18n.defaultLocale,
    locales: domains.filter((entry) => !entry.hosts.length || entry.hosts.includes(normalizedHost)).map((entry) => entry.locale)
  };
}
function firstLocaleDomain(locale) {
  return locale?.defaultForDomains?.[0] || locale?.domain || locale?.domains?.[0];
}
function resolveCanonicalLocaleDomain(locale, defaultLocale) {
  return firstLocaleDomain(locale) || firstLocaleDomain(defaultLocale);
}
function splitRouteSuffix(route) {
  const suffixIndex = route.search(/[?#]/);
  const rawPathname = suffixIndex === -1 ? route : route.slice(0, suffixIndex);
  return {
    pathname: rawPathname ? rawPathname.startsWith("/") ? rawPathname : `/${rawPathname}` : "/",
    suffix: suffixIndex === -1 ? "" : route.slice(suffixIndex)
  };
}
function resolveLocaleFromRoute(route, i18n, context = {}) {
  const { pathname, suffix } = splitRouteSuffix(route);
  if (i18n.strategy !== "no_prefix") {
    const segments = pathname.split("/").filter(Boolean);
    const first = segments[0];
    const matched = first ? i18n.locales.find((l) => l.code === first) : void 0;
    if (matched) {
      const rest = segments.slice(1).join("/");
      const trailingSlash = rest && pathname.endsWith("/") ? "/" : "";
      return { locale: matched.code, basePath: `${rest ? `/${rest}${trailingSlash}` : "/"}${suffix}` };
    }
  }
  const contextLocale = context.locale ? i18n.locales.find((locale) => locale.code === context.locale) : void 0;
  const domain = resolveI18nDomain(context.host, i18n);
  const hostLocales = domain._tag === "known" ? domain.locales.filter((locale) => [...localeDomains(locale), ...locale.defaultForDomains || []].some((host) => normalizeHost(host) === normalizeHost(context.host))) : [];
  const hostLocale = hostLocales.find((locale) => locale.code === domain.defaultLocale) || hostLocales[0];
  return { locale: contextLocale?.code || hostLocale?.code || domain.defaultLocale, basePath: `${pathname}${suffix}` };
}
function localePath(basePath, locale, i18n, context = {}) {
  const { pathname, suffix } = splitRouteSuffix(basePath);
  if (i18n.strategy === "no_prefix")
    return `${pathname}${suffix}`;
  const domain = resolveI18nDomain(context.host, i18n);
  const isDefault = locale === domain.defaultLocale;
  const isDomainDefault = i18n.differentDomains || domain._tag === "known" && isDefault;
  if (i18n.strategy === "prefix_except_default" && (isDefault || i18n.differentDomains))
    return `${pathname}${suffix}`;
  if (i18n.strategy === "prefix_and_default" && isDomainDefault)
    return `${pathname}${suffix}`;
  if (pathname === "/")
    return `/${locale}${suffix}`;
  return `/${locale}${pathname}${suffix}`;
}
function toSegments(path) {
  return path.split("/").filter(Boolean);
}
const PAGE_PARAM_PATTERN = /\[\[(\.\.\.)?([^[\]]+)\]\]|\[(\.\.\.)?([^[\]]+)\]|:(\w+)(?:\((\.\*)?\))?([?*+]?)/g;
function parsePageSegment(segment) {
  const tokens = [];
  let offset = 0;
  for (const match of segment.matchAll(PAGE_PARAM_PATTERN)) {
    const index = match.index;
    if (index > offset)
      tokens.push({ _tag: "static", value: segment.slice(offset, index) });
    if (match[2]) {
      tokens.push({ _tag: "param", param: { name: match[2], catchAll: !!match[1], optional: true } });
    } else if (match[4]) {
      tokens.push({ _tag: "param", param: { name: match[4], catchAll: !!match[3], optional: false } });
    } else {
      const modifier = match[7];
      const routePattern = match[6];
      tokens.push({
        _tag: "param",
        param: {
          name: match[5],
          catchAll: !!routePattern?.includes(".*") || modifier === "*" || modifier === "+",
          optional: modifier === "?" || modifier === "*"
        }
      });
    }
    offset = index + match[0].length;
  }
  if (offset < segment.length)
    tokens.push({ _tag: "static", value: segment.slice(offset) });
  return tokens.length ? tokens : [{ _tag: "static", value: segment }];
}
function wholeSegmentParam(tokens) {
  return tokens.length === 1 && tokens[0]?._tag === "param" ? tokens[0].param : null;
}
function segmentRanks(pattern) {
  return toSegments(pattern).map((segment) => {
    const tokens = parsePageSegment(segment);
    const params = tokens.filter((token) => token._tag === "param");
    if (!params.length)
      return 6;
    const hasStatic = tokens.some((token) => token._tag === "static");
    if (hasStatic)
      return params.some((token) => token.param.optional) ? 3 : 4;
    const param = params[0].param;
    if (param.catchAll)
      return param.optional ? -1 : 0;
    return param.optional ? 1 : 2;
  });
}
function compareSpecificity(a, b) {
  const length = Math.min(a.length, b.length);
  for (let i = 0; i < length; i++) {
    const diff = b[i] - a[i];
    if (diff !== 0)
      return diff;
  }
  return a.length - b.length;
}
function matchSegmentTokens(tokens, path) {
  const failedStates = /* @__PURE__ */ new Set();
  function visit(index, offset, params) {
    const state = index * (path.length + 1) + offset;
    if (failedStates.has(state))
      return null;
    if (index === tokens.length) {
      if (offset === path.length)
        return params;
      failedStates.add(state);
      return null;
    }
    const token = tokens[index];
    if (token._tag === "static") {
      const matched = path.startsWith(token.value, offset) ? visit(index + 1, offset + token.value.length, params) : null;
      if (!matched)
        failedStates.add(state);
      return matched;
    }
    const minimumEnd = token.param.optional ? offset : offset + 1;
    for (let end = minimumEnd; end <= path.length; end++) {
      const value = path.slice(offset, end);
      const nextParams = value ? { ...params, [token.param.name]: value } : params;
      const matched = visit(index + 1, end, nextParams);
      if (matched)
        return matched;
    }
    failedStates.add(state);
    return null;
  }
  return visit(0, 0, {});
}
function matchPagePattern(pattern, path) {
  const patternSegments = toSegments(pattern);
  const pathSegments = toSegments(path);
  const failedStates = /* @__PURE__ */ new Set();
  function visit(patternIndex, pathIndex, params) {
    const state = patternIndex * (pathSegments.length + 1) + pathIndex;
    if (failedStates.has(state))
      return null;
    if (patternIndex === patternSegments.length) {
      if (pathIndex === pathSegments.length)
        return params;
      failedStates.add(state);
      return null;
    }
    const tokens = parsePageSegment(patternSegments[patternIndex]);
    const param = wholeSegmentParam(tokens);
    if (param?.catchAll) {
      const minimumEnd = param.optional ? pathIndex : pathIndex + 1;
      for (let end = pathSegments.length; end >= minimumEnd; end--) {
        const value = pathSegments.slice(pathIndex, end).join("/");
        const nextParams = value ? { ...params, [param.name]: value } : params;
        const matched2 = visit(patternIndex + 1, end, nextParams);
        if (matched2)
          return matched2;
      }
      failedStates.add(state);
      return null;
    }
    const segment = pathSegments[pathIndex];
    if (segment !== void 0) {
      const segmentParams = matchSegmentTokens(tokens, segment);
      if (segmentParams) {
        const matched2 = visit(patternIndex + 1, pathIndex + 1, { ...params, ...segmentParams });
        if (matched2)
          return matched2;
      }
    }
    const matched = param?.optional ? visit(patternIndex + 1, pathIndex, params) : null;
    if (!matched)
      failedStates.add(state);
    return matched;
  }
  return visit(0, 0, {});
}
function fillPagePattern(pattern, params) {
  const filled = [];
  for (const segment of toSegments(pattern)) {
    const tokens = parsePageSegment(segment);
    let value = "";
    for (const token of tokens) {
      if (token._tag === "static") {
        value += token.value;
        continue;
      }
      const paramValue = params[token.param.name];
      if (paramValue === void 0) {
        if (token.param.optional)
          continue;
        return null;
      }
      value += paramValue;
    }
    if (value)
      filled.push(value);
  }
  if (!filled.length)
    return "/";
  return `/${filled.join("/")}${pattern.endsWith("/") ? "/" : ""}`;
}
function alternatesForEntry(localePaths, params, i18n, context) {
  const untranslated = localePaths[i18n.defaultLocale];
  const alternates = [];
  const defaultLocale = i18n.locales.find((locale) => locale.code === i18n.defaultLocale);
  const locales = context.domainMode === "request" ? resolveI18nDomain(context.host, i18n).locales : i18n.locales;
  for (const l of locales) {
    const pattern = localePaths[l.code] ?? untranslated;
    if (localePaths[l.code] === false)
      continue;
    if (typeof pattern !== "string")
      continue;
    const path = fillPagePattern(pattern, params);
    if (path === null)
      continue;
    const domain = context.domainMode === "request" ? void 0 : resolveCanonicalLocaleDomain(l, defaultLocale);
    alternates.push({
      code: l.code,
      hreflang: l.hreflang || l.code,
      path: localePath(path, l.code, i18n, { host: domain || context.host }),
      ...domain ? { domain } : {}
    });
  }
  return alternates;
}
function alternatesFromPages(basePath, routePath, locale, i18n, context) {
  const pages = i18n.pages;
  const hasDomainLocales = i18n.differentDomains || i18n.multiDomainLocales;
  const hasContextLocale = !!context.locale && i18n.locales.some((locale2) => locale2.code === context.locale);
  if (!pages)
    return null;
  const allowLocalized = i18n.strategy !== "no_prefix" || hasDomainLocales || hasContextLocale;
  const matches = [];
  for (const page of Object.values(pages)) {
    if (!page)
      continue;
    if (isUnlocalizedLocalePage(page)) {
      if (matchesUnlocalizedLocalePage(page, routePath))
        matches.push({ _tag: "unlocalized", ranks: segmentRanks(page.path) });
      continue;
    }
    if (!allowLocalized)
      continue;
    const pattern = page[locale];
    if (!pattern)
      continue;
    const params = matchPagePattern(pattern, basePath);
    if (params)
      matches.push({ _tag: "localized", ranks: segmentRanks(pattern), localePaths: page, params });
  }
  matches.sort((a, b) => compareSpecificity(a.ranks, b.ranks));
  for (const match of matches) {
    if (match._tag === "unlocalized") {
      const defaultCode = context.domainMode === "request" ? resolveI18nDomain(context.host, i18n).defaultLocale : i18n.defaultLocale;
      const defaultLocale = i18n.locales.find((locale2) => locale2.code === defaultCode);
      if (defaultLocale) {
        const domain = context.domainMode === "request" ? void 0 : resolveCanonicalLocaleDomain(defaultLocale);
        return [{
          code: defaultLocale.code,
          hreflang: defaultLocale.hreflang || defaultLocale.code,
          path: routePath,
          ...domain ? { domain } : {}
        }];
      }
      continue;
    }
    return alternatesForEntry(match.localePaths, match.params, i18n, context);
  }
  return null;
}
function resolveLocaleAlternates(route, i18n, context = {}) {
  const { locale, basePath } = resolveLocaleFromRoute(route, i18n, context);
  const { pathname, suffix } = splitRouteSuffix(basePath);
  const { pathname: routePathname } = splitRouteSuffix(route);
  const translated = alternatesFromPages(pathname, routePathname, locale, i18n, context);
  if (translated) {
    return {
      _tag: "pages",
      alternates: translated.map((alternate) => ({ ...alternate, path: `${alternate.path}${suffix}` }))
    };
  }
  const defaultLocale = i18n.locales.find((locale2) => locale2.code === i18n.defaultLocale);
  return {
    _tag: "strategy",
    alternates: (context.domainMode === "request" ? resolveI18nDomain(context.host, i18n).locales : i18n.locales).map((l) => {
      const domain = context.domainMode === "request" ? void 0 : resolveCanonicalLocaleDomain(l, defaultLocale);
      return {
        code: l.code,
        hreflang: l.hreflang || l.code,
        path: localePath(basePath, l.code, i18n, { host: domain || context.host }),
        ...domain ? { domain } : {}
      };
    })
  };
}
function computeLocaleAlternates(route, i18n, context = {}) {
  return resolveLocaleAlternates(route, i18n, context).alternates;
}

function parseSerializedRegExp(value) {
  const lastSlash = value.lastIndexOf("/");
  return new RegExp(value.slice(1, lastSlash), value.slice(lastSlash + 1));
}
function deserializeFilters(filters) {
  return filters.map((filter) => {
    if (filter instanceof RegExp || typeof filter === "string")
      return filter;
    if (typeof filter.regex === "string")
      return parseSerializedRegExp(filter.regex);
    if (typeof filter.source === "string")
      return new RegExp(filter.source, filter.flags || "");
    return filter;
  });
}
function createFilter(options = {}) {
  const include = deserializeFilters(options.include || []);
  const exclude = deserializeFilters(options.exclude || []);
  if (include.length === 0 && exclude.length === 0)
    return () => true;
  const excludeRegex = exclude.filter((r) => r instanceof RegExp);
  const includeRegex = include.filter((r) => r instanceof RegExp);
  const excludeStrings = exclude.filter((r) => typeof r === "string");
  const includeStrings = include.filter((r) => typeof r === "string");
  const excludeMatcher = excludeStrings.length > 0 ? toRouteMatcher(createRouter$1({
    routes: Object.fromEntries(excludeStrings.map((r) => [r, true])),
    strictTrailingSlash: false
  })) : null;
  const includeMatcher = includeStrings.length > 0 ? toRouteMatcher(createRouter$1({
    routes: Object.fromEntries(includeStrings.map((r) => [r, true])),
    strictTrailingSlash: false
  })) : null;
  const excludeExact = new Set(excludeStrings);
  const includeExact = new Set(includeStrings);
  return function(path) {
    if (excludeRegex.some((r) => r.test(path)))
      return false;
    if (excludeExact.has(path))
      return false;
    if (excludeMatcher && excludeMatcher.matchAll(path).length > 0)
      return false;
    if (includeRegex.some((r) => r.test(path)))
      return true;
    if (includeExact.has(path))
      return true;
    if (includeMatcher && includeMatcher.matchAll(path).length > 0)
      return true;
    return include.length === 0;
  };
}
function createModuleLogger(tag, debug) {
  return createConsola({ level: 3, defaults: { tag } });
}

const logger = createModuleLogger("@nuxt/sitemap");
const XML_ENTITIES = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&apos;"
};
const XML_SPECIAL_CHARS_RE = /[&<>"']/g;
const HAS_XML_SPECIAL_CHARS_RE = /[&<>"']/;
function xmlEscape(value) {
  const input = String(value);
  return HAS_XML_SPECIAL_CHARS_RE.test(input) ? input.replace(XML_SPECIAL_CHARS_RE, (char) => XML_ENTITIES[char]) : input;
}
const merger = createDefu((obj, key, value) => {
  if (Array.isArray(obj[key]) && Array.isArray(value))
    obj[key] = Array.from(/* @__PURE__ */ new Set([...obj[key], ...value]));
  return obj[key];
});
function mergeOnKey(arr, key, onMerge) {
  if (arr.length < 2)
    return arr;
  const seen = /* @__PURE__ */ new Map();
  let resultLength = 0;
  for (const item of arr) {
    const k = item[key];
    if (seen.has(k)) {
      const existingIndex = seen.get(k);
      onMerge?.(item[key]);
      arr[existingIndex] = merger(item, arr[existingIndex]);
    } else {
      seen.set(k, resultLength);
      arr[resultLength++] = item;
    }
  }
  arr.length = resultLength;
  return arr;
}
function splitForLocales(path, locales) {
  const start = path.charCodeAt(0) === 47 ? 1 : 0;
  const end = path.indexOf("/", start);
  const prefix = path.slice(start, end === -1 ? path.length : end);
  const hasLocale = locales instanceof Set ? locales.has(prefix) : locales.includes(prefix);
  if (prefix && hasLocale) {
    const prefixEnd = start + prefix.length;
    return [prefix, start === 1 ? path.slice(prefixEnd) : path];
  }
  return [null, path];
}
function toRuntimeI18nConfig(i18n) {
  return {
    ...i18n,
    // Sitemap transforms keep the unprefixed default URL alongside Nuxt's prefixed route.
    strategy: i18n.strategy === "prefix_and_default" ? "prefix_except_default" : i18n.strategy,
    pages: i18n.pages && Object.fromEntries(
      Object.entries(i18n.pages).map(([pageName, pageLocales]) => [
        pageName,
        Object.fromEntries(i18n.locales.map((locale) => {
          const configuredPath = pageLocales[locale.code];
          return [locale.code, configuredPath === void 0 ? withLeadingSlash(pageName) : configuredPath];
        }))
      ])
    ),
    locales: i18n.locales.map((locale) => ({
      ...locale,
      hreflang: locale._hreflang
    }))
  };
}
function localeAlternateHref(alternate) {
  return alternate.domain ? joinURL(withHttps(alternate.domain), alternate.path) : alternate.path;
}
function resolveI18nRouteEntries(route, i18n, includeHref = () => true, context = {}) {
  const runtimeConfig = toRuntimeI18nConfig(i18n);
  const currentLocale = resolveLocaleFromRoute(route, runtimeConfig, context).locale;
  const alternates = computeLocaleAlternates(route, runtimeConfig, { ...context, locale: currentLocale });
  const localizedAlternates = alternates.map((alternate) => ({
    alternate,
    href: localeAlternateHref(alternate)
  }));
  const defaultHref = localizedAlternates.find(({ alternate }) => alternate.code === i18n.defaultLocale)?.href;
  const sitemapAlternatives = [
    ...defaultHref && includeHref(defaultHref) ? [{ hreflang: "x-default", href: defaultHref }] : [],
    ...localizedAlternates.filter(({ href }) => includeHref(href)).map(({ alternate, href }) => ({ hreflang: alternate.hreflang, href }))
  ];
  return localizedAlternates.flatMap(({ alternate, href }) => {
    const locale = i18n.locales.find((locale2) => locale2.code === alternate.code);
    return locale ? [{ locale, loc: href, alternatives: sitemapAlternatives }] : [];
  });
}
function resolveI18nSitemapLocaleKey(sitemapName, localeSitemapKeys) {
  let best = null;
  for (const key of localeSitemapKeys) {
    if (sitemapName === key || sitemapName.startsWith(`${key}-`)) {
      if (best === null || key.length > best.length)
        best = key;
    }
  }
  return best;
}
const StringifiedRegExpPattern = /\/(.*?)\/([gimsuy]*)$/;
function normalizeRuntimeFilters(input) {
  return (input || []).map((rule) => {
    if (rule instanceof RegExp || typeof rule === "string")
      return rule;
    const match = rule.regex.match(StringifiedRegExpPattern);
    if (match)
      return new RegExp(match[1], match[2]);
    return false;
  }).filter(Boolean);
}
function createPathFilter(options = {}, baseURL) {
  const urlFilter = createFilter({
    include: normalizeRuntimeFilters(options.include),
    exclude: normalizeRuntimeFilters(options.exclude)
  });
  const hasBase = baseURL !== "/";
  return (loc, pathname) => {
    let path = pathname;
    if (typeof path !== "string") {
      try {
        path = parseURL(loc).pathname;
      } catch {
        return false;
      }
    }
    if (hasBase)
      path = withoutBase(path, baseURL);
    return urlFilter(withLeadingSlash(path));
  };
}
const ROBOTS_BLOCKING_DIRECTIVES = /* @__PURE__ */ new Set(["noindex", "none"]);
function robotsBlocksIndexing(robots) {
  if (robots === false)
    return true;
  if (typeof robots !== "string")
    return false;
  return robots.split(",").some((directive) => ROBOTS_BLOCKING_DIRECTIVES.has(directive.trim().toLowerCase()));
}

const SERVER_CACHE_MAX_AGE$3 = staticConfig.cacheMaxAgeSeconds;
function dynamicRuntimeConfig(e) {
  return useRuntimeConfig(e).sitemap;
}
function copyStaticSitemaps() {
  return Object.fromEntries(
    Object.entries(staticConfig.sitemaps).map(([name, sitemap]) => [name, {
      ...sitemap,
      include: normalizeRuntimeFilters("include" in sitemap ? sitemap.include : void 0),
      exclude: normalizeRuntimeFilters("exclude" in sitemap ? sitemap.exclude : void 0)
    }])
  );
}
function useSitemapRuntimeConfig(e) {
  return Object.freeze({
    ...staticConfig,
    sitemaps: copyStaticSitemaps(),
    ...dynamicRuntimeConfig(e)
  });
}
function serializeFilters(filters) {
  if (!filters?.length)
    return void 0;
  return filters.map((f) => {
    if (f instanceof RegExp)
      return { regex: `/${f.source}/${f.flags}` };
    return f;
  });
}
async function resolveSitemapSitemaps(e, nitro) {
  const ctx = { sitemaps: copyStaticSitemaps(), event: e };
  await nitro.hooks.callHook("sitemap:sitemaps-resolved", ctx);
  const sitemaps = { ...ctx.sitemaps };
  for (const name of Object.keys(sitemaps)) {
    const sitemap = { ...sitemaps[name] };
    if (typeof sitemap.urls === "function")
      sitemap.urls = await sitemap.urls();
    sitemap.include = serializeFilters(sitemap.include);
    sitemap.exclude = serializeFilters(sitemap.exclude);
    sitemaps[name] = sitemap;
  }
  return sitemaps;
}
const resolveSitemapSitemapsCached = defineCachedFunction(
  resolveSitemapSitemaps,
  {
    name: "sitemap:runtime-sitemaps",
    group: "sitemap",
    maxAge: SERVER_CACHE_MAX_AGE$3,
    base: "sitemap",
    // nitro calls getKey with the full fn args (event, nitro)
    getKey: (e) => {
      const host = e && (getHeader(e, "x-forwarded-host") || getHeader(e, "host")) || "";
      const proto = e && getHeader(e, "x-forwarded-proto") || "https";
      return `runtime-sitemaps-${proto}-${host}`;
    },
    swr: true
  }
);
async function useResolvedSitemapRuntimeConfig(e) {
  const maxAge = dynamicRuntimeConfig(e)?.cacheMaxAgeSeconds ?? staticConfig.cacheMaxAgeSeconds;
  const shouldCache = typeof maxAge === "number" && maxAge > 0;
  const sitemaps = shouldCache ? await resolveSitemapSitemapsCached(e, useNitroApp()) : await resolveSitemapSitemaps(e, useNitroApp());
  return Object.freeze({
    ...staticConfig,
    sitemaps,
    ...dynamicRuntimeConfig(e)
  });
}

const _uygUoA = defineEventHandler(async (e) => {
  const fixPath = createSitePathResolver(e, { absolute: false, withBase: true });
  const { sitemapName: fallbackSitemapName, cacheMaxAgeSeconds, version, xslColumns, xslTips } = useSitemapRuntimeConfig();
  setHeader(e, "Content-Type", "application/xslt+xml");
  if (cacheMaxAgeSeconds)
    setHeader(e, "Cache-Control", `public, max-age=${cacheMaxAgeSeconds}, must-revalidate`);
  else
    setHeader(e, "Cache-Control", `no-cache, no-store`);
  const { name: siteName, url: siteUrl } = getSiteConfig(e);
  const referrer = getHeader(e, "Referer") || "/";
  const referrerPath = parseURL(referrer).pathname;
  const isNotIndexButHasIndex = referrerPath !== "/sitemap.xml" && referrerPath !== "/sitemap_index.xml" && referrerPath.endsWith(".xml");
  const sitemapName = parseURL(referrer).pathname.split("/").pop()?.split("-sitemap")[0] || fallbackSitemapName;
  const title = `${siteName}${sitemapName !== "sitemap.xml" ? ` - ${sitemapName === "sitemap_index.xml" ? "index" : sitemapName}` : ""}`.replace(/&/g, "&amp;");
  getQuery$1(referrer).canonical;
  const debugUrl = xmlEscape(withQuery("/__sitemap__/debug.json", { sitemap: sitemapName }));
  xmlEscape(referrerPath);
  xmlEscape(withQuery(referrerPath, { canonical: "" }));
  const fetchErrors = [];
  const xslQuery = getQuery(e);
  if (xslQuery.error_messages) {
    const errorMessages = xslQuery.error_messages;
    const errorUrls = xslQuery.error_urls;
    if (errorMessages) {
      const messages = Array.isArray(errorMessages) ? errorMessages : [errorMessages];
      const urls = Array.isArray(errorUrls) ? errorUrls : errorUrls ? [errorUrls] : [];
      messages.forEach((msg, i) => {
        const errorParts = [xmlEscape(msg)];
        if (urls[i])
          errorParts.push(xmlEscape(urls[i]));
        fetchErrors.push(`<span class="error-item">${errorParts.join(" \u2014 ")}</span>`);
      });
    }
  }
  const hasRuntimeErrors = fetchErrors.length > 0;
  let columns = [...xslColumns];
  if (!columns.length) {
    columns = [
      { label: "URL", width: "50%" },
      { label: "Images", width: "25%", select: "count(image:image)" },
      { label: "Last Updated", width: "25%", select: "concat(substring(sitemap:lastmod,0,11),concat(' ', substring(sitemap:lastmod,12,5)),concat(' ', substring(sitemap:lastmod,20,6)))" }
    ];
  }
  return `<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="2.0"
                xmlns:html="http://www.w3.org/TR/REC-html40"
                xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"
                xmlns:sitemap="http://www.sitemaps.org/schemas/sitemap/0.9"
                xmlns:xhtml="http://www.w3.org/1999/xhtml"
                xmlns:news="http://www.google.com/schemas/sitemap-news/0.9"
                xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:output method="html" version="1.0" encoding="UTF-8" indent="yes"/>
  <xsl:template match="/">
    <html xmlns="http://www.w3.org/1999/xhtml">
      <head>
        <title>XML Sitemap</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <style type="text/css">
          :root {
            --accent: #00dc82;
            --accent-hover: #00b86b;
            --bg: #0a0a0a;
            --bg-elevated: #141414;
            --bg-subtle: #1a1a1a;
            --border: #262626;
            --border-subtle: #1f1f1f;
            --text: #e5e5e5;
            --text-muted: #737373;
            --text-faint: #525252;
            --error: #ef4444;
            --error-bg: rgba(239,68,68,0.1);
            --warning: #f59e0b;
          }
          * { box-sizing: border-box; }
          body {
            font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
            font-size: 13px;
            color: var(--text);
            background: var(--bg);
            margin: 0;
            padding: 0;
            line-height: 1.6;
            -webkit-font-smoothing: antialiased;
          }
          a { color: inherit; transition: color 0.15s; }
          a:hover { color: var(--accent); }

          /* Debug bar (dev only) */
          .debug-bar {
            position: fixed;
            bottom: 0.75rem;
            left: 50%;
            transform: translateX(-50%);
            width: 80%;
            background: var(--bg-elevated);
            border: 1px solid var(--border);
            border-radius: 10px;
            padding: 0 1rem;
            height: 2.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            z-index: 100;
            font-size: 11px;
          }
          .debug-bar-brand {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--text-muted);
            text-decoration: none;
          }
          .debug-bar-brand:hover { color: var(--text); }
          .debug-bar-brand svg { flex-shrink: 0; }
          .debug-bar-hint {
            color: var(--text-faint);
            margin-right: auto;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
          }
          .debug-bar-hint code {
            background: var(--bg-subtle);
            padding: 0.1rem 0.3rem;
            border-radius: 3px;
            font-size: 10px;
          }
          .mode-badge {
            font-size: 9px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            padding: 0.2rem 0.4rem;
            border-radius: 3px;
          }
          .mode-dev { background: rgba(245,158,11,0.15); color: var(--warning); }
          .mode-prod { background: rgba(0,220,130,0.12); color: var(--accent); }
          .mode-toggle {
            display: inline-flex;
            border-radius: 4px;
            overflow: hidden;
            background: var(--bg-subtle);
            padding: 2px;
            gap: 1px;
          }
          .mode-toggle a {
            padding: 0.2rem 0.4rem;
            font-size: 9px;
            font-weight: 500;
            text-decoration: none;
            color: var(--text-muted);
            border-radius: 2px;
            transition: all 0.15s;
          }
          .mode-toggle a:hover { color: var(--text); }
          .mode-toggle a.active {
            background: var(--accent);
            color: #0a0a0a;
          }
          .btn {
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            text-decoration: none;
            font-size: 10px;
            font-weight: 500;
            transition: all 0.15s;
          }
          .btn-primary {
            background: var(--accent);
            color: #0a0a0a;
          }
          .btn-primary:hover { background: var(--accent-hover); color: #0a0a0a; }
          .btn svg { width: 12px; height: 12px; }

          /* Error banner */
          .error-banner {
            background: var(--error-bg);
            border-bottom: 1px solid rgba(239,68,68,0.2);
            padding: 0.75rem 1.5rem;
            color: #fca5a5;
            font-size: 12px;
          }
          .error-banner strong { color: var(--error); }
          .error-item { display: block; margin-top: 0.375rem; color: #fca5a5; }
          .error-debug-link {
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
            margin-top: 0.625rem;
            padding: 0.25rem 0.5rem;
            background: var(--error);
            color: #fff;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 500;
            text-decoration: none;
            transition: background 0.15s;
          }
          .error-debug-link:hover { background: #dc2626; color: #fff; }

          /* Main content */
          .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 1.5rem;
          }
          .header {
            margin-bottom: 1.25rem;
          }
          .header h1 {
            font-size: 1rem;
            font-weight: 600;
            margin: 0 0 0.25rem 0;
            color: var(--text);
          }
          .header-meta {
            color: var(--text-muted);
            font-size: 12px;
          }
          .header-meta a {
            color: var(--text-muted);
            text-decoration: underline;
            text-decoration-color: var(--border);
            text-underline-offset: 2px;
          }
          .header-meta a:hover { color: var(--accent); text-decoration-color: var(--accent); }

          /* Table */
          .table-wrap {
            border: 1px solid var(--border);
            border-radius: 8px;
            overflow: hidden;
            background: var(--bg-elevated);
          }
          table {
            width: 100%;
            border-collapse: collapse;
          }
          th {
            text-align: left;
            padding: 0.625rem 1rem;
            font-size: 10px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--text-muted);
            background: var(--bg-subtle);
            border-bottom: 1px solid var(--border);
          }
          td {
            padding: 0.5rem 1rem;
            border-bottom: 1px solid var(--border-subtle);
            font-size: 12px;
            color: var(--text);
          }
          tr:last-child td { border-bottom: none; }
          tr:hover td { background: rgba(255,255,255,0.02); }
          td a {
            text-decoration: none;
            word-break: break-all;
            color: var(--text);
          }
          td a:hover { color: var(--accent); }
          .inline-warning {
            font-size: 11px;
            color: var(--warning);
            margin-top: 0.25rem;
            line-height: 1.4;
          }
          .inline-warning::before {
            content: "\u26A0 ";
          }
          .count {
            display: inline-block;
            min-width: 1.25rem;
            padding: 0.125rem 0.375rem;
            background: var(--bg-subtle);
            border-radius: 4px;
            text-align: center;
            font-size: 11px;
            color: var(--text-muted);
            font-variant-numeric: tabular-nums;
          }
          .count:empty::before { content: "0"; }

          /* Light mode */
          @media (prefers-color-scheme: light) {
            :root {
              --accent: #00a963;
              --accent-hover: #008f54;
              --bg: #ffffff;
              --bg-elevated: #f5f5f5;
              --bg-subtle: #ebebeb;
              --border: #d4d4d4;
              --border-subtle: #e5e5e5;
              --text: #171717;
              --text-muted: #525252;
              --text-faint: #737373;
              --error: #dc2626;
              --error-bg: rgba(220,38,38,0.08);
              --warning: #b45309;
            }
            tr:hover td { background: rgba(0,0,0,0.02); }
            .btn-primary { color: #fff; }
            .btn-primary:hover { color: #fff; }
            .mode-toggle a.active { color: #fff; }
            .error-banner { color: #991b1b; }
            .error-item { color: #b91c1c; }
            .error-debug-link { color: #fff; }
            .error-debug-link:hover { color: #fff; }
          }

          .debug-bar-version {
            color: var(--text-faint);
            font-size: 10px;
          }

          /* Responsive */
          @media (max-width: 640px) {
            .debug-bar { padding: 0 0.75rem; gap: 0.5rem; width: 95%; }
            .debug-bar-brand span { display: none; }
            .debug-bar-hint { display: none; }
            .debug-bar-version { display: none; }
            .mode-badge { display: none; }
            .container { padding: 1rem; }
            th, td { padding: 0.5rem 0.75rem; }
          }
          ${""}
        </style>
      </head>
      <body>
        ${hasRuntimeErrors ? `<div class="error-banner">
            <strong>Sitemap Generation Errors</strong>
            ${fetchErrors.join("")}
            <a href="${debugUrl}" target="_blank" class="error-debug-link">View Debug Info \u2192</a>
          </div>` : ""}
        <div class="container">
          <div class="header">
            <h1>${xmlEscape(title)}</h1>
            <div class="header-meta">
              ${isNotIndexButHasIndex ? `Part of <a href="${xmlEscape(fixPath("/sitemap_index.xml"))}">${xmlEscape(fixPath("/sitemap_index.xml"))}</a> \xB7 ` : ""}
              <xsl:if test="count(sitemap:sitemapindex/sitemap:sitemap) &gt; 0">
                <xsl:value-of select="count(sitemap:sitemapindex/sitemap:sitemap)"/> sitemaps
              </xsl:if>
              <xsl:if test="count(sitemap:sitemapindex/sitemap:sitemap) &lt; 1">
                <xsl:value-of select="count(sitemap:urlset/sitemap:url)"/> URLs
              </xsl:if>
            </div>
          </div>
          <xsl:if test="count(sitemap:sitemapindex/sitemap:sitemap) &gt; 0">
            <div class="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th style="width:70%">Sitemap</th>
                    <th style="width:30%">Last Modified</th>
                  </tr>
                </thead>
                <tbody>
                  <xsl:for-each select="sitemap:sitemapindex/sitemap:sitemap">
                    <xsl:variable name="sitemapURL">
                      <xsl:value-of select="sitemap:loc"/>
                    </xsl:variable>
                    <tr>
                      <td>
                        <a href="{$sitemapURL}">
                          <xsl:value-of select="sitemap:loc"/>
                        </a>
                      </td>
                      <td>
                        <xsl:value-of
                          select="concat(substring(sitemap:lastmod,0,11),concat(' ', substring(sitemap:lastmod,12,5)),concat(' ', substring(sitemap:lastmod,20,6)))"/>
                      </td>
                    </tr>
                  </xsl:for-each>
                </tbody>
              </table>
            </div>
          </xsl:if>
          <xsl:if test="count(sitemap:sitemapindex/sitemap:sitemap) &lt; 1">
            <div class="table-wrap">
              <table>
                <thead>
                  <tr>
                    ${columns.map((c) => `<th style="width:${c.width}">${c.label}</th>`).join("\n")}
                  </tr>
                </thead>
                <tbody>
                  <xsl:for-each select="sitemap:urlset/sitemap:url">
                    <tr>
                      <td>
                        <xsl:variable name="itemURL">
                          <xsl:value-of select="sitemap:loc"/>
                        </xsl:variable>
                        <a href="{$itemURL}">
                          <xsl:value-of select="sitemap:loc"/>
                        </a>
                        ${""}
                      </td>
                      ${columns.filter((c) => c.label !== "URL").map((c) => `<td><span class="count"><xsl:value-of select="${c.select}"/></span></td>`).join("\n")}
                    </tr>
                  </xsl:for-each>
                </tbody>
              </table>
            </div>
          </xsl:if>
        </div>
        ${""}
      </body>
    </html>
  </xsl:template>
</xsl:stylesheet>
`;
});

const DEFAULT_XML_STREAM_CHUNK_SIZE = 64 * 1024;
function createChunkedXmlStream(chunks, targetChunkSize = DEFAULT_XML_STREAM_CHUNK_SIZE) {
  const iterator = chunks[Symbol.iterator]();
  const encoder = new TextEncoder();
  const chunkSize = Math.max(1, Math.floor(targetChunkSize));
  let complete = false;
  let pending;
  let pendingOffset = 0;
  return new ReadableStream({
    pull(controller) {
      if (complete)
        return;
      let output = "";
      while (output.length < chunkSize) {
        if (!pending) {
          const next = iterator.next();
          if (next.done) {
            complete = true;
            break;
          }
          pending = next.value;
          pendingOffset = 0;
          if (!pending)
            continue;
        }
        const remaining = chunkSize - output.length;
        let end = Math.min(pending.length, pendingOffset + remaining);
        if (end < pending.length && end > pendingOffset && pending.charCodeAt(end - 1) >= 55296 && pending.charCodeAt(end - 1) <= 56319) {
          end--;
          if (end === pendingOffset) {
            if (output)
              break;
            end = Math.min(pending.length, pendingOffset + 2);
          }
        }
        output += pending.slice(pendingOffset, end);
        pendingOffset = end;
        if (pendingOffset === pending.length)
          pending = void 0;
      }
      if (output)
        controller.enqueue(encoder.encode(output));
      if (complete)
        controller.close();
    },
    cancel() {
      complete = true;
      iterator.return?.();
    }
  });
}

function escapeValueForXml(value) {
  if (value === true || value === false)
    return value ? "yes" : "no";
  return xmlEscape(String(value));
}
function yesNo(v) {
  return v === "yes" || v === true ? "yes" : "no";
}
const URLSET_OPENING_TAG = '<urlset xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:video="http://www.google.com/schemas/sitemap-video/1.1" xmlns:xhtml="http://www.w3.org/1999/xhtml" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1" xmlns:news="http://www.google.com/schemas/sitemap-news/0.9" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd http://www.google.com/schemas/sitemap-image/1.1 http://www.google.com/schemas/sitemap-image/1.1/sitemap-image.xsd" xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
function buildUrlXml(url, NL, I1, I2, I3, I4) {
  let xml = `${I1}<url>${NL}`;
  if (url.loc)
    xml += `${I2}<loc>${xmlEscape(url.loc)}</loc>${NL}`;
  if (url.lastmod)
    xml += `${I2}<lastmod>${xmlEscape(url.lastmod)}</lastmod>${NL}`;
  if (url.changefreq)
    xml += `${I2}<changefreq>${xmlEscape(url.changefreq)}</changefreq>${NL}`;
  if (url.priority !== void 0) {
    const p = typeof url.priority === "number" ? url.priority : Number.parseFloat(url.priority);
    xml += `${I2}<priority>${p.toFixed(1)}</priority>${NL}`;
  }
  if (url.alternatives) {
    for (const alt of url.alternatives) {
      let attrs = "";
      for (const k in alt) {
        if ((k === "href" || k === "hreflang") && Object.hasOwn(alt, k))
          attrs += ` ${k}="${xmlEscape(String(alt[k]))}"`;
      }
      xml += `${I2}<xhtml:link rel="alternate"${attrs} />${NL}`;
    }
  }
  if (url.images) {
    for (const img of url.images) {
      xml += `${I2}<image:image>${NL}${I3}<image:loc>${xmlEscape(img.loc)}</image:loc>${NL}`;
      if (img.title)
        xml += `${I3}<image:title>${xmlEscape(img.title)}</image:title>${NL}`;
      if (img.caption)
        xml += `${I3}<image:caption>${xmlEscape(img.caption)}</image:caption>${NL}`;
      if (img.geo_location)
        xml += `${I3}<image:geo_location>${xmlEscape(img.geo_location)}</image:geo_location>${NL}`;
      if (img.license)
        xml += `${I3}<image:license>${xmlEscape(img.license)}</image:license>${NL}`;
      xml += `${I2}</image:image>${NL}`;
    }
  }
  if (url.videos) {
    for (const video of url.videos) {
      xml += `${I2}<video:video>${NL}${I3}<video:title>${xmlEscape(video.title)}</video:title>${NL}`;
      if (video.thumbnail_loc)
        xml += `${I3}<video:thumbnail_loc>${xmlEscape(video.thumbnail_loc)}</video:thumbnail_loc>${NL}`;
      xml += `${I3}<video:description>${xmlEscape(video.description)}</video:description>${NL}`;
      if (video.content_loc)
        xml += `${I3}<video:content_loc>${xmlEscape(video.content_loc)}</video:content_loc>${NL}`;
      if (video.player_loc)
        xml += `${I3}<video:player_loc>${xmlEscape(video.player_loc)}</video:player_loc>${NL}`;
      if (video.duration !== void 0)
        xml += `${I3}<video:duration>${escapeValueForXml(video.duration)}</video:duration>${NL}`;
      if (video.expiration_date)
        xml += `${I3}<video:expiration_date>${xmlEscape(video.expiration_date)}</video:expiration_date>${NL}`;
      if (video.rating !== void 0)
        xml += `${I3}<video:rating>${escapeValueForXml(video.rating)}</video:rating>${NL}`;
      if (video.view_count !== void 0)
        xml += `${I3}<video:view_count>${escapeValueForXml(video.view_count)}</video:view_count>${NL}`;
      if (video.publication_date)
        xml += `${I3}<video:publication_date>${xmlEscape(video.publication_date)}</video:publication_date>${NL}`;
      if (video.family_friendly !== void 0)
        xml += `${I3}<video:family_friendly>${yesNo(video.family_friendly)}</video:family_friendly>${NL}`;
      if (video.restriction)
        xml += `${I3}<video:restriction relationship="${xmlEscape(video.restriction.relationship || "allow")}">${xmlEscape(video.restriction.restriction)}</video:restriction>${NL}`;
      if (video.platform)
        xml += `${I3}<video:platform relationship="${xmlEscape(video.platform.relationship || "allow")}">${xmlEscape(video.platform.platform)}</video:platform>${NL}`;
      if (video.requires_subscription !== void 0)
        xml += `${I3}<video:requires_subscription>${yesNo(video.requires_subscription)}</video:requires_subscription>${NL}`;
      if (video.price) {
        for (const price of video.price) {
          const c = price.currency ? ` currency="${xmlEscape(price.currency)}"` : "";
          const t = price.type ? ` type="${xmlEscape(price.type)}"` : "";
          xml += `${I3}<video:price${c}${t}>${xmlEscape(String(price.price ?? ""))}</video:price>${NL}`;
        }
      }
      if (video.uploader) {
        const info = video.uploader.info ? ` info="${xmlEscape(video.uploader.info)}"` : "";
        xml += `${I3}<video:uploader${info}>${xmlEscape(video.uploader.uploader)}</video:uploader>${NL}`;
      }
      if (video.live !== void 0)
        xml += `${I3}<video:live>${yesNo(video.live)}</video:live>${NL}`;
      if (video.tag) {
        const tags = Array.isArray(video.tag) ? video.tag : [video.tag];
        for (const t of tags) xml += `${I3}<video:tag>${xmlEscape(t)}</video:tag>${NL}`;
      }
      if (video.category)
        xml += `${I3}<video:category>${xmlEscape(video.category)}</video:category>${NL}`;
      if (video.gallery_loc)
        xml += `${I3}<video:gallery_loc>${xmlEscape(video.gallery_loc)}</video:gallery_loc>${NL}`;
      xml += `${I2}</video:video>${NL}`;
    }
  }
  if (url.news) {
    xml += `${I2}<news:news>${NL}${I3}<news:publication>${NL}`;
    xml += `${I4}<news:name>${xmlEscape(url.news.publication.name)}</news:name>${NL}`;
    xml += `${I4}<news:language>${xmlEscape(url.news.publication.language)}</news:language>${NL}`;
    xml += `${I3}</news:publication>${NL}`;
    if (url.news.title)
      xml += `${I3}<news:title>${xmlEscape(url.news.title)}</news:title>${NL}`;
    if (url.news.publication_date)
      xml += `${I3}<news:publication_date>${xmlEscape(url.news.publication_date)}</news:publication_date>${NL}`;
    xml += `${I2}</news:news>${NL}`;
  }
  xml += `${I1}</url>`;
  return xml;
}
function resolveXmlRenderContext(resolvers, { xsl, minify }, errorInfo) {
  let xslHref = xsl ? resolvers.relativeBaseUrlResolver(xsl) : false;
  if (xslHref && errorInfo?.messages.length) {
    xslHref = withQuery(xslHref, {
      errors: "true",
      error_messages: errorInfo.messages,
      error_urls: errorInfo.urls
    });
  }
  const NL = minify ? "" : "\n";
  return {
    xslHref,
    NL,
    I1: minify ? "" : "    ",
    I2: minify ? "" : "        ",
    I3: minify ? "" : "            ",
    I4: minify ? "" : "                "
  };
}
function* renderSitemapXmlChunks(urls, resolvers, config, errorInfo) {
  const { version, credits } = config;
  const { xslHref, NL, I1, I2, I3, I4 } = resolveXmlRenderContext(resolvers, config, errorInfo);
  yield xslHref ? `<?xml version="1.0" encoding="UTF-8"?><?xml-stylesheet type="text/xsl" href="${escapeValueForXml(xslHref)}"?>${NL}` : `<?xml version="1.0" encoding="UTF-8"?>${NL}`;
  yield URLSET_OPENING_TAG + NL;
  for (const url of urls) {
    yield buildUrlXml(url, NL, I1, I2, I3, I4) + NL;
  }
  yield "</urlset>";
  if (credits) {
    yield `${NL}<!-- XML Sitemap generated by @nuxtjs/sitemap v${version} at ${(/* @__PURE__ */ new Date()).toISOString()} -->`;
  }
}
function urlsToXml(urls, resolvers, config, errorInfo) {
  const { version, credits } = config;
  const { xslHref, NL, I1, I2, I3, I4 } = resolveXmlRenderContext(resolvers, config, errorInfo);
  let xml = xslHref ? `<?xml version="1.0" encoding="UTF-8"?><?xml-stylesheet type="text/xsl" href="${escapeValueForXml(xslHref)}"?>${NL}` : `<?xml version="1.0" encoding="UTF-8"?>${NL}`;
  xml += URLSET_OPENING_TAG + NL;
  for (const url of urls)
    xml += buildUrlXml(url, NL, I1, I2, I3, I4) + NL;
  xml += "</urlset>";
  if (credits)
    xml += `${NL}<!-- XML Sitemap generated by @nuxtjs/sitemap v${version} at ${(/* @__PURE__ */ new Date()).toISOString()} -->`;
  return xml;
}
function urlsToXmlStream(urls, resolvers, config, errorInfo) {
  return createChunkedXmlStream(renderSitemapXmlChunks(urls, resolvers, config, errorInfo));
}

function resolve(s, resolvers) {
  if (typeof s === "undefined")
    return void 0;
  const str = typeof s === "string" ? s : s.toString();
  if (!resolvers)
    return str;
  if (hasProtocol(str, { acceptRelative: true, strict: false }))
    return resolvers.fixSlashes(str);
  return resolvers.canonicalUrlResolver(str);
}
function removeTrailingSlash(s) {
  let pathEnd = s.length;
  const queryIndex = s.indexOf("?");
  if (queryIndex !== -1)
    pathEnd = queryIndex;
  const hashIndex = s.indexOf("#");
  if (hashIndex !== -1 && hashIndex < pathEnd)
    pathEnd = hashIndex;
  return pathEnd > 0 && s.charCodeAt(pathEnd - 1) === 47 ? s.slice(0, pathEnd - 1) + s.slice(pathEnd) : s;
}
function preNormalizeEntry(_e, resolvers) {
  const input = typeof _e === "string" ? { loc: _e } : { ..._e };
  if (input.url && !input.loc) {
    input.loc = input.url;
  }
  delete input.url;
  if (typeof input.loc !== "string") {
    input.loc = "";
  }
  const skipEncoding = input._encoded === true;
  const e = input;
  e.loc = removeTrailingSlash(e.loc);
  e._abs = hasProtocol(e.loc, { acceptRelative: false, strict: false });
  try {
    e._path = e._abs ? parseURL(e.loc) : parsePath(e.loc);
  } catch {
    e._path = null;
  }
  if (e._path) {
    const search = e._path.search;
    const qs = search && search.length > 1 ? stringifyQuery(parseQuery(search)) : "";
    const pathname = skipEncoding ? e._path.pathname : encodePath(e._path.pathname);
    e._relativeLoc = `${pathname}${qs.length ? `?${qs}` : ""}`;
    if (e._path.host) {
      e.loc = stringifyParsedURL(e._path);
    } else {
      e.loc = e._relativeLoc;
    }
  } else if (!skipEncoding && !isEncoded(e.loc)) {
    e.loc = encodeURI(e.loc);
  }
  if (e.loc === "")
    e.loc = `/`;
  e.loc = resolve(e.loc, resolvers);
  e._key = `${e._sitemap || ""}${withoutTrailingSlash(e.loc)}`;
  return e;
}
function isEncoded(url) {
  try {
    return url !== decodeURIComponent(url);
  } catch {
    return false;
  }
}
function normaliseEntry(_e, defaults, resolvers, cache) {
  const e = defaults ? defu(_e, defaults) : { ..._e };
  if (e.lastmod) {
    const date = cache?.lastmodInput === e.lastmod ? cache.lastmodOutput : normaliseDate(e.lastmod);
    if (cache && cache.lastmodInput !== e.lastmod) {
      cache.lastmodInput = e.lastmod;
      cache.lastmodOutput = date;
    }
    if (date)
      e.lastmod = date;
    else
      delete e.lastmod;
  }
  if (!e.lastmod)
    delete e.lastmod;
  e.loc = resolve(e.loc, resolvers);
  if (e.alternatives) {
    const alternatives = e.alternatives.map(({ _i18nGenerated: _, ...alternative }) => alternative);
    for (const alt of alternatives) {
      if (typeof alt.href === "string") {
        alt.href = resolve(alt.href, resolvers);
      } else if (typeof alt.href === "object" && alt.href) {
        alt.href = resolve(alt.href.href, resolvers);
      }
    }
    e.alternatives = mergeOnKey(alternatives, "hreflang");
  }
  if (e.images) {
    const images = e.images.map((i) => ({ ...i }));
    for (const img of images) {
      img.loc = resolve(img.loc, resolvers);
    }
    e.images = mergeOnKey(images, "loc");
  }
  if (e.videos) {
    const videos = e.videos.map((v) => ({ ...v }));
    for (const video of videos) {
      if (video.content_loc) {
        video.content_loc = resolve(video.content_loc, resolvers);
      }
    }
    e.videos = mergeOnKey(videos, "content_loc");
  }
  return e;
}
const IS_VALID_W3C_DATE = [
  /^\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d\.\d+([+-][0-2]\d:[0-5]\d|Z)$/,
  /^\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d([+-][0-2]\d:[0-5]\d|Z)$/,
  /^\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d([+-][0-2]\d:[0-5]\d|Z)$/,
  /^\d{4}-[01]\d-[0-3]\d$/,
  /^\d{4}-[01]\d$/,
  /^\d{4}$/
];
function isValidW3CDate(d) {
  if (!IS_VALID_W3C_DATE.some((r) => r.test(d)))
    return false;
  const [year, month, day] = d.slice(0, 10).split("-").map(Number);
  if (month !== void 0 && (month < 1 || month > 12))
    return false;
  if (day !== void 0 && (day < 1 || day > new Date(year, month, 0).getDate()))
    return false;
  return true;
}
function normaliseDate(d) {
  if (typeof d === "string") {
    const tIdx = d.indexOf("T");
    if (tIdx !== -1) {
      const t = d.slice(tIdx + 1);
      if (!t.includes("+") && !t.includes("-") && !t.includes("Z")) {
        d += "Z";
      }
    }
    if (!isValidW3CDate(d))
      return false;
    d = new Date(d);
    d.setMilliseconds(0);
    if (Number.isNaN(d.getTime()))
      return false;
  }
  const z = (n) => `0${n}`.slice(-2);
  const date = `${d.getUTCFullYear()}-${z(d.getUTCMonth() + 1)}-${z(d.getUTCDate())}`;
  if (d.getUTCHours() > 0 || d.getUTCMinutes() > 0 || d.getUTCSeconds() > 0) {
    return `${date}T${z(d.getUTCHours())}:${z(d.getUTCMinutes())}:${z(d.getUTCSeconds())}Z`;
  }
  return date;
}

function parseChunkInfo(sitemapName, sitemaps, defaultChunkSize) {
  defaultChunkSize = defaultChunkSize || 1e3;
  if (typeof sitemaps.chunks !== "undefined" && !Number.isNaN(Number(sitemapName))) {
    return {
      isChunked: true,
      baseSitemapName: "sitemap",
      chunkIndex: Number(sitemapName),
      chunkSize: defaultChunkSize
    };
  }
  if (sitemapName.includes("-")) {
    const parts = sitemapName.split("-");
    const lastPart = parts.pop();
    if (!Number.isNaN(Number(lastPart))) {
      const baseSitemapName = parts.join("-");
      const baseSitemap = sitemaps[baseSitemapName];
      if (baseSitemap && (baseSitemap.chunks || baseSitemap._isChunking)) {
        const chunkSize = typeof baseSitemap.chunks === "number" ? baseSitemap.chunks : baseSitemap.chunkSize || defaultChunkSize;
        return {
          isChunked: true,
          baseSitemapName,
          chunkIndex: Number(lastPart),
          chunkSize
        };
      }
    }
  }
  return {
    isChunked: false,
    baseSitemapName: sitemapName,
    chunkIndex: void 0,
    chunkSize: defaultChunkSize
  };
}
function sliceUrlsForChunk(urls, sitemapName, sitemaps, defaultChunkSize = 1e3) {
  const chunkInfo = parseChunkInfo(sitemapName, sitemaps, defaultChunkSize);
  if (chunkInfo.isChunked && chunkInfo.chunkIndex !== void 0) {
    const startIndex = chunkInfo.chunkIndex * chunkInfo.chunkSize;
    const endIndex = (chunkInfo.chunkIndex + 1) * chunkInfo.chunkSize;
    return urls.slice(startIndex, endIndex);
  }
  return urls;
}

const naturalCompare = new Intl.Collator(void 0, { numeric: true }).compare;
function countPathSegments(loc) {
  let segments = 1;
  for (let i = 0; i < loc.length; i++) {
    if (loc.charCodeAt(i) === 47)
      segments++;
  }
  return segments;
}
function sortInPlace(urls) {
  urls.sort((a, b) => {
    const aLoc = typeof a === "string" ? a : a.loc;
    const bLoc = typeof b === "string" ? b : b.loc;
    const aSegments = countPathSegments(aLoc);
    const bSegments = countPathSegments(bLoc);
    if (aSegments !== bSegments) {
      return aSegments - bSegments;
    }
    return naturalCompare(aLoc, bLoc);
  });
  return urls;
}

const changeFrequencies = /* @__PURE__ */ new Set([
  "always",
  "hourly",
  "daily",
  "weekly",
  "monthly",
  "yearly",
  "never"
]);
function readerEntryToSitemapInput(entry) {
  const priority = entry.priority === void 0 ? void 0 : Number.parseFloat(entry.priority);
  const changefreq = entry.changefreq && changeFrequencies.has(entry.changefreq) ? entry.changefreq : void 0;
  return {
    loc: entry.loc,
    ...entry.lastmod ? { lastmod: entry.lastmod } : {},
    ...changefreq ? { changefreq } : {},
    ...priority !== void 0 && Number.isFinite(priority) ? { priority } : {},
    ...entry.extensions?.alternatives ? { alternatives: entry.extensions.alternatives.map(({ hreflang, href }) => ({ hreflang, href })) } : {},
    ...entry.extensions?.images ? {
      images: entry.extensions.images.map((image) => ({
        loc: image.loc,
        ...image.caption ? { caption: image.caption } : {},
        ...image.geoLocation ? { geo_location: image.geoLocation } : {},
        ...image.title ? { title: image.title } : {},
        ...image.license ? { license: image.license } : {}
      }))
    } : {},
    ...entry.extensions?.videos ? { videos: entry.extensions.videos } : {},
    ...entry.extensions?.news ? { news: entry.extensions.news } : {}
  };
}
function normalizeSourceInput(source) {
  if (typeof source === "string") {
    return { context: { name: "hook" }, fetch: source };
  }
  if (Array.isArray(source)) {
    return { context: { name: "hook" }, fetch: source };
  }
  return source;
}
async function tryFetchWithFallback(url, options, event) {
  const isExternalUrl = !url.startsWith("/");
  if (isExternalUrl) {
    const strategies = [
      // Strategy 1: Use globalThis.$fetch (original approach)
      () => globalThis.$fetch(url, options),
      // Strategy 2: If event is available, try using event context even for external URLs
      event ? () => fetchWithEvent(event, url, options) : null,
      // Strategy 3: Use native fetch as last resort
      () => $fetch(url, options)
    ].filter(Boolean);
    let lastError = null;
    for (const strategy of strategies) {
      try {
        return await strategy();
      } catch (error) {
        lastError = error;
        continue;
      }
    }
    throw lastError;
  }
  return event ? await fetchWithEvent(event, url, options) : await globalThis.$fetch(url, options);
}
const SOURCE_FETCH_MEMO_KEY = "_sitemapSourceFetches";
const SERVER_CACHE_MAX_AGE$2 = staticConfig.cacheMaxAgeSeconds;
function useSourceFetchMemo(event) {
  const context = event?.context;
  if (!context)
    return void 0;
  const existing = context[SOURCE_FETCH_MEMO_KEY];
  if (existing)
    return existing;
  const memo = /* @__PURE__ */ new Map();
  context[SOURCE_FETCH_MEMO_KEY] = memo;
  return memo;
}
function hashCacheKey(key) {
  let h1 = 3735928559;
  let h2 = 1103547991;
  for (let i = 0; i < key.length; i++) {
    const ch = key.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ h1 >>> 16, 2246822507) ^ Math.imul(h2 ^ h2 >>> 13, 3266489909);
  h2 = Math.imul(h2 ^ h2 >>> 16, 2246822507) ^ Math.imul(h1 ^ h1 >>> 13, 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
}
const fetchSourceUrlsCached = defineCachedFunction(
  (event, _key, url, options) => fetchSourceUrls(url, options, event),
  {
    name: "sitemap:source-urls",
    group: "sitemap",
    base: "sitemap",
    maxAge: SERVER_CACHE_MAX_AGE$2,
    getKey: (event, key) => {
      const host = getHeader(event, "x-forwarded-host") || getHeader(event, "host") || "";
      const proto = getHeader(event, "x-forwarded-proto") || "https";
      return `source-${proto}-${host}-${hashCacheKey(key)}`;
    },
    swr: true,
    // A failed fetch must never be served again, otherwise one outage empties the sitemap for a
    // whole cache window.
    validate: (entry) => {
      const value = entry.value;
      return value !== void 0 && !value._isFailure;
    }
  }
);
function isSourceCacheEnabled() {
  const cacheMaxAgeSeconds = staticConfig.cacheMaxAgeSeconds;
  return cacheMaxAgeSeconds > 0;
}
async function fetchDataSource(input, event) {
  const context = typeof input.context === "string" ? { name: input.context } : input.context || { name: "fetch" };
  const url = typeof input.fetch === "string" ? input.fetch : input.fetch[0];
  const options = typeof input.fetch === "string" ? {} : input.fetch[1];
  const memo = useSourceFetchMemo(event);
  const key = `${url}::${JSON.stringify(options || {})}`;
  let request = memo?.get(key);
  if (!request) {
    request = event && isSourceCacheEnabled() ? fetchSourceUrlsCached(event, key, url, options) : fetchSourceUrls(url, options, event);
    memo?.set(key, request);
  }
  const result = await request;
  if (result._isFailure)
    memo?.delete(key);
  return { ...input, context, ...result };
}
async function fetchSourceUrls(url, options, event) {
  const start = Date.now();
  const isExternalUrl = !url.startsWith("/");
  const timeout = isExternalUrl ? 1e4 : options.timeout || 5e3;
  const timeoutController = new AbortController();
  const abortRequestTimeout = setTimeout(() => timeoutController.abort(), timeout);
  try {
    let isMaybeErrorResponse = false;
    const pathname = parseURL(url).pathname.toLowerCase();
    const isGzUrl = pathname.endsWith(".gz");
    const isXmlRequest = pathname.endsWith(".xml") || isGzUrl;
    const mergedHeaders = defu(
      options?.headers,
      {
        Accept: isXmlRequest ? "text/xml" : "application/json"
      },
      event && !isExternalUrl ? { host: getRequestHost(event, { xForwardedHost: true }) } : {}
    );
    const fetchOptions = {
      ...options,
      // Fetch XML sources as raw bytes so we can detect and decompress a gzip body
      // (either a `.gz` URL, or a server that serves gzip without Content-Encoding)
      // before it's mangled by a UTF-8 text decode.
      responseType: isXmlRequest ? "arrayBuffer" : "json",
      signal: timeoutController.signal,
      headers: mergedHeaders,
      // Use ofetch's built-in retry for external sources
      ...isExternalUrl && {
        retry: 2,
        retryDelay: 200
      },
      // @ts-expect-error untyped
      onResponse({ response }) {
        if (typeof response._data === "string" && response._data.startsWith("<!DOCTYPE html>"))
          isMaybeErrorResponse = true;
      }
    };
    const res = await tryFetchWithFallback(url, fetchOptions, event);
    const timeTakenMs = Date.now() - start;
    if (isMaybeErrorResponse) {
      return {
        urls: [],
        timeTakenMs,
        error: "Received HTML response instead of JSON",
        // An HTML page is usually an outage or an auth wall, both transient. Treat it like a
        // failed fetch so the empty result is never cached.
        _isFailure: true
      };
    }
    let urls = [];
    if (isXmlRequest) {
      const bytes = res instanceof Uint8Array ? res : new Uint8Array(res);
      const result = await collectSitemap(bytes);
      if (result._tag !== "document")
        throw new Error(result.issues.map((issue) => issue.message).join("; ") || "Invalid sitemap document");
      if (result.document._tag !== "urlset")
        throw new Error("Sitemap URL source must be a URL set, not a sitemap index");
      urls = result.document.entries.map(readerEntryToSitemapInput);
    } else if (typeof res === "object") {
      urls = res.urls || res;
    }
    return {
      timeTakenMs,
      urls
    };
  } catch (_err) {
    const error = _err;
    if (isExternalUrl) {
      const errorInfo = {
        url,
        timeout,
        error: error.message,
        statusCode: error.response?.status,
        statusText: error.response?.statusText,
        method: options?.method || "GET"
      };
      logger.error("Failed to fetch external source.", errorInfo);
    } else {
      logger.error("Failed to fetch source.", { url, error: error.message });
    }
    return {
      urls: [],
      error: error.message,
      _isFailure: true
      // Mark as failure to prevent caching
    };
  } finally {
    if (abortRequestTimeout) {
      clearTimeout(abortRequestTimeout);
    }
  }
}
async function globalSitemapSources() {
  const m = await import('../virtual/global-sources.mjs');
  return [...m.sources];
}
async function childSitemapSources(definition) {
  if (definition?.sources?.length)
    return [...definition.sources];
  if (definition?.urls) {
    const urls = typeof definition.urls === "function" ? await definition.urls() : definition.urls;
    return [{
      context: { name: `sitemaps:${definition.sitemapName}:urls`, description: "Set with the sitemap definition `urls`." },
      urls
    }];
  }
  if (!definition?._hasSourceChunk)
    return [];
  const m = await import('../virtual/child-sources.mjs');
  return [...m.sources[definition.sitemapName] || []];
}
async function resolveSitemapSources(sources, event) {
  return await Promise.all(
    sources.map((source) => {
      const normalized = normalizeSourceInput(source);
      if ("urls" in normalized) {
        return {
          timeTakenMs: 0,
          ...normalized,
          urls: normalized.urls
        };
      }
      if (normalized.fetch)
        return fetchDataSource(normalized, event);
      return {
        ...normalized,
        error: "Invalid source"
      };
    })
  );
}

function isGeneratedAlternative(alternative) {
  return alternative._i18nGenerated !== void 0 && alternative._i18nGenerated === JSON.stringify([alternative.hreflang, alternative.href.toString()]);
}
function resolveSitemapEntries(sitemap, urls, runtimeConfig, resolvers, baseURL) {
  const {
    autoI18n: configuredI18n,
    isI18nMapped
  } = runtimeConfig;
  const requestHost = configuredI18n?.multiDomainLocales && resolvers ? parseURL(resolvers.canonicalUrlResolver("/")).host : void 0;
  const domain = configuredI18n?.multiDomainLocales ? resolveI18nDomain(requestHost, configuredI18n) : void 0;
  const autoI18n = configuredI18n && domain ? { ...configuredI18n, defaultLocale: domain.defaultLocale } : configuredI18n;
  const availableLocales = domain?.locales || autoI18n?.locales;
  const hasFilters = !!sitemap.include?.length || !!sitemap.exclude?.length;
  const filterPath = hasFilters ? createPathFilter({
    include: sitemap.include,
    exclude: sitemap.exclude
  }, baseURL || "/") : void 0;
  const domainLocaleCodes = autoI18n?.multiDomainLocales && autoI18n.strategy !== "no_prefix" ? new Set(autoI18n.locales.map((l) => l.code)) : void 0;
  const domainLocaleKeys = autoI18n?.multiDomainLocales ? autoI18n.locales.map((l) => l._sitemap) : [];
  const _urls = [];
  const unavailableEntries = /* @__PURE__ */ new Set();
  for (const _e of urls) {
    const e = preNormalizeEntry(_e, resolvers);
    if (autoI18n && domainLocaleCodes && !e._abs && !e._i18nTransform && !e._i18nUnlocalized) {
      const prefix = splitForLocales(e._path?.pathname || "/", domainLocaleCodes)[0];
      const localeCode = prefix || autoI18n.defaultLocale;
      const sitemapLocale = isI18nMapped && typeof e._sitemap === "string" ? resolveI18nSitemapLocaleKey(e._sitemap, domainLocaleKeys) : null;
      const locale = autoI18n.locales.find((l) => l.code === localeCode);
      if (locale && availableLocales && !availableLocales.includes(locale))
        continue;
      if (autoI18n.strategy === "prefix_except_default" && prefix === autoI18n.defaultLocale)
        continue;
      if (sitemapLocale && sitemapLocale !== locale?._sitemap)
        continue;
      if (e.alternatives?.some(isGeneratedAlternative)) {
        const alternatives = e.alternatives.filter((alternative) => {
          if (!isGeneratedAlternative(alternative))
            return true;
          if (alternative.hreflang === "x-default")
            return false;
          const alternateLocale = autoI18n.locales.find((l) => l._hreflang === alternative.hreflang);
          if (!alternateLocale)
            return true;
          if (availableLocales && !availableLocales.includes(alternateLocale))
            return false;
          const alternatePrefix = splitForLocales(parseURL(alternative.href.toString()).pathname || "/", domainLocaleCodes)[0];
          if (["prefix_except_default", "prefix_and_default"].includes(autoI18n.strategy) && alternatePrefix === autoI18n.defaultLocale)
            return false;
          return (alternatePrefix || autoI18n.defaultLocale) === alternateLocale.code;
        });
        const defaultHreflang = autoI18n.locales.find((l) => l.code === autoI18n.defaultLocale)?._hreflang;
        const defaultAlternative = alternatives.find((a) => a.hreflang === defaultHreflang);
        e.alternatives = defaultAlternative && !alternatives.some((alternative) => alternative.hreflang === "x-default") ? [...alternatives, { ...defaultAlternative, hreflang: "x-default" }] : alternatives;
      }
    }
    const needsExpansion = e._i18nTransform && autoI18n && autoI18n.strategy !== "no_prefix";
    if (e.loc && (needsExpansion || !filterPath || filterPath(e.loc, e._path?.pathname)))
      _urls.push(e);
  }
  const withoutPrefixPaths = {};
  if (autoI18n && autoI18n.strategy !== "no_prefix") {
    const localeCodes = new Set(autoI18n.locales.map((l) => l.code));
    const localeByCode = new Map(autoI18n.locales.map((l) => [l.code, l]));
    const defaultLocale = autoI18n.defaultLocale;
    const hasDifferentDomains = !!autoI18n.differentDomains;
    const validI18nUrlsForTransform = [];
    for (let i = 0; i < _urls.length; i++) {
      const _e = _urls[i];
      if (_e._abs && !_e._i18nTransform)
        continue;
      const split = _e._i18nUnlocalized ? [null, _e._relativeLoc] : splitForLocales(_e._relativeLoc, localeCodes);
      let localeCode = split[0];
      const pathWithoutPrefix = split[1];
      if (!localeCode)
        localeCode = defaultLocale;
      const e = _e;
      e._pathWithoutPrefix = pathWithoutPrefix;
      const locale = localeByCode.get(localeCode);
      if (!locale)
        continue;
      e._locale = locale;
      e._index = i;
      e._key = `${e._sitemap || ""}${e._path?.pathname || "/"}${e._path?.search || ""}`;
      withoutPrefixPaths[pathWithoutPrefix] = withoutPrefixPaths[pathWithoutPrefix] || [];
      if (!e._i18nTransform && !e._i18nUnlocalized && !withoutPrefixPaths[pathWithoutPrefix].some((e2) => e2._locale.code === locale.code))
        withoutPrefixPaths[pathWithoutPrefix].push(e);
      validI18nUrlsForTransform.push(e);
    }
    for (const e of validI18nUrlsForTransform) {
      if (!e._i18nTransform && !e.alternatives?.length) {
        const alternatives = [];
        for (const u of e._i18nUnlocalized ? [e] : withoutPrefixPaths[e._pathWithoutPrefix] || []) {
          if (autoI18n.multiDomainLocales && availableLocales && !availableLocales.includes(u._locale))
            continue;
          if (u._locale.code === defaultLocale) {
            alternatives.push({
              href: u.loc,
              hreflang: "x-default"
            });
          }
          alternatives.push({
            href: u.loc,
            hreflang: u._locale._hreflang || defaultLocale
          });
        }
        if (alternatives.length)
          e.alternatives = alternatives;
      } else if (e._i18nTransform) {
        delete e._i18nTransform;
        const routeEntries = resolveI18nRouteEntries(e._relativeLoc, autoI18n, (href) => !filterPath || filterPath(href), autoI18n.multiDomainLocales ? { host: requestHost || "", domainMode: "request" } : {});
        if (autoI18n.multiDomainLocales) {
          if (!routeEntries.length) {
            unavailableEntries.add(e);
            continue;
          }
          if (autoI18n.strategy === "prefix_and_default") {
            const defaultEntry = routeEntries.find((entry) => entry.locale.code === defaultLocale);
            if (defaultEntry) {
              routeEntries.push({ ...defaultEntry, loc: `/${defaultLocale}${defaultEntry.loc === "/" ? "" : defaultEntry.loc}` });
            }
          }
        }
        if (hasDifferentDomains) {
          e.alternatives = routeEntries[0]?.alternatives;
        } else {
          const sourceLocaleAvailable = routeEntries.some((entry) => entry.locale.code === e._locale.code);
          for (const { alternatives, locale: l, loc } of routeEntries) {
            const _sitemap = isI18nMapped ? l._sitemap : void 0;
            const { _index: _, ...rest } = e;
            const newEntry = preNormalizeEntry({
              _sitemap,
              ...rest,
              _key: `${_sitemap || ""}${loc || "/"}`,
              _locale: l,
              loc,
              alternatives
            }, resolvers);
            if (e._index !== void 0 && (e._locale.code === newEntry._locale.code || !sourceLocaleAvailable)) {
              _urls[e._index] = newEntry;
              e._index = void 0;
            } else {
              _urls.push(newEntry);
            }
          }
        }
      }
      if (isI18nMapped) {
        e._sitemap = e._sitemap || e._locale._sitemap;
        e._key = `${e._sitemap || ""}${e.loc || "/"}${e._path?.search || ""}`;
      }
      if (e._index)
        _urls[e._index] = e;
    }
  }
  return _urls.filter((entry) => !unavailableEntries.has(entry) && (!filterPath || filterPath(entry.loc, entry._path?.pathname)));
}

const SERVER_CACHE_MAX_AGE$1 = staticConfig.cacheMaxAgeSeconds;
async function buildResolvedSitemapUrls(effectiveSitemap, matchName, isChunked, resolvers, runtimeConfig, nitro) {
  const { sitemaps, autoI18n, isI18nMapped, isMultiSitemap, sortEntries } = runtimeConfig;
  let sourcesInput = effectiveSitemap.includeAppSources ? [...await globalSitemapSources(), ...await childSitemapSources(effectiveSitemap)] : await childSitemapSources(effectiveSitemap);
  if (nitro && resolvers.event) {
    const ctx = {
      event: resolvers.event,
      sitemapName: matchName,
      sources: sourcesInput
    };
    await nitro.hooks.callHook("sitemap:sources", ctx);
    sourcesInput = ctx.sources;
  }
  const sources = await resolveSitemapSources(sourcesInput, resolvers.event);
  const failedSources = sources.filter((source) => source.error && source._isFailure).map((source) => ({
    url: typeof source.fetch === "string" ? source.fetch : source.fetch?.[0] || "unknown",
    error: source.error || "Unknown error"
  }));
  const resolvedCtx = {
    urls: sources.flatMap((s) => s.urls),
    sitemapName: matchName,
    event: resolvers.event
  };
  await nitro?.hooks.callHook("sitemap:input", resolvedCtx);
  const enhancedUrls = resolveSitemapEntries(effectiveSitemap, resolvedCtx.urls, { autoI18n, isI18nMapped }, resolvers, useRuntimeConfig().app.baseURL);
  const localeSitemapKeys = isI18nMapped && autoI18n ? autoI18n.locales.map((l) => l._sitemap) : [];
  if (isMultiSitemap) {
    const sitemapNames = Object.keys(sitemaps).filter((k) => k !== "index");
    const validSitemapNames = new Set(sitemapNames);
    if (isI18nMapped) {
      for (const name of sitemapNames) {
        const localeKey = resolveI18nSitemapLocaleKey(name, localeSitemapKeys);
        if (localeKey)
          validSitemapNames.add(localeKey);
      }
    }
    const warnedSitemaps = nitro?._sitemapWarnedSitemaps || /* @__PURE__ */ new Set();
    for (const e of enhancedUrls) {
      const hasMatchingSitemap = typeof e._sitemap === "string" && validSitemapNames.has(e._sitemap);
      if (typeof e._sitemap === "string" && !hasMatchingSitemap) {
        if (!warnedSitemaps.has(e._sitemap)) {
          warnedSitemaps.add(e._sitemap);
          logger.error(`Sitemap \`${e._sitemap}\` not found in sitemap config. Available sitemaps: ${sitemapNames.join(", ")}. Either add it to the sitemap config or register it with the sitemap:sitemaps-resolved hook. Entry \`${e.loc}\` will be omitted.`);
        }
      }
    }
    if (nitro) {
      nitro._sitemapWarnedSitemaps = warnedSitemaps;
    }
  }
  const matchedLocaleSitemap = isI18nMapped ? resolveI18nSitemapLocaleKey(matchName, localeSitemapKeys) : null;
  const filteredUrls = enhancedUrls.filter((e) => {
    if (e._sitemap === false)
      return false;
    if (isMultiSitemap && e._sitemap && matchName) {
      if (isChunked)
        return e._sitemap === matchName;
      if (e._sitemap === matchName)
        return true;
      if (isI18nMapped)
        return e._sitemap === matchedLocaleSitemap;
      return false;
    }
    return true;
  });
  const urls = sortEntries ? sortInPlace(filteredUrls) : filteredUrls;
  return { urls, failedSources };
}
const buildResolvedSitemapUrlsCached = defineCachedFunction(
  async (_event, effectiveSitemap, matchName, isChunked, resolvers, runtimeConfig, nitro) => buildResolvedSitemapUrls(effectiveSitemap, matchName, isChunked, resolvers, runtimeConfig, nitro),
  {
    name: "sitemap:resolved-urls",
    group: "sitemap",
    base: "sitemap",
    maxAge: SERVER_CACHE_MAX_AGE$1,
    getKey: (event, _effectiveSitemap, matchName, isChunked) => {
      const host = getHeader(event, "x-forwarded-host") || getHeader(event, "host") || "";
      const proto = getHeader(event, "x-forwarded-proto") || "https";
      return `resolved-${isChunked ? "chunked-" : ""}${matchName}-${proto}-${host}`;
    },
    swr: true,
    // A build with failed sources is never cached: one outage must not pin an empty sitemap
    // for a whole cache window. The next request retries the sources instead.
    validate: (entry) => {
      const value = entry.value;
      return value !== void 0 && !value.failedSources?.length;
    }
  }
);
async function getResolvedSitemapUrls(effectiveSitemap, matchName, isChunked, resolvers, runtimeConfig, nitro) {
  const event = resolvers.event;
  const shouldCache = typeof runtimeConfig.cacheMaxAgeSeconds === "number" && runtimeConfig.cacheMaxAgeSeconds > 0;
  if (shouldCache && event) {
    return buildResolvedSitemapUrlsCached(event, effectiveSitemap, matchName, isChunked, resolvers, runtimeConfig, nitro);
  }
  return buildResolvedSitemapUrls(effectiveSitemap, matchName, isChunked, resolvers, runtimeConfig, nitro);
}
async function buildSitemapUrls(sitemap, resolvers, runtimeConfig, nitro) {
  const { sitemaps, autoI18n, defaultSitemapsChunkSize } = runtimeConfig;
  const chunkSize = defaultSitemapsChunkSize || void 0;
  const chunkInfo = parseChunkInfo(sitemap.sitemapName, sitemaps, chunkSize);
  if (autoI18n?.differentDomains) {
    const domain = autoI18n.locales.find((e) => e.language === sitemap.sitemapName || e.code === sitemap.sitemapName)?.domain;
    if (domain) {
      const _tester = resolvers.canonicalUrlResolver;
      resolvers.canonicalUrlResolver = (path) => resolveSitePath(path, {
        absolute: true,
        withBase: false,
        siteUrl: withHttps(domain),
        trailingSlash: _tester("/test/").endsWith("/"),
        base: "/"
      });
    }
  }
  let effectiveSitemap = sitemap;
  const baseSitemapName = chunkInfo.baseSitemapName;
  if (chunkInfo.isChunked && baseSitemapName !== sitemap.sitemapName && sitemaps[baseSitemapName]) {
    effectiveSitemap = sitemaps[baseSitemapName];
  }
  const matchName = chunkInfo.isChunked ? baseSitemapName : sitemap.sitemapName;
  const resolved = await getResolvedSitemapUrls(effectiveSitemap, matchName, chunkInfo.isChunked, resolvers, runtimeConfig, nitro);
  const urls = sliceUrlsForChunk(resolved.urls, sitemap.sitemapName, sitemaps, chunkSize);
  return { urls, failedSources: resolved.failedSources };
}

const SERVER_CACHE_MAX_AGE = staticConfig.cacheMaxAgeSeconds;
function useNitroUrlResolvers(e) {
  const canonicalQuery = getQuery(e).canonical;
  const isShowingCanonical = typeof canonicalQuery !== "undefined" && canonicalQuery !== "false";
  const siteConfig = getSiteConfig(e);
  return {
    event: e,
    fixSlashes: (path) => fixSlashes(siteConfig.trailingSlash, path),
    // we need these as they depend on the nitro event
    canonicalUrlResolver: createSitePathResolver(e, {
      canonical: isShowingCanonical || true,
      absolute: true,
      withBase: true
    }),
    relativeBaseUrlResolver: createSitePathResolver(e, { absolute: false, withBase: true })
  };
}
async function buildSitemapRenderPlan(event, definition, resolvers, runtimeConfig) {
  const { sitemapName } = definition;
  const nitro = useNitroApp();
  const { urls: resolvedSitemapUrls, failedSources } = await buildSitemapUrls(definition, resolvers, runtimeConfig, nitro);
  const sitemapUrls = resolvedSitemapUrls.slice();
  const routeRuleMatcher = createNitroRouteRuleMatcher(useRuntimeConfig(event));
  const { autoI18n } = runtimeConfig;
  const localeCodes = autoI18n?.locales && autoI18n.strategy !== "no_prefix" ? new Set(autoI18n.locales.map((l) => l.code)) : void 0;
  sitemapUrls.length;
  let validCount = 0;
  for (let i = 0; i < sitemapUrls.length; i++) {
    const u = sitemapUrls[i];
    const path = u._path?.pathname || u.loc;
    let routeRules = routeRuleMatcher(path);
    if (localeCodes) {
      const match = splitForLocales(path, localeCodes);
      const pathWithoutPrefix = match[1];
      if (pathWithoutPrefix && pathWithoutPrefix !== path)
        routeRules = defu(routeRules, routeRuleMatcher(pathWithoutPrefix));
    }
    if (routeRules.sitemap === false)
      continue;
    if (robotsBlocksIndexing(routeRules.robots))
      continue;
    let hasRobotsDisabled = false;
    const headers = routeRules.headers;
    if (headers) {
      for (const name in headers) {
        if (name.toLowerCase() === "x-robots-tag" && headers[name].toLowerCase().includes("noindex")) {
          hasRobotsDisabled = true;
          break;
        }
      }
    }
    if (routeRules.redirect || hasRobotsDisabled)
      continue;
    sitemapUrls[validCount++] = routeRules.sitemap ? defu(u, routeRules.sitemap) : u;
  }
  sitemapUrls.length = validCount;
  const locSize = sitemapUrls.length;
  const resolvedCtx = {
    urls: sitemapUrls,
    sitemapName,
    event
  };
  await nitro.hooks.callHook("sitemap:resolved", resolvedCtx);
  if (resolvedCtx.urls.length !== locSize) {
    for (let i = 0; i < resolvedCtx.urls.length; i++)
      resolvedCtx.urls[i] = preNormalizeEntry(resolvedCtx.urls[i], resolvers);
  }
  const maybeSort = (urls2) => runtimeConfig.sortEntries ? sortInPlace(urls2) : urls2;
  const defaults = definition.defaults;
  const normalizedPreDedupe = resolvedCtx.urls;
  const firstLastmod = normalizedPreDedupe[0]?.lastmod ?? defaults?.lastmod;
  let cacheLastmod = normalizedPreDedupe.length > 1 && !!firstLastmod;
  for (let i = 1; cacheLastmod && i < Math.min(normalizedPreDedupe.length, 8); i++)
    cacheLastmod = (normalizedPreDedupe[i].lastmod ?? defaults?.lastmod) === firstLastmod;
  const normaliseCache = cacheLastmod ? {} : void 0;
  for (let i = 0; i < normalizedPreDedupe.length; i++)
    normalizedPreDedupe[i] = normaliseEntry(normalizedPreDedupe[i], defaults, resolvers, normaliseCache);
  const duplicateKeys = /* @__PURE__ */ new Set();
  const urls = mergeOnKey(normalizedPreDedupe, "_key", (key) => duplicateKeys.add(key));
  if (duplicateKeys.size) {
    for (let i = 0; i < urls.length; i++) {
      if (duplicateKeys.has(urls[i]._key))
        urls[i] = normaliseEntry(urls[i], defaults, resolvers, normaliseCache);
    }
  }
  maybeSort(urls);
  if (definition._isChunking && definition.sitemapName.includes("-")) {
    const parts = definition.sitemapName.split("-");
    const lastPart = parts.pop();
    if (!Number.isNaN(Number(lastPart))) {
      const chunkIndex = Number(lastPart);
      const baseSitemapName = parts.join("-");
      if (urls.length === 0 && chunkIndex > 0) {
        throw createError$1({
          statusCode: 404,
          message: `Sitemap chunk ${chunkIndex} for "${baseSitemapName}" does not exist.`
        });
      }
    }
  }
  const errorInfo = failedSources.length > 0 ? {
    messages: failedSources.map((f) => f.error),
    urls: failedSources.map((f) => f.url)
  } : void 0;
  return { errorInfo, sitemapName, urls };
}
async function renderSitemapOutput(nitro, event, sitemapName, renderString, renderStream, shouldStream, debug) {
  let buffered = false;
  let sitemap;
  const ctx = { sitemapName, event };
  Object.defineProperty(ctx, "sitemap", {
    configurable: true,
    enumerable: true,
    get() {
      buffered = true;
      sitemap ??= renderString();
      return sitemap;
    },
    set(value) {
      buffered = true;
      sitemap = value;
    }
  });
  await nitro.hooks.callHook("sitemap:output", ctx);
  if (debug)
    setHeader(event, "X-Sitemap-Render-Mode", buffered ? "buffered-hook" : "stream");
  return buffered ? createChunkedXmlStream([sitemap]) : renderStream();
}
async function buildSitemapXml(event, definition, resolvers, runtimeConfig) {
  const { errorInfo, sitemapName, urls } = await buildSitemapRenderPlan(event, definition, resolvers, runtimeConfig);
  const sitemap = urlsToXml(urls, resolvers, runtimeConfig, errorInfo);
  const ctx = { sitemap, sitemapName, event };
  await useNitroApp().hooks.callHook("sitemap:output", ctx);
  return ctx.sitemap;
}
function getSitemapCacheKey(event, definition) {
  const host = getHeader(event, "x-forwarded-host") || getHeader(event, "host") || "";
  const proto = getHeader(event, "x-forwarded-proto") || "https";
  const sitemapName = definition.sitemapName || "default";
  return `${sitemapName}-${proto}-${host}`;
}
const buildSitemapRenderPlanCached = defineCachedFunction(
  buildSitemapRenderPlan,
  {
    name: "sitemap:render-plan",
    group: "sitemap",
    maxAge: SERVER_CACHE_MAX_AGE,
    base: "sitemap",
    getKey: getSitemapCacheKey,
    swr: true
  }
);
const buildSitemapXmlCached = defineCachedFunction(
  buildSitemapXml,
  {
    name: "sitemap:xml",
    group: "sitemap",
    maxAge: SERVER_CACHE_MAX_AGE,
    base: "sitemap",
    // Use the sitemap storage
    getKey: getSitemapCacheKey,
    swr: true
    // Enable stale-while-revalidate
  }
);
function setSitemapResponseHeaders(event, runtimeConfig) {
  setHeader(event, "Content-Type", "text/xml; charset=UTF-8");
  if (runtimeConfig.cacheMaxAgeSeconds) {
    setHeader(event, "Cache-Control", `public, max-age=${runtimeConfig.cacheMaxAgeSeconds}, s-maxage=${runtimeConfig.cacheMaxAgeSeconds}, stale-while-revalidate=3600`);
    const now = /* @__PURE__ */ new Date();
    setHeader(event, "X-Sitemap-Generated", now.toISOString());
    setHeader(event, "X-Sitemap-Cache-Duration", `${runtimeConfig.cacheMaxAgeSeconds}s`);
    const expiryTime = new Date(now.getTime() + runtimeConfig.cacheMaxAgeSeconds * 1e3);
    setHeader(event, "X-Sitemap-Cache-Expires", expiryTime.toISOString());
    const remainingSeconds = Math.floor((expiryTime.getTime() - now.getTime()) / 1e3);
    setHeader(event, "X-Sitemap-Cache-Remaining", `${remainingSeconds}s`);
  } else {
    setHeader(event, "Cache-Control", `no-cache, no-store`);
  }
  event.context._isSitemap = true;
}
async function createSitemap(event, definition, runtimeConfig) {
  const resolvers = useNitroUrlResolvers(event);
  const shouldStream = !!runtimeConfig.experimentalStreaming && true;
  const shouldCache = typeof runtimeConfig.cacheMaxAgeSeconds === "number" && runtimeConfig.cacheMaxAgeSeconds > 0;
  let xml;
  if (shouldStream) {
    const { errorInfo, sitemapName, urls } = shouldCache ? await buildSitemapRenderPlanCached(event, definition, resolvers, runtimeConfig) : await buildSitemapRenderPlan(event, definition, resolvers, runtimeConfig);
    xml = await renderSitemapOutput(
      useNitroApp(),
      event,
      sitemapName,
      () => urlsToXml(urls, resolvers, runtimeConfig, errorInfo),
      () => urlsToXmlStream(urls, resolvers, runtimeConfig, errorInfo),
      true,
      runtimeConfig.debug
    );
  } else {
    xml = shouldCache ? await buildSitemapXmlCached(event, definition, resolvers, runtimeConfig) : await buildSitemapXml(event, definition, resolvers, runtimeConfig);
  }
  setSitemapResponseHeaders(event, runtimeConfig);
  return xml;
}

async function sitemapXmlEventHandler(e) {
  const runtimeConfig = await useResolvedSitemapRuntimeConfig(e);
  const { sitemaps } = runtimeConfig;
  if ("index" in sitemaps)
    return sendRedirect(e, withBase("/sitemap_index.xml", useRuntimeConfig().app.baseURL), 301);
  return createSitemap(e, Object.values(sitemaps)[0], runtimeConfig);
}

const _qhuwPj = defineEventHandler(sitemapXmlEventHandler);

const _SxA8c9 = defineEventHandler(() => {});

const _lazy_4_p_xR = () => import('../routes/api/_...path_.mjs');
const _lazy_y75UUM = () => import('../routes/oss/_...path_.mjs');
const _lazy_eEiJoI = () => import('../routes/sitemap-urls.json.get.mjs');
const _lazy_4hSsWk = () => import('../routes/renderer.mjs').then(function (n) { return n.r; });

const handlers = [
  { route: '', handler: _g_tsVx, lazy: false, middleware: true, method: undefined },
  { route: '/api/**:path', handler: _lazy_4_p_xR, lazy: true, middleware: false, method: undefined },
  { route: '/oss/**:path', handler: _lazy_y75UUM, lazy: true, middleware: false, method: undefined },
  { route: '/sitemap-urls.json', handler: _lazy_eEiJoI, lazy: true, middleware: false, method: "get" },
  { route: '/__nuxt_error', handler: _lazy_4hSsWk, lazy: true, middleware: false, method: undefined },
  { route: '', handler: _dMZTdp, lazy: false, middleware: true, method: undefined },
  { route: '/__sitemap__/style.xsl', handler: _uygUoA, lazy: false, middleware: false, method: undefined },
  { route: '/sitemap.xml', handler: _qhuwPj, lazy: false, middleware: false, method: undefined },
  { route: '/__nuxt_island/**', handler: _SxA8c9, lazy: false, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_4hSsWk, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const captureError = (error, context = {}) => {
    const promise = hooks.callHookParallel("error", error, context).catch((error_) => {
      console.error("Error while capturing another error", error_);
    });
    if (context.event && isEvent(context.event)) {
      const errors = context.event.context.nitro?.errors;
      if (errors) {
        errors.push({ error, context });
      }
      if (context.event.waitUntil) {
        context.event.waitUntil(promise);
      }
    }
  };
  const h3App = createApp({
    debug: destr(false),
    onError: (error, event) => {
      captureError(error, { event, tags: ["request"] });
      return errorHandler(error, event);
    },
    onRequest: async (event) => {
      event.context.nitro = event.context.nitro || { errors: [] };
      const fetchContext = event.node.req?.__unenv__;
      if (fetchContext?._platform) {
        event.context = {
          _platform: fetchContext?._platform,
          // #3335
          ...fetchContext._platform,
          ...event.context
        };
      }
      if (!event.context.waitUntil && fetchContext?.waitUntil) {
        event.context.waitUntil = fetchContext.waitUntil;
      }
      event.fetch = (req, init) => fetchWithEvent$1(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent$1(event, req, init, {
        fetch: $fetch
      });
      event.waitUntil = (promise) => {
        if (!event.context.nitro._waitUntilPromises) {
          event.context.nitro._waitUntilPromises = [];
        }
        event.context.nitro._waitUntilPromises.push(promise);
        if (event.context.waitUntil) {
          event.context.waitUntil(promise);
        }
      };
      event.captureError = (error, context) => {
        captureError(error, { event, ...context });
      };
      await nitroApp$1.hooks.callHook("request", event).catch((error) => {
        captureError(error, { event, tags: ["request"] });
      });
    },
    onBeforeResponse: async (event, response) => {
      await nitroApp$1.hooks.callHook("beforeResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    },
    onAfterResponse: async (event, response) => {
      await nitroApp$1.hooks.callHook("afterResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    }
  });
  const router = createRouter({
    preemptive: true
  });
  const nodeHandler = toNodeListener(h3App);
  const localCall = (aRequest) => b$1(
    nodeHandler,
    aRequest
  );
  const localFetch = (input, init) => {
    if (!input.toString().startsWith("/")) {
      return globalThis.fetch(input, init);
    }
    return C(
      nodeHandler,
      input,
      init
    ).then((response) => normalizeFetchResponse(response));
  };
  const $fetch = createFetch({
    fetch: localFetch,
    Headers: Headers$1,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(createRouteRulesHandler({ localFetch }));
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router.handler);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch,
    captureError
  };
  return app;
}
function runNitroPlugins(nitroApp2) {
  for (const plugin of plugins) {
    try {
      plugin(nitroApp2);
    } catch (error) {
      nitroApp2.captureError(error, { tags: ["plugin"] });
      throw error;
    }
  }
}
const nitroApp$1 = createNitroApp();
function useNitroApp() {
  return nitroApp$1;
}
runNitroPlugins(nitroApp$1);

function defineRenderHandler(render) {
  const runtimeConfig = useRuntimeConfig();
  return eventHandler(async (event) => {
    const nitroApp = useNitroApp();
    const ctx = { event, render, response: void 0 };
    await nitroApp.hooks.callHook("render:before", ctx);
    if (!ctx.response) {
      if (event.path === `${runtimeConfig.app.baseURL}favicon.ico`) {
        setResponseHeader(event, "Content-Type", "image/x-icon");
        return send(
          event,
          "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
        );
      }
      ctx.response = await ctx.render(event);
      if (!ctx.response) {
        const _currentStatus = getResponseStatus(event);
        setResponseStatus(event, _currentStatus === 200 ? 500 : _currentStatus);
        return send(
          event,
          "No response returned from render handler: " + event.path
        );
      }
    }
    await nitroApp.hooks.callHook("render:response", ctx.response, ctx);
    if (ctx.response.headers) {
      setResponseHeaders(event, ctx.response.headers);
    }
    if (ctx.response.statusCode || ctx.response.statusMessage) {
      setResponseStatus(
        event,
        ctx.response.statusCode,
        ctx.response.statusMessage
      );
    }
    return ctx.response.body;
  });
}

const debug = (...args) => {
};
function GracefulShutdown(server, opts) {
  opts = opts || {};
  const options = Object.assign(
    {
      signals: "SIGINT SIGTERM",
      timeout: 3e4,
      development: false,
      forceExit: true,
      onShutdown: (signal) => Promise.resolve(signal),
      preShutdown: (signal) => Promise.resolve(signal)
    },
    opts
  );
  let isShuttingDown = false;
  const connections = {};
  let connectionCounter = 0;
  const secureConnections = {};
  let secureConnectionCounter = 0;
  let failed = false;
  let finalRun = false;
  function onceFactory() {
    let called = false;
    return (emitter, events, callback) => {
      function call() {
        if (!called) {
          called = true;
          return Reflect.apply(callback, this, arguments);
        }
      }
      for (const e of events) {
        emitter.on(e, call);
      }
    };
  }
  const signals = options.signals.split(" ").map((s) => s.trim()).filter((s) => s.length > 0);
  const once = onceFactory();
  once(process, signals, (signal) => {
    debug("received shut down signal", signal);
    shutdown(signal).then(() => {
      if (options.forceExit) {
        process.exit(failed ? 1 : 0);
      }
    }).catch((error) => {
      debug("server shut down error occurred", error);
      process.exit(1);
    });
  });
  function isFunction(functionToCheck) {
    const getType = Object.prototype.toString.call(functionToCheck);
    return /^\[object\s([A-Za-z]+)?Function]$/.test(getType);
  }
  function destroy(socket, force = false) {
    if (socket._isIdle && isShuttingDown || force) {
      socket.destroy();
      if (socket.server instanceof http.Server) {
        delete connections[socket._connectionId];
      } else {
        delete secureConnections[socket._connectionId];
      }
    }
  }
  function destroyAllConnections(force = false) {
    debug("Destroy Connections : " + (force ? "forced close" : "close"));
    let counter = 0;
    let secureCounter = 0;
    for (const key of Object.keys(connections)) {
      const socket = connections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        counter++;
        destroy(socket);
      }
    }
    debug("Connections destroyed : " + counter);
    debug("Connection Counter    : " + connectionCounter);
    for (const key of Object.keys(secureConnections)) {
      const socket = secureConnections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        secureCounter++;
        destroy(socket);
      }
    }
    debug("Secure Connections destroyed : " + secureCounter);
    debug("Secure Connection Counter    : " + secureConnectionCounter);
  }
  server.on("request", (req, res) => {
    req.socket._isIdle = false;
    if (isShuttingDown && !res.headersSent) {
      res.setHeader("connection", "close");
    }
    res.on("finish", () => {
      req.socket._isIdle = true;
      destroy(req.socket);
    });
  });
  server.on("connection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = connectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      connections[id] = socket;
      socket.once("close", () => {
        delete connections[socket._connectionId];
      });
    }
  });
  server.on("secureConnection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = secureConnectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      secureConnections[id] = socket;
      socket.once("close", () => {
        delete secureConnections[socket._connectionId];
      });
    }
  });
  process.on("close", () => {
    debug("closed");
  });
  function shutdown(sig) {
    function cleanupHttp() {
      destroyAllConnections();
      debug("Close http server");
      return new Promise((resolve, reject) => {
        server.close((err) => {
          if (err) {
            return reject(err);
          }
          return resolve(true);
        });
      });
    }
    debug("shutdown signal - " + sig);
    if (options.development) {
      debug("DEV-Mode - immediate forceful shutdown");
      return process.exit(0);
    }
    function finalHandler() {
      if (!finalRun) {
        finalRun = true;
        if (options.finally && isFunction(options.finally)) {
          debug("executing finally()");
          options.finally();
        }
      }
      return Promise.resolve();
    }
    function waitForReadyToShutDown(totalNumInterval) {
      debug(`waitForReadyToShutDown... ${totalNumInterval}`);
      if (totalNumInterval === 0) {
        debug(
          `Could not close connections in time (${options.timeout}ms), will forcefully shut down`
        );
        return Promise.resolve(true);
      }
      const allConnectionsClosed = Object.keys(connections).length === 0 && Object.keys(secureConnections).length === 0;
      if (allConnectionsClosed) {
        debug("All connections closed. Continue to shutting down");
        return Promise.resolve(false);
      }
      debug("Schedule the next waitForReadyToShutdown");
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve(waitForReadyToShutDown(totalNumInterval - 1));
        }, 250);
      });
    }
    if (isShuttingDown) {
      return Promise.resolve();
    }
    debug("shutting down");
    return options.preShutdown(sig).then(() => {
      isShuttingDown = true;
      cleanupHttp();
    }).then(() => {
      const pollIterations = options.timeout ? Math.round(options.timeout / 250) : 0;
      return waitForReadyToShutDown(pollIterations);
    }).then((force) => {
      debug("Do onShutdown now");
      if (force) {
        destroyAllConnections(force);
      }
      return options.onShutdown(sig);
    }).then(finalHandler).catch((error) => {
      const errString = typeof error === "string" ? error : JSON.stringify(error);
      debug(errString);
      failed = true;
      throw errString;
    });
  }
  function shutdownManual() {
    return shutdown("manual");
  }
  return shutdownManual;
}

function getGracefulShutdownConfig() {
  return {
    disabled: !!process.env.NITRO_SHUTDOWN_DISABLED,
    signals: (process.env.NITRO_SHUTDOWN_SIGNALS || "SIGTERM SIGINT").split(" ").map((s) => s.trim()),
    timeout: Number.parseInt(process.env.NITRO_SHUTDOWN_TIMEOUT || "", 10) || 3e4,
    forceExit: !process.env.NITRO_SHUTDOWN_NO_FORCE_EXIT
  };
}
function setupGracefulShutdown(listener, nitroApp) {
  const shutdownConfig = getGracefulShutdownConfig();
  if (shutdownConfig.disabled) {
    return;
  }
  GracefulShutdown(listener, {
    signals: shutdownConfig.signals.join(" "),
    timeout: shutdownConfig.timeout,
    forceExit: shutdownConfig.forceExit,
    onShutdown: async () => {
      await new Promise((resolve) => {
        const timeout = setTimeout(() => {
          console.warn("Graceful shutdown timeout, force exiting...");
          resolve();
        }, shutdownConfig.timeout);
        nitroApp.hooks.callHook("close").catch((error) => {
          console.error(error);
        }).finally(() => {
          clearTimeout(timeout);
          resolve();
        });
      });
    }
  });
}

const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const nitroApp = useNitroApp();
const server = cert && key ? new Server({ key, cert }, toNodeListener(nitroApp.h3App)) : new Server$1(toNodeListener(nitroApp.h3App));
const port = destr(process.env.NITRO_PORT || process.env.PORT) || 3e3;
const host = process.env.NITRO_HOST || process.env.HOST;
const path = process.env.NITRO_UNIX_SOCKET;
const listener = server.listen(path ? { path } : { port, host }, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  const protocol = cert && key ? "https" : "http";
  const addressInfo = listener.address();
  if (typeof addressInfo === "string") {
    console.log(`Listening on unix socket ${addressInfo}`);
    return;
  }
  const baseURL = (useRuntimeConfig().app.baseURL || "").replace(/\/$/, "");
  const url = `${protocol}://${addressInfo.family === "IPv6" ? `[${addressInfo.address}]` : addressInfo.address}:${addressInfo.port}${baseURL}`;
  console.log(`Listening on ${url}`);
});
trapUnhandledNodeErrors();
setupGracefulShutdown(listener, nitroApp);
const nodeServer = {};

export { $fetch as $, appTeleportTag as A, NUXT_PAGE_PATTERNS as B, defineRenderHandler as C, toRequestEvent as D, setResponseHeader as E, withQuery as F, sanitizeStatusCode as G, parseURL as H, decodePath as I, isScriptProtocol as J, defu as K, parseQuery as L, hasProtocol as M, NUXT_PRERENDER_NO_SSR_ROUTES as N, withTrailingSlash as O, withoutTrailingSlash as P, nodeServer as Q, getRequestURL as a, appRootTag as b, createError$1 as c, defineEventHandler as d, appRootAttrs as e, appSpaLoaderTag as f, getRouterParam as g, appSpaLoaderAttrs as h, useNitroApp as i, joinRelativeURL as j, getRouteRules as k, createHead as l, unheadOptions as m, appId as n, getQuery$1 as o, proxyRequest as p, appHead as q, destr as r, NUXT_SSR_STREAMING as s, renderSSRHeadOptions as t, useRuntimeConfig as u, appTeleportAttrs as v, writeEarlyHints as w, NUXT_NO_SCRIPTS_PATTERNS as x, relative as y, joinURL as z };
//# sourceMappingURL=nitro.mjs.map
