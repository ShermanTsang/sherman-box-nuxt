import { d as defineEventHandler, u as useRuntimeConfig } from '../nitro/nitro.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'consola';
import 'sitemapd/parse';

const sitemapUrls_json_get = defineEventHandler(async (event) => {
  var _a;
  const config = useRuntimeConfig(event);
  const baseURL = String(config.public.apiBaseurl || "").replace(/\/$/, "");
  if (!baseURL) return [];
  try {
    const response = await $fetch(`${baseURL}/common/sitemap`);
    const pages = ((_a = response == null ? void 0 : response.data) == null ? void 0 : _a.data) || [];
    return pages.map((item) => ({
      loc: `/${item.module}/${item.resource_sn}`,
      changefreq: "daily",
      priority: 1
    }));
  } catch (error) {
    console.warn("[sitemap] Could not load API URLs; returning an empty dynamic URL list.", error);
    return [];
  }
});

export { sitemapUrls_json_get as default };
//# sourceMappingURL=sitemap-urls.json.get.mjs.map
