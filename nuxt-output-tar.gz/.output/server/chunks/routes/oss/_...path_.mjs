import { d as defineEventHandler, u as useRuntimeConfig } from '../../nitro/nitro.mjs';
import { p as proxyUpstream } from '../../_/proxy-upstream.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'consola';
import 'sitemapd/parse';

const ____path_ = defineEventHandler((event) => {
  const config = useRuntimeConfig(event);
  return proxyUpstream(event, String(config.public.ossBaseurl || process.env.OSS_BASEURL || ""));
});

export { ____path_ as default };
//# sourceMappingURL=_...path_.mjs.map
