const sources = [
    {
        "sourceType": "user",
        "fetch": "/sitemap-urls.json"
    },
    {
        "context": {
            "name": "nuxt:pages",
            "description": "Generated from your static page files.",
            "tips": [
                "Can be disabled with `{ excludeAppSources: ['nuxt:pages'] }`."
            ]
        },
        "urls": [
            {
                "loc": "/monument/2022"
            },
            {
                "loc": "/page/log"
            },
            {
                "loc": "/blog"
            },
            {
                "loc": "/day"
            },
            {
                "loc": "/error"
            },
            {
                "loc": "/idea"
            },
            {
                "loc": "/mailbox"
            },
            {
                "loc": "/monument"
            },
            {
                "loc": "/movie"
            },
            {
                "loc": "/plan"
            },
            {
                "loc": "/project"
            },
            {
                "loc": "/search"
            },
            {
                "loc": "/timeline"
            },
            {
                "loc": "/word"
            },
            {
                "loc": "/"
            }
        ],
        "sourceType": "app"
    }
];

export { sources };
//# sourceMappingURL=global-sources.mjs.map
