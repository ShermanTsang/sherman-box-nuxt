import { c as createError, g as getRouterParam, a as getRequestURL, p as proxyRequest } from '../nitro/nitro.mjs';

function proxyUpstream(event, baseURL) {
  if (!baseURL) {
    throw createError({ statusCode: 503, statusMessage: "Upstream service is not configured" });
  }
  const path = String(getRouterParam(event, "path") || "").replace(/^\/+/, "");
  const upstreamURL = `${baseURL.replace(/\/$/, "")}/${path}${getRequestURL(event).search}`;
  return proxyRequest(event, upstreamURL);
}

export { proxyUpstream as p };
//# sourceMappingURL=proxy-upstream.mjs.map
